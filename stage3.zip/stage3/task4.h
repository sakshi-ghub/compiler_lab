// nodetype 1-read
// 	     2-write
// 	     3-connector
// 	     4- '='
// 	     5- '+'
// 	     6- '-'
// 	     7- '*'
// 	     8- '/'
//	     9- LT
//	     10-GT
//	     11- LE
//           12- GE
//	      13- NE
//		14- EQ
//		15- IF_ELSE_THEN
//		16- WHILE
//type  0- num
//	1-ID
//	2-nonleaf
//	3-break
//	4-continue

//expr_type 0-boolean
//	     1-arithmetic
//           5-typeless

typedef struct tnode{
 int val; //value of a number for NUM nodes
 int type; //type of variable
 char *varname; //name of a variable for ID nodes
 int nodetype; //information about non-leaf nodes -read/write/connector/+/- etc
 int expr_type; //iformation about type of expression ex- arithmetic, boolean, typeless
 struct tnode *left,*right,*third; //left and right branches
 }tnode;
	
/*Make a tnode */
struct tnode* createTree(int val,int type, char c,int nodetype, int expr_type,struct tnode *l,struct tnode *r,struct tnode *t);
struct tnode* createID(int val,int type, char c,int nodetype, int expr_type,struct tnode *l,struct tnode *r,struct tnode *t);
int codeGen(struct tnode *t,FILE *target);
