struct tnode* createTree(int val,int type, char c,int nodetype,struct tnode *l,struct tnode *r)
{
    struct tnode *temp;
    temp = (struct tnode*)malloc(sizeof(struct tnode));
    temp->val=val;
    temp->type=type;
    temp->varname = NULL;
    temp->nodetype=nodetype;
    temp->left = l;
    temp->right = r;
    return temp;
}

struct tnode* createID(int val,int type, char c,int nodetype,struct tnode *l,struct tnode *r)
{
    struct tnode *temp;
    temp = (struct tnode*)malloc(sizeof(struct tnode));
    temp->val=val;
    temp->type=type;
    temp->varname = malloc(sizeof(char));
    *(temp->varname) = c;
    temp->nodetype=nodetype;
    temp->left = l;
    temp->right = r;
    return temp;
}

void traverse(struct tnode *t)
{
	if(t==NULL)
		{return;}
//	if(t->left!=NULL)
//		printf("(");
	traverse(t->left);
	if(t->type==0)
	{
		printf("%d ",t->val);
	}
	else if(t->type==1)
	{
		printf("%c ",*t->varname);
	}
	else if(t->type==2)
	{
		if(t->nodetype==1)
			printf("read ");
		else if(t->nodetype==2)
			printf("write ");
		else if(t->nodetype==3)
			printf("\n");
		else if(t->nodetype==4)
			printf("= ");
		else if(t->nodetype==5)
			printf("+ ");
		else if(t->nodetype==6)
			printf("- ");
		else if(t->nodetype==7)
			printf("* ");
		else if(t->nodetype==8)
			printf("/ ");
	}
	traverse(t->right);
//	if(t->left!=NULL)
//		printf(")");
}




int evaluate(struct tnode *t,int *arr){
	int i,j,num,index,num1,num2;
	if(t==NULL)
		return 0;
	
	if(t->type==0)
	{

		return (t->val);
	}
	else if(t->type==1)
	{
		num=(*t->varname)-'a';
		return (arr[num]);
	}		
	else
	{
		i=evaluate(t->left,arr);
		j=evaluate(t->right,arr);
		if(t->nodetype==1)
		{
			num=(*t->right->varname)-'a';
			printf("Enter value for %c\n",'a'+num);
			scanf("%d",&arr[num]);
			return j;
		}
		else if(t->nodetype==2)
		{
			printf("%d\n",j);
			return j;
		}
		else if(t->nodetype==3)
		{
			return i;
		}
		else if(t->nodetype==4)
		{
			num=(*t->left->varname)-'a';
			arr[num]=j;
			return i;
		}
		else if(t->nodetype==5)
		{
			if(t->right->type==1)
			{
				num2=(*t->right->varname)-'a';
				if(t->left->type==1)
				{
					num1=(*t->left->varname)-'a';
					return arr[num1]+arr[num2];
				}
				else
				{
                                        return i+arr[num2];
				}

			}
			else
			{
				if(t->left->type==1)
                                {
                                        num1=(*t->left->varname)-'a';
					return arr[num1]+j;
                                }
                                else
                                {
                                        return i+j;
                                }

			}
		}
		else if(t->nodetype==6)
		{

            		if(t->right->type==1)
			{
				num2=(*t->right->varname)-'a';
				if(t->left->type==1)
				{
					num1=(*t->left->varname)-'a';
					return arr[num1]-arr[num2];
				}
				else
				{
                                        return i-arr[num2];
				}

			}
			else
			{
				if(t->left->type==1)
                                {
                                        num1=(*t->left->varname)-'a';
					return arr[num1]-j;
                                }
                                else
                                {
                                        return i-j;
                                }

			}

		}
		else if(t->nodetype==7)
		{
           		if(t->right->type==1)
			{
				num2=(*t->right->varname)-'a';
				if(t->left->type==1)
				{
					num1=(*t->left->varname)-'a';
					return arr[num1]*arr[num2];
				}
				else
				{
                                        return i*arr[num2];
				}

			}
			else
			{
				if(t->left->type==1)
                                {
                                        num1=(*t->left->varname)-'a';
					return arr[num1]*j;
                                }
                                else
                                {
                                        return i*j;
                                }

			}

		}
		else if(t->nodetype==7)
		{
            		if(t->right->type==1)
			{
				num2=(*t->right->varname)-'a';
				if(t->left->type==1)
				{
					num1=(*t->left->varname)-'a';
					num=arr[num1]/arr[num2];
					return num;
				}
				else
				{
					num=i/arr[num2];
                                       return num;
				}

			}
			else
			{
				if(t->left->type==1)
                                {
                                        num1=(*t->left->varname)-'a';
                                        num=arr[num1]/j;
					 return num;
                                }
                                else
                                {
                                	num=i/j;
                                        return num;
                                }

			}

		}
	}
}


