struct tnode* createTree(int val,int type, char c,int nodetype,int expr_type,struct tnode *l,struct tnode *r,struct tnode *t)
{
    struct tnode *temp;
    temp = (struct tnode*)malloc(sizeof(struct tnode));
    temp->val=val;
    temp->type=type;
    temp->varname = NULL;
    temp->nodetype=nodetype;
    temp->left = l;
    temp->right = r;
    temp->expr_type=expr_type;
    temp->third=t;
    return temp;
}

struct tnode* createID(int val,int type, char c,int nodetype,int expr_type,struct tnode *l,struct tnode *r,struct tnode *t)
{
    struct tnode *temp;
    temp = (struct tnode*)malloc(sizeof(struct tnode));
    temp->val=val;
    temp->type=type;
    temp->varname = malloc(sizeof(char));
    *(temp->varname) = c;
    temp->nodetype=nodetype;
    temp->left = l;
    temp->right = r;
    temp->expr_type=expr_type;
    temp->third=t;
    return temp;
}



int evaluate(struct tnode *t,int *arr){
	int i,j,num,index,num1,num2;
	if(t==NULL)
		return 0;
	
	if(t->type==0)
	{

		return (t->val);
	}
	else if(t->type==1)
	{
		num=(*t->varname)-'a';
		return (arr[num]);
	}		
	else
	{
		if(!(t->nodetype==15 || t->nodetype==16))
		{
			i=evaluate(t->left,arr);
			j=evaluate(t->right,arr);
		}
		if(t->nodetype==1)
		{
			if(t->right->expr_type!=1)
			{
				printf("ERROR type-mismatch1");
				exit(0);
			}
			num=(*t->right->varname)-'a';
			printf("Enter value for %c\n",'a'+num);
			scanf("%d",&arr[num]);
			return j;
		}
		else if(t->nodetype==2)
		{
			if(t->right->expr_type!=1)
                        {
                                printf("ERROR type-mismatch2");
                                exit(0);
                        }
			printf("%d\n",j);
			return j;
		}
		else if(t->nodetype==3)
		{
			return i;
		}
		else if(t->nodetype==4)
		{
			if(t->right->expr_type!=1)
                        {
                                printf("ERROR type-mismatch3");
                                exit(0);
                        }
			num=(*t->left->varname)-'a';
			arr[num]=j;
			return i;
		}
		else if(t->nodetype==5)
		{
			if(t->left->expr_type!=1||t->right->expr_type!=1)
                        {
                                printf("ERROR type-mismatch4");
                                exit(0);
                        }
			if(t->right->type==1)
			{
				num2=(*t->right->varname)-'a';
				if(t->left->type==1)
				{
					num1=(*t->left->varname)-'a';
					return arr[num1]+arr[num2];
				}
				else
				{
                                        return i+arr[num2];
				}
			}
			else
			{
				if(t->left->type==1)
                                {
                                        num1=(*t->left->varname)-'a';
					return arr[num1]+j;
                                }
                                else
                                {
                                        return i+j;
                                }
			}
		}
		else if(t->nodetype==6)
		{
			if(t->left->expr_type!=1||t->right->expr_type!=1)
                        {
                                printf("ERROR type-mismatch5");
                                exit(0);
                        }
            		if(t->right->type==1)
			{
				num2=(*t->right->varname)-'a';
				if(t->left->type==1)
				{
					num1=(*t->left->varname)-'a';
					return arr[num1]-arr[num2];
				}
				else
				{
                                        return i-arr[num2];
				}
			}
			else
			{
				if(t->left->type==1)
                                {
                                        num1=(*t->left->varname)-'a';
					return arr[num1]-j;
                                }
                                else
                                {
                                        return i-j;
                                }
			}
		}
		else if(t->nodetype==7)
		{
			if(t->left->expr_type!=1||t->right->expr_type!=1)
                        {
                                printf("ERROR type-mismatch6");
                                exit(0);
                        }
           		if(t->right->type==1)
			{
				num2=(*t->right->varname)-'a';
				if(t->left->type==1)
				{
					num1=(*t->left->varname)-'a';
					return arr[num1]*arr[num2];
				}
				else
				{
                                        return i*arr[num2];
				}
			}
			else
			{
				if(t->left->type==1)
                                {
                                        num1=(*t->left->varname)-'a';
					return arr[num1]*j;
                                }
                                else
                                {
                                        return i*j;
                                }
			}
		}
		else if(t->nodetype==8)
		{
			if(t->left->expr_type!=1||t->right->expr_type!=1)
                        {
                                printf("ERROR type-mismatch7");
                                exit(0);
                        }

            		if(t->right->type==1)
			{
				num2=(*t->right->varname)-'a';
				if(t->left->type==1)
				{
					num1=(*t->left->varname)-'a';
					num=arr[num1]/arr[num2];
					return num;
				}
				else
				{
					num=i/arr[num2];
                                       return num;
				}

			}
			else
			{
				if(t->left->type==1)
                                {
                                        num1=(*t->left->varname)-'a';
                                        num=arr[num1]/j;
					 return num;
                                }
                                else
                                {
                                	num=i/j;
                                        return num;
                                }
			}
		}
		else if(t->nodetype==15)
		{
			if(t->left->expr_type!=0)
			{
				printf("ERROR-TYPE MISMATCH8\n");
				exit(0);
			}
			i=evaluate(t->left,arr);
			//printf("---%d---\n",i);
			if(i)
			{
				j=evaluate(t->right,arr);
			}
			else
			{
				if(t->third)
					j=evaluate(t->third,arr);
			}
			return i;
		}
		else if(t->nodetype==16)
		{
			if(t->left->expr_type!=0)
                        {
                                printf("ERROR-TYPE MISMATCH8\n");
                                exit(0);
                        }
                        while(1)
			{
				i=evaluate(t->left,arr);
				if(i)
					j=evaluate(t->right,arr);
				else
					break;
			}
		}
		else
		{
			if(t->left->expr_type!=1||t->right->expr_type!=1)
                        {
                                printf("ERROR type-mismatch9");
                                exit(0);
                        }

			if(t->left->type==1)
			{
				num=(*t->left->varname)-'a';
				num1=arr[num];
			}
			else
				num1=i;
			if(t->right->type==1)
			{
				num=(*t->right->varname)-'a';
				num2=arr[num];
			}
			else
				num2=j;
			if(t->nodetype==9)
			{
				//printf("***%d--%d***\n",num1,num2);
				return (num1<num2);
			}
			else if(t->nodetype==10)
				return (num1>num2);
			else if(t->nodetype==11)
				return (num1<=num2);
			else if(t->nodetype==12)
				return (num1>=num2);
			else if(t->nodetype==13)
				return (num1!=num2);
			else if(t->nodetype==14)
				return (num1==num2);
		}
	}
}


