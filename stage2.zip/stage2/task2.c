struct tnode* createTree(int val,int type, char c,int nodetype,struct tnode *l,struct tnode *r)
{
    struct tnode *temp;
    temp = (struct tnode*)malloc(sizeof(struct tnode));
    temp->val=val;
    temp->type=type;
    temp->varname = NULL;
    temp->nodetype=nodetype;
    temp->left = l;
    temp->right = r;
    return temp;
}

struct tnode* createID(int val,int type, char c,int nodetype,struct tnode *l,struct tnode *r)
{
    struct tnode *temp;
    temp = (struct tnode*)malloc(sizeof(struct tnode));
    temp->val=val;
    temp->type=type;
    temp->varname = malloc(sizeof(char));
    *(temp->varname) = c;
    temp->nodetype=nodetype;
    temp->left = l;
    temp->right = r;
    return temp;
}

void traverse(struct tnode *t)
{
	if(t==NULL)
		{return;}
//	if(t->left!=NULL)
//		printf("(");
	traverse(t->left);
	if(t->type==0)
	{
		printf("%d ",t->val);
	}
	else if(t->type==1)
	{
		printf("%c ",*t->varname);
	}
	else if(t->type==2)
	{
		if(t->nodetype==1)
			printf("read ");
		else if(t->nodetype==2)
			printf("write ");
		else if(t->nodetype==3)
			printf("\n");
		else if(t->nodetype==4)
			printf("= ");
		else if(t->nodetype==5)
			printf("+ ");
		else if(t->nodetype==6)
			printf("- ");
		else if(t->nodetype==7)
			printf("* ");
		else if(t->nodetype==8)
			printf("/ ");
	}
	traverse(t->right);
//	if(t->left!=NULL)
//		printf(")");
}




int codeGen(struct tnode *t,FILE *target){
	int i,j,num;
	if(t==NULL)
		return 0;
	static int regNo=6;
	if(regNo>19)
	{
		printf("Out of registers\n");
		exit(0);
	}
	if(t->type==0)
	{
		fprintf(target, "MOV R%d, %d\n",regNo++,t->val);
		return (regNo-1);
	}
	else if(t->type==1)
	{
		num=4096+(*t->varname)-'a';
		return num;
	}		
	else
	{
		i=codeGen(t->left,target);
		j=codeGen(t->right,target);
		if(t->nodetype==1)
		{
			num=j;
			fprintf(target, "MOV SP, 4121\n");
			fprintf(target, "MOV R1, \"Read\"\n");
        		fprintf(target, "PUSH R1\n");
        		fprintf(target, "MOV R1, -1\n");
        		fprintf(target, "PUSH R1\n");
			fprintf(target, "MOV R1, %d\n",num);
        		fprintf(target, "PUSH R1\n");
			fprintf(target, "PUSH R0\n");
        		fprintf(target, "PUSH R0\n");
        		fprintf(target,"CALL 128\n");
        		fprintf(target, "POP R0\n");
        		fprintf(target, "POP R1\n");
        		fprintf(target, "POP R1\n");
        		fprintf(target, "POP R1\n");
        		fprintf(target, "POP R1\n");
		}
		else if(t->nodetype==2)
		{
			if(t->right->type==1)
			{
				fprintf(target,"MOV R0, [%d]\n",j);
			}
			else
			{
				fprintf(target,"MOV R0, R%d\n",j);
			}
			fprintf(target, "MOV SP, 4121\n");
			fprintf(target, "MOV R1, \"Write\"\n");
			fprintf(target, "PUSH R1\n");
			fprintf(target, "MOV R1, -2\n");
			fprintf(target, "PUSH R1\n");
			fprintf(target, "PUSH R0\n");
			fprintf(target, "PUSH R0\n");
			fprintf(target, "PUSH R0\n");
			fprintf(target,"CALL 0\n");
			fprintf(target, "POP R0\n");
			fprintf(target, "POP R1\n");
			fprintf(target, "POP R1\n");
			fprintf(target, "POP R1\n");
			fprintf(target, "POP R1\n");
			return regNo;
		}
		else if(t->nodetype==3)
		{
			return regNo;
		}
		else if(t->nodetype==4)
		{
			fprintf(target,"MOV [%d], R%d\n",i,j);
			regNo--;
			return regNo;
		}
		else if(t->nodetype==5)
		{
			if(t->right->type==1)
			{
				if(t->left->type==1)
				{
					fprintf(target, "MOV R%d, [%d]\n",regNo,i);
					fprintf(target, "MOV R0, [%d]\n",j);
					fprintf(target, "ADD R%d, R0\n",regNo);
					regNo++;
					return regNo-1;
				}
				else
				{
                                        fprintf(target, "MOV R0, [%d]\n",j);
                                        fprintf(target, "ADD R%d, R0\n",i);
                                        return i;
				}

			}
			else
			{
				if(t->left->type==1)
                                {
                                        fprintf(target, "MOV R0, [%d]\n",i);
                                        fprintf(target, "ADD R%d, R0\n",j);
                                        return j;
                                }
                                else
                                {
                                        fprintf(target, "ADD R%d, R%d\n",i,j);
					regNo--;
                                        return i;
                                }

			}
		}
		else if(t->nodetype==6)
		{

            		if(t->right->type==1)
                        {
                                if(t->left->type==1)
                                {
                                        fprintf(target, "MOV R%d, [%d]\n",regNo,i);
                                        fprintf(target, "MOV R0, [%d]\n",j);
                                        fprintf(target, "SUB R%d, R0\n",regNo);
                                        regNo++;
                                        return regNo-1;
                                }
                                else
                                {
                                        fprintf(target, "MOV R0, [%d]\n",j);
                                        fprintf(target, "SUB R%d, R0\n",i);
                                        return i;
                                }
                                
                        }
                        else
                        {
                                if(t->left->type==1)
                                {
                                        fprintf(target, "MOV R0, [%d]\n",i);
                                        fprintf(target, "SUB R%d, R0\n",j);
                                        return j;
                                }
                                else
                                {
                                        fprintf(target, "SUB R%d, R%d\n",i,j);
                                        regNo--;
                                        return i;
                                }

                        }

		}
		else if(t->nodetype==7)
		{
           		if(t->right->type==1)
                        {
                                if(t->left->type==1)
                                {
                                        fprintf(target, "MOV R%d, [%d]\n",regNo,i);
                                        fprintf(target, "MOV R0, [%d]\n",j);
                                        fprintf(target, "MUL R%d, R0\n",regNo);
                                        regNo++;
                                        return regNo-1;
                                }
                                else
                                {
                                        fprintf(target, "MOV R0, [%d]\n",j);
                                        fprintf(target, "MUL R%d, R0\n",i);
                                        return i;
                                }
                                
                        }
                        else
                        {
                                if(t->left->type==1)
                                {
                                        fprintf(target, "MOV R0, [%d]\n",i);
                                        fprintf(target, "MUL R%d, R0\n",j);
                                        return j;
                                }
                                else
                                {
                                        fprintf(target, "MUL R%d, R%d\n",i,j);
                                        regNo--;
                                        return i;
                                }

                        }

		}
		else if(t->nodetype==7)
		{
            		if(t->right->type==1)
                        {
                                if(t->left->type==1)
                                {
                                        fprintf(target, "MOV R%d, [%d]\n",regNo,i);
                                        fprintf(target, "MOV R0, [%d]\n",j);
                                        fprintf(target, "DIV R%d, R0\n",regNo);
                                        regNo++;
                                        return regNo-1;
                                }
                                else
                                {
                                        fprintf(target, "MOV R0, [%d]\n",j);
                                        fprintf(target, "DIV R%d, R0\n",i);
                                        return i;
                                }
                                
                        }
                        else
                        {
                                if(t->left->type==1)
                                {
                                        fprintf(target, "MOV R0, [%d]\n",i);
                                        fprintf(target, "DIV R%d, R0\n",j);
                                        return j;
                                }
                                else
                                {
                                        fprintf(target, "DIV R%d, R%d\n",i,j);
                                        regNo--;
                                        return i;
                                }

                        }

		}
	}
}


