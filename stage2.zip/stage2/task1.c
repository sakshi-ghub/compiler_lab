struct tnode* createTree(int val,int type, char c,int nodetype,struct tnode *l,struct tnode *r)
{
    struct tnode *temp;
    temp = (struct tnode*)malloc(sizeof(struct tnode));
    temp->val=val;
    temp->type=type;
    temp->varname = NULL;
    temp->nodetype=nodetype;
    temp->left = l;
    temp->right = r;
    return temp;
}

struct tnode* createID(int val,int type, char c,int nodetype,struct tnode *l,struct tnode *r)
{
    struct tnode *temp;
    temp = (struct tnode*)malloc(sizeof(struct tnode));
    temp->val=val;
    temp->type=type;
    temp->varname = malloc(sizeof(char));
    *(temp->varname) = c;
    temp->nodetype=nodetype;
    temp->left = l;
    temp->right = r;
    return temp;
}

void traverse(struct tnode *t)
{
	if(t==NULL)
		{return;}
//	if(t->left!=NULL)
//		printf("(");
	traverse(t->left);
	if(t->type==0)
	{
		printf("%d ",t->val);
	}
	else if(t->type==1)
	{
		printf("%c ",*t->varname);
	}
	else if(t->type==2)
	{
		if(t->nodetype==1)
			printf("read ");
		else if(t->nodetype==2)
			printf("write ");
		else if(t->nodetype==3)
			printf("\n");
		else if(t->nodetype==4)
			printf("= ");
		else if(t->nodetype==5)
			printf("+ ");
		else if(t->nodetype==6)
			printf("- ");
		else if(t->nodetype==7)
			printf("* ");
		else if(t->nodetype==8)
			printf("/ ");
	}
	traverse(t->right);
//	if(t->left!=NULL)
//		printf(")");
}



