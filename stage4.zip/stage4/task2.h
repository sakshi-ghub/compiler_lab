// nodetype 1-read
// 	     2-write
// 	     3-connector
// 	     4- '='
// 	     5- '+'
// 	     6- '-'
// 	     7- '*'
// 	     8- '/'
//	     9- LT
//	     10-GT
//	     11- LE
//           12- GE
//	      13- NE
//		14- EQ
//		15- IF_ELSE_THEN
//		16- WHILE
//		17-MODULUS
//type  0- num
//	1-ID
//	2-nonleaf
//	3-break
//	4-continue
//	5-string
//	
//	7-array element

//expr_type 0-boolean
//	     1-arithmetic
//	      2-string
//           5-typeless

typedef struct tnode{
 int val; //value of a number for NUM nodes
 int type; //type of variable
 char *varname; //name of a variable for ID nodes
 int nodetype; //information about non-leaf nodes -read/write/connector/+/- etc
 int expr_type; //iformation about type of expression ex- arithmetic, boolean, typeless
 struct tnode *left,*right,*third; //left and right branches
 struct Gsymbol *Gentry; //pointer to GST entry for global variables and functions
}tnode;

typedef struct Gsymbol{
 char* name; //name of the variable
 int type;   //type of the variable
 int size;   //sizeof the type of the variable
 int binding; //stores the static memory address allocated to the variable
 struct Gsymbol *next;
 }Gsymbol;
 
/*Make a tnode */
struct tnode* createTree(int val,int type, char c,int nodetype, int expr_type,struct tnode *l,struct tnode *r,struct tnode *t);
struct tnode* createID(int val,int type, char *c,int nodetype, int expr_type,struct Gsymbol *Gentry,struct tnode *l,struct tnode *r,struct tnode *t);
int evaluate(struct tnode *t,int *arr);
void Install(struct Gsymbol **Table,char *name, int type, int size,int binding);
struct Gsymbol *Lookup(struct Gsymbol *Table,char *name);
int freeReg();
void read_codeGen(struct tnode*t, FILE *target);
void write_codeGen(struct tnode*t, FILE *target);
int get_Address(FILE *target,struct tnode * t);
int expression_codeGen(struct tnode*t,FILE *target);
void assg_codeGen(struct tnode*t, FILE *target);
int bool_codeGen(struct tnode *t, FILE *target);
void while_codeGen(struct tnode *t, FILE *target);
void if_else_codeGen(struct tnode * t, FILE *target,int break_label, int continue_label);
void codeGen(struct tnode *t, FILE *target, int break_label, int continue_label);

