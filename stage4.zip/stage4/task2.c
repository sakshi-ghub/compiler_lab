int LABEL = -1;
struct Gsymbol *Table=NULL;
struct Gsymbol *temp,*temp1;
int break_label,continue_label;
int getLabel()
{
    int a = ++LABEL;
    return a;
}

struct tnode* createTree(int val,int type, char c,int nodetype,int expr_type,struct tnode *l,struct tnode *r,struct tnode *t)
{
	if(type==2)
	{
		if (nodetype==2)
		{
			if(r->expr_type!=1 && r->expr_type!=2)
			{
				yyerror("Type mismatch");
				exit(0);
			}
		}
		else if (nodetype==1)
		{
			if(r->type!=1 && r->type!=7)
			{
				yyerror("Type mismatch");
				exit(0);
			}
		}
		else if(nodetype==4|| nodetype==13 || nodetype==14)
		{
			if(l->expr_type!=r->expr_type)
			{
				yyerror("Type mismatch");
				exit(0);
			}
		}
		else if(nodetype==5 || nodetype==6 || nodetype==7 || nodetype==8 ||nodetype==17|| nodetype==9 || nodetype==10 || nodetype==11 || nodetype==12 )
		{
			if(l->expr_type!=1 || r->expr_type!=1)
			{
				yyerror("Type mismatch");
				exit(0);
			}
		}
		else if(nodetype==15 || nodetype==16)
		{
			if(l->expr_type!=0)
			{
				yyerror("Type mismatch");
				exit(0);
			}
		}
	}

    	struct tnode *temp;
    	temp = (struct tnode*)malloc(sizeof(struct tnode));
    	temp->val=val;
    	temp->type=type;
    	temp->varname = NULL;
    	temp->nodetype=nodetype;
    	temp->left = l;
    	temp->right = r;
    	temp->expr_type=expr_type;
    	temp->third=t;
    	return temp;
}

struct tnode* createID(int val,int type, char *varname,int nodetype,int expr_type,struct Gsymbol *Gentry,struct tnode *l,struct tnode *r,struct tnode *t)
{
    struct tnode *temp;
    temp = (struct tnode*)malloc(sizeof(struct tnode));
    temp->val=val;
    temp->type=type;
    temp->varname = (char*)malloc(sizeof(char)*100);
    strcpy(temp->varname,varname);
    temp->nodetype=nodetype;
    temp->left = l;
    temp->right = r;
    temp->expr_type=expr_type;
    temp->third=t;
    temp->Gentry=Gentry;
    return temp;
}

struct Gsymbol *Lookup(struct Gsymbol *Table,char *name)
{
	if(Table==NULL)
		return NULL;
	while(Table!=NULL)
	{
		if(strcmp(Table->name, name)==0)
			return Table;
		Table=Table->next;
	}
	return NULL;
}


void Install(struct Gsymbol **Table,char *name, int type, int size,int binding)
{
	struct Gsymbol *temp=(struct Gsymbol*)malloc(sizeof(struct Gsymbol));
	temp->name=(char*)malloc(sizeof(char)*100);
	strcpy(temp->name,name);
	temp->type=type;
	temp->size=size;
	temp->binding=4096+binding;
	temp->next=(*Table);
	(*Table) =temp;
}
int reg[20];
//Get a register
int getReg()
{
    for(int i = 0;i < 20;i++)
    {
        if(reg[i] == 0)
        {
            reg[i] = 1;
            return i;
        }
    }

    printf("Out of Registers\n");
    return -1;
}

//Free a register
int freeReg()
{
    int max = -1;
    for (int i = 0; i < 20; i++)
    {
        if (reg[i] == 1 && i > max)
            max = i;
    }
    if (max != -1)
    {
        reg[max] = 0;
        return max;
    }
    printf("Invalid Register\n");
    exit(1);
}

void read_codeGen(struct tnode*t, FILE *target)
{
	int var_Addr;
        int idx = getReg();
        if (idx == -1)
            exit(1);
        if(t->right->type == 1)
        {
            var_Addr = get_Address(target,t->right);
            fprintf(target, "MOV R%d, R%d\n", idx, var_Addr);
        }
        else if(t->right->type == 7)
        {
            var_Addr = get_Address(target,t->right);
            fprintf(target, "MOV R%d,R%d\n", idx ,var_Addr);
            var_Addr = freeReg();   
        }
        
        int temp = getReg();
        if (temp == -1)
            exit(1);
        fprintf(target, "MOV SP, 4296\n");
        fprintf(target, "MOV R%d,\"Read\"\n", temp);
        fprintf(target, "PUSH R%d\n", temp);
        fprintf(target, "MOV R%d,-1\n", temp);
        fprintf(target, "PUSH R%d\n", temp);
        fprintf(target, "PUSH R%d\n", idx);
        fprintf(target, "PUSH R%d\n", temp);
        fprintf(target, "PUSH R%d\n", temp);
        fprintf(target, "CALL 128\n");
        fprintf(target, "POP R%d\n", temp);
        fprintf(target, "POP R%d\n", temp);
        fprintf(target, "POP R%d\n", temp);
        fprintf(target, "POP R%d\n", temp);
        fprintf(target, "POP R%d\n", temp);
        temp = freeReg();
        if (temp == -1)
            exit(1);
        idx = freeReg();
        if (idx == -1)
            exit(1);  
    
}

void write_codeGen(struct tnode*t, FILE *target)
{
        int idx;
    	idx = expression_codeGen(t->right, target);
        int temp = getReg();
        if (temp == -1)
            exit(1);
        fprintf(target, "MOV SP, 4296\n");
        fprintf(target, "MOV R%d,\"Write\"\n", temp);
        fprintf(target, "PUSH R%d\n", temp);
        fprintf(target, "MOV R%d,-2\n", temp);
        fprintf(target, "PUSH R%d\n", temp);
        fprintf(target, "PUSH R%d\n", idx);
        fprintf(target, "PUSH R%d\n", temp);
        fprintf(target, "PUSH R%d\n", temp);
        fprintf(target, "CALL 0\n");
        fprintf(target, "POP R%d\n", temp);
        fprintf(target, "POP R%d\n", temp);
        fprintf(target, "POP R%d\n", temp);
        fprintf(target, "POP R%d\n", temp);
        fprintf(target, "POP R%d\n", temp);
        idx = freeReg();
        if (idx == -1)
            exit(1);
        idx = freeReg();
        if (idx == -1)
            exit(1);
}

int get_Address(FILE *target,struct tnode * t)
{
    int tmp;
    struct Gsymbol *tmp2 ;
    
    if(t->type == 7)
    {
        tmp2 = Lookup(Table,t->varname);

        tmp = getReg();
        fprintf(target,"MOV R%d, %d\n",tmp,tmp2->binding);
        int tmp1 = expression_codeGen(t->left,target);
        fprintf(target,"ADD R%d, R%d\n",tmp,tmp1);
        tmp1 = freeReg();
        return tmp;
    }
    else
    {
        temp = Lookup(Table,t->varname);
        int reg_i = getReg();
            //if(tmp2 != NULL)
        fprintf(target, "MOV R%d, %d\n",reg_i, temp->binding);
            /*else
                printf("Variable Not Declared\n");*/
       return reg_i;
    }
}

int expression_codeGen(struct tnode*t,FILE *target)
{
    int idx;
    if(t->type == 0)
    {
        idx = getReg();
        if(idx == -1)
            exit(1);
        fprintf(target,"MOV R%d, %d\n",idx, t->val);
        return idx;
    }
    else if(t->type == 1  || t->type==7)
    {
        idx = getReg();
        int var_Addr = get_Address(target,t);
        if(idx == -1)
            exit(1);

        fprintf(target,"MOV R%d, [R%d]\n",idx, var_Addr);
        var_Addr = freeReg();
        return idx;
    }
    /*else if(t->type == 7 && t->expr_type == 1)
    {
        idx = getReg();
        int var_Addr = get_Address(target,t);
        if(idx == -1)
            exit(1);

        fprintf(target,"MOV R%d, [R%d]\n",idx,var_Addr);
        var_Addr = freeReg();
        return idx;
    }*/
    else if(t->type == 5)
    {
        idx = getReg();
        if(idx == -1)
            exit(1);
	fprintf(target,"MOV R%d,\"%s\"\n",idx,t->varname);
        return idx;
    }/*
    else if(t->type == 1 && t->expr_type == 2)
    {
        idx = getReg();
        int var_Addr = get_Address(target,t);
        if(idx == -1)
            exit(1);

        fprintf(target,"MOV R%d, [%d]\n",idx, var_Addr);
        var_Addr = freeReg();
        return idx;
    }*/
    else if(t->left || t->right)
    {

        int left, right;
        if(t->left)
            left = expression_codeGen(t->left, target);
        if(t->right)
            right = expression_codeGen(t->right, target);

        switch(t->nodetype)
        {
            case 5:
                    fprintf(target,"ADD R%d, R%d\n",left, right);
                    idx = freeReg();

                    if(idx == -1)
                        exit(1);
                    return left;
                    break;
            case 6:
                    fprintf(target,"SUB R%d, R%d\n",left, right);
                    idx = freeReg();

                    if(idx == -1)
                        exit(1);
                    return left;
                    break;
            case 7:
                    fprintf(target,"MUL R%d, R%d\n",left, right);
                    idx = freeReg();

                    if(idx == -1)
                        exit(1);
                    return left;
                    break;
            case 8:
                    fprintf(target,"DIV R%d, R%d\n",left, right);
                    idx = freeReg();

                    if(idx == -1)
                        exit(1);
                    return left;
                    break;
            case 17:
                    fprintf(target,"MOD R%d, R%d\n",left, right);
                    idx = freeReg();

                    if(idx == -1)
                        exit(1);
                    return left;
                    break;
        }

    }

}
void assg_codeGen(struct tnode*t, FILE *target)
{
    	int idx,var_Addr;
        idx = expression_codeGen(t->right, target);
        if(t->left->type == 1)
        {
            var_Addr = get_Address(target, t->left);
            fprintf(target,"MOV [R%d], R%d\n",var_Addr,idx);
            var_Addr = freeReg();
        }
        else if(t->left->type == 7)
        {
            var_Addr = get_Address(target,t->left);
            fprintf(target,"MOV [R%d], R%d\n",var_Addr,idx);
            var_Addr = freeReg();
        }
        
        idx = freeReg();
        if(idx == -1){
            exit(1);
        }
}
int bool_codeGen(struct tnode *t, FILE *target)
{
    int a, b,idx;
    a = expression_codeGen(t->left,target);
    b = expression_codeGen(t->right,target);

    switch(t->nodetype)
    {
        case 9:
            fprintf(target,"LT R%d,R%d\n",a,b);
            idx = freeReg();
	     if(idx == -1)
                   exit(1);
            break;
        case 10:
            fprintf(target,"GT R%d,R%d\n",a,b);
            idx = freeReg();
	     if(idx == -1)
                   exit(1);
            break;
        case 11:
            fprintf(target,"LE R%d,R%d\n",a,b);
            idx = freeReg();
	     if(idx == -1)
                   exit(1);
            break;
        case 12:
            fprintf(target,"GE R%d,R%d\n",a,b);
            idx = freeReg();
	     if(idx == -1)
                   exit(1);
            break;
        case 14:
            fprintf(target,"EQ R%d,R%d\n",a,b);
            idx = freeReg();
	     if(idx == -1)
                   exit(1);
            break;
        case 13:
            fprintf(target,"NE R%d,R%d\n",a,b);
            idx = freeReg();
	     if(idx == -1)
                   exit(1);
            break;
    }
    
    return a;
}

void while_codeGen(struct tnode *t, FILE *target)
{
    if(t->left)
    {
        int label1 = getLabel();
        int label2 = getLabel();
        int idx;
        fprintf(target,"L%d:\n",label1);
        break_label=label2;
        continue_label=label1;
        if(t->left)
            idx=bool_codeGen(t->left,target);
	fprintf(target,"JZ R%d, L%d\n",idx,label2);
    	int tmp = freeReg();
        if(t->right)
            codeGen(t->right,target,label2,label1);
            
    	
    	
        fprintf(target, "JMP L%d\n",label1);
        fprintf(target, "L%d:\n",label2);
        return ;
    }
    printf("Invalid WHILE\n");
    exit(0);
}
void if_else_codeGen(struct tnode * t, FILE *target,int break_label, int continue_label)
{
	int label1 = getLabel();
        int idx,label2;
	idx=bool_codeGen(t->left,target);
	if(t->third)
	{
		label2 = getLabel();
		fprintf(target, "JZ R%d, L%d\n",idx,label2);
	}
	else
		fprintf(target, "JZ R%d, L%d\n",idx,label1);		
	codeGen(t->right,target,break_label,continue_label);
	fprintf(target, "JMP L%d\n",label1);
			
	if(t->third)
	{
		fprintf(target,"L%d:\n",label2);
		codeGen(t->third,target,break_label,continue_label);
	}
	fprintf(target, "JMP L%d\n",label1);
	fprintf(target,"L%d:\n",label1);
		
}
void codeGen(struct tnode *t, FILE *target, int break_label, int continue_label)
{
	if(t)
	{
		if(t->type==2)
		{
			if(t->nodetype==1)
			{
				read_codeGen(t,target);
				return;
			}
			if(t->nodetype==2)
			{
				write_codeGen(t,target);
				return;
			}
			if(t->nodetype==4)
			{
				assg_codeGen(t,target);
				return;
			}
			if(t->nodetype==15)
			{
				if_else_codeGen(t,target,break_label,continue_label);
				return;
			}
			if(t->nodetype==16)
			{
				while_codeGen(t,target);
				return;
			}
		}
		else if(t->type==3)
		{
			if(break_label != -1)
                	fprintf(target,"JMP L%d\n",break_label);
            		return ; 
            	}
            	else if(t->type == 4)
        	{
            		if(continue_label != -1)
               	fprintf(target,"JMP L%d\n",continue_label);
           		return ;
        	}
        	codeGen(t->left,target,break_label,continue_label);
        	codeGen(t->right,target,break_label,continue_label);
        }
        return;
}			


