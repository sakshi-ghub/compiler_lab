struct tnode* createTree(int val,int type, char c,int nodetype,int expr_type,struct tnode *l,struct tnode *r,struct tnode *t)
{
    struct tnode *temp;
    temp = (struct tnode*)malloc(sizeof(struct tnode));
    temp->val=val;
    temp->type=type;
    temp->varname = NULL;
    temp->nodetype=nodetype;
    temp->left = l;
    temp->right = r;
    temp->expr_type=expr_type;
    temp->third=t;
    return temp;
}

struct tnode* createID(int val,int type, char *varname,int nodetype,int expr_type,struct Gsymbol *Gentry,struct tnode *l,struct tnode *r,struct tnode *t)
{
    struct tnode *temp;
    temp = (struct tnode*)malloc(sizeof(struct tnode));
    temp->val=val;
    temp->type=type;
    temp->varname = (char*)malloc(sizeof(char)*100);
    strcpy(temp->varname,varname);
    temp->nodetype=nodetype;
    temp->left = l;
    temp->right = r;
    temp->expr_type=expr_type;
    temp->third=t;
    temp->Gentry=Gentry;
    return temp;
}

struct Gsymbol *Lookup(struct Gsymbol *Table,char *name)
{
	if(Table==NULL)
		return NULL;
	while(Table!=NULL)
	{
		if(strcmp(Table->name, name)==0)
			return Table;
		Table=Table->next;
	}
	return NULL;
}


void Install(struct Gsymbol **Table,char *name, int type, int size,int binding)
{
	struct Gsymbol *temp=(struct Gsymbol*)malloc(sizeof(struct Gsymbol));
	temp->name=(char*)malloc(sizeof(char)*100);
	strcpy(temp->name,name);
	temp->type=type;
	temp->size=size;
	temp->binding=4096+binding;
	temp->next=(*Table);
	(*Table) =temp;
}


int codeGen(struct tnode *t,FILE *target){
	int i,j,num,k1,k2;
	static int k=-1;
	if(t==NULL)
		return 0;
	static int regNo=6;
	static int labelno=0;
	if(regNo>19)
	{
		printf("Out of registers\n");
		exit(0);
	}
	if(t->type==0)
	{
		fprintf(target, "MOV R%d, %d\n",regNo++,t->val);
		return (regNo-1);
	}
	else if(t->type==1)
	{
		num=t->Gentry->binding;
		return num;
	}
	else if(t->type==3)
	{
		if(k!=-1)
			fprintf(target,"JMP L%d\n",k);
		
	}
	else if(t->type==4)
	{
		if(k!=-1)
			fprintf(target,"JMP L%d\n",k-1);
	}
	else if(t->type==5)
	{
		return regNo;	
	}	
	else
	{
		if(!(t->nodetype==15 || t->nodetype==16))
		{
			i=codeGen(t->left,target);
			j=codeGen(t->right,target);
		}
		if(t->nodetype==1)
		{
			if((t->right->expr_type==1 || t->right->expr_type==2) && t->right->type==1)
			{
				num=j;
				fprintf(target, "MOV SP, 4121\n");
				fprintf(target, "MOV R1, \"Read\"\n");
        			fprintf(target, "PUSH R1\n");
        			fprintf(target, "MOV R1, -1\n");
        			fprintf(target, "PUSH R1\n");
				fprintf(target, "MOV R1, %d\n",num);
        			fprintf(target, "PUSH R1\n");
				fprintf(target, "PUSH R0\n");
        			fprintf(target, "PUSH R0\n");
        			fprintf(target,"CALL 128\n");
        			fprintf(target, "POP R0\n");
        			fprintf(target, "POP R1\n");
        			fprintf(target, "POP R1\n");
        			fprintf(target, "POP R1\n");
        			fprintf(target, "POP R1\n");
        			return regNo;
			}
			else
			{
				printf("ERROR type-mismatch1");
				exit(0);
			}
			
		}
		else if(t->nodetype==2)
		{
			if(t->right->expr_type!=1 && t->right->expr_type!=2)
                        {
                                printf("ERROR type-mismatch2");
                                exit(0);
                        }
			if(t->right->type==1)
			{
				fprintf(target,"MOV R0, [%d]\n",j);
			}
			else if(t->right->type==0)
			{
				fprintf(target,"MOV R0, R%d\n",j);
			}
			else if(t->right->type==5)
			{
				fprintf(target,"MOV R0, \"%s\"\n",t->right->varname);
			}
			
			fprintf(target, "MOV SP, 4121\n");
			fprintf(target, "MOV R1, \"Write\"\n");
			fprintf(target, "PUSH R1\n");
			fprintf(target, "MOV R1, -2\n");
			fprintf(target, "PUSH R1\n");
			fprintf(target, "PUSH R0\n");
			fprintf(target, "PUSH R0\n");
			fprintf(target, "PUSH R0\n");
			fprintf(target,"CALL 0\n");
			fprintf(target, "POP R0\n");
			fprintf(target, "POP R1\n");
			fprintf(target, "POP R1\n");
			fprintf(target, "POP R1\n");
			fprintf(target, "POP R1\n");
			return regNo;
		}
		else if(t->nodetype==3)
		{
			return regNo;
		}
		else if(t->nodetype==4)
		{
			if(t->left->expr_type!=t->right->expr_type)
                        {	
                                printf("ERROR type-mismatch3");
                                exit(0);
                        }
                        if(t->left->expr_type==1){
				if(t->right->type==1)
				{
					fprintf(target,"MOV R0,[%d]\n",j);
					fprintf(target,"MOV [%d], R0\n",i);
				}
				else
				{
					fprintf(target,"MOV [%d],R%d\n",i,j);
					regNo--;
				}
			}
			else if(t->left->expr_type==2)
			{
				if(t->right->type==1)
				{
					fprintf(target,"MOV R0,[%d]\n",j);
					fprintf(target,"MOV [%d], R0\n",i);
				}
				else
				{
					fprintf(target,"MOV [%d],\"%s\"\n",i,t->right->varname);
				}
			}
			return regNo;
		}
		else if(t->nodetype==5)
		{
			if(t->left->expr_type!=1||t->right->expr_type!=1)
                        {
                                printf("ERROR type-mismatch4");
                                exit(0);
                        }
			if(t->right->type==1)
			{
				if(t->left->type==1)
				{
					fprintf(target, "MOV R%d, [%d]\n",regNo,i);
					fprintf(target, "MOV R0, [%d]\n",j);
					fprintf(target, "ADD R%d, R0\n",regNo);
					regNo++;
					return regNo-1;
				}
				else
				{
                                        fprintf(target, "MOV R0, [%d]\n",j);
                                        fprintf(target, "ADD R%d, R0\n",i);
                                        return i;
				}

			}
			else
			{
				if(t->left->type==1)
                                {
                                        fprintf(target, "MOV R0, [%d]\n",i);
                                        fprintf(target, "ADD R%d, R0\n",j);
                                        return j;
                                }
                                else
                                {
                                        fprintf(target, "ADD R%d, R%d\n",i,j);
					regNo--;
                                        return i;
                                }

			}
		}
		else if(t->nodetype==6)
		{
			if(t->left->expr_type!=1||t->right->expr_type!=1)
                        {
                                printf("ERROR type-mismatch4");
                                exit(0);
                        }
            		if(t->right->type==1)
                        {
                                if(t->left->type==1)
                                {
                                        fprintf(target, "MOV R%d, [%d]\n",regNo,i);
                                        fprintf(target, "MOV R0, [%d]\n",j);
                                        fprintf(target, "SUB R%d, R0\n",regNo);
                                        regNo++;
                                        return regNo-1;
                                }
                                else
                                {
                                        fprintf(target, "MOV R0, [%d]\n",j);
                                        fprintf(target, "SUB R%d, R0\n",i);
                                        return i;
                                }
                                
                        }
                        else
                        {
                                if(t->left->type==1)
                                {
                                        fprintf(target, "MOV R0, [%d]\n",i);
                                        fprintf(target, "SUB R%d, R0\n",j);
                                        return j;
                                }
                                else
                                {
                                        fprintf(target, "SUB R%d, R%d\n",i,j);
                                        regNo--;
                                        return i;
                                }

                        }

		}
		else if(t->nodetype==7)
		{
			if(t->left->expr_type!=1||t->right->expr_type!=1)
                        {
                                printf("ERROR type-mismatch4");
                                exit(0);
                        }
           		if(t->right->type==1)
                        {
                                if(t->left->type==1)
                                {
                                        fprintf(target, "MOV R%d, [%d]\n",regNo,i);
                                        fprintf(target, "MOV R0, [%d]\n",j);
                                        fprintf(target, "MUL R%d, R0\n",regNo);
                                        regNo++;
                                        return regNo-1;
                                }
                                else
                                {
                                        fprintf(target, "MOV R0, [%d]\n",j);
                                        fprintf(target, "MUL R%d, R0\n",i);
                                        return i;
                                }
                                
                        }
                        else
                        {
                                if(t->left->type==1)
                                {
                                        fprintf(target, "MOV R0, [%d]\n",i);
                                        fprintf(target, "MUL R%d, R0\n",j);
                                        return j;
                                }
                                else
                                {
                                        fprintf(target, "MUL R%d, R%d\n",i,j);
                                        regNo--;
                                        return i;
                                }

                        }

		}
		else if(t->nodetype==8)
		{
			if(t->left->expr_type!=1||t->right->expr_type!=1)
                        {
                                printf("ERROR type-mismatch4");
                                exit(0);
                        }
            		if(t->right->type==1)
                        {
                                if(t->left->type==1)
                                {
                                        fprintf(target, "MOV R%d, [%d]\n",regNo,i);
                                        fprintf(target, "MOV R0, [%d]\n",j);
                                        fprintf(target, "DIV R%d, R0\n",regNo);
                                        regNo++;
                                        return regNo-1;
                                }
                                else
                                {
                                        fprintf(target, "MOV R0, [%d]\n",j);
                                        fprintf(target, "DIV R%d, R0\n",i);
                                        return i;
                                }
                                
                        }
                        else
                        {
                                if(t->left->type==1)
                                {
                                        fprintf(target, "MOV R0, [%d]\n",i);
                                        fprintf(target, "DIV R%d, R0\n",j);
                                        return j;
                                }
                                else
                                {
                                        fprintf(target, "DIV R%d, R%d\n",i,j);
                                        regNo--;
                                        return i;
                                }

                        }

		}
		else if(t->nodetype==15)
		{
			if(t->left->expr_type!=0)
			{
				printf("ERROR-TYPE MISMATCH8\n");
				exit(0);
			}
			

			i=codeGen(t->left,target);
			k1=labelno++;
			if(t->third)
			{
				k2=labelno++;
				fprintf(target, "JZ R%d, L%d\n",i,k2);
			}
			else
				fprintf(target, "JZ R%d, L%d\n",i,k1);
			codeGen(t->right,target);
			fprintf(target, "JMP L%d\n",k1);
			
			if(t->third)
			{
				fprintf(target,"L%d:\n",k2);
				codeGen(t->third,target);
			}
			fprintf(target, "JMP L%d\n",k1);
			fprintf(target,"L%d:\n",k1);
			return regNo;
		}
		else if(t->nodetype==16)
		{
			//printf("%d ",t->left->expr_type);
			if(t->left->expr_type!=0)
                        {
                                printf("ERROR-TYPE MISMATCH8\n");
                                exit(0);
                        }
			fprintf(target,"L%d:\n",labelno++);
			k=labelno;
			labelno++;
			i=codeGen(t->left,target);
			fprintf(target, "JZ R%d, L%d\n",i,k);
			codeGen(t->right,target);
			fprintf(target,"JMP L%d\n",k-1);
			fprintf(target, "L%d:\n",k);
			k=-1;
			return regNo;
		}
		else
		{
			if(t->left->expr_type!=1||t->right->expr_type!=1)
                        {
                                printf("ERROR type-mismatch9");
                                exit(0);
                        }

			if(t->left->type==1)
			{
				fprintf(target, "MOV R%d, [%d]\n",regNo,i);
			}
			else
			{
				fprintf(target, "MOV R%d, R%d\n",regNo, i);
			}
			if(t->right->type==1)
			{
				fprintf(target, "MOV R0, [%d]\n",j);
			}
			else
				fprintf(target, "MOV R0, R%d\n",j);
				
				
			if(t->nodetype==9)
				fprintf(target, "LT R%d, R0\n",regNo);
			else if(t->nodetype==10)
				fprintf(target, "GT R%d, R0\n",regNo);
			else if(t->nodetype==11)
				fprintf(target, "LE R%d, R0\n",regNo);
			else if(t->nodetype==12)
				fprintf(target, "GE R%d, R0\n",regNo);
			else if(t->nodetype==13)
				fprintf(target, "NE R%d, R0\n",regNo);
			else if(t->nodetype==14)
				fprintf(target, "EQ R%d, R0\n",regNo);
			
			regNo++;
			return (regNo-1);
		}
	}
}


