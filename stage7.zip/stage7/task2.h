struct Classtable{
	char *Name;	//name of the class
	struct Fieldlist *Memberfield;   //pointer to Fieldlist
	struct Memberfunclist *Vfuncptr;  // pointer to Memberfunclist
	struct Classtable *Parentptr;  //pointer to the parent's class table
	int Class_index; //position of the class in the virtual function table
	int Fieldcount;  //count of fields
	int Methodcount; //count of methods
	struct Classtable *Next; //pointer to next class table entry
}Classtable;

typedef struct Gsymbol{
	char *name; //name of the variable or function
	struct Typetable *type; //return type of the function
	struct Classtable *Ctype; //the field to store pointer from class table
	int size; //size of an array 
	int binding; //static binding of global variables
	struct Paramstruct *paramlist; //pointer to the head of the formal list
	int flabel; // a label for identifying the starting address of a function's code
	struct Gsymbol *next; //points to the next Global Symbol Table
}Gsymbol;

typedef struct Lsymbol{
	char *name; // name of the variable
	struct Typetable *type;  //type of the variable: (Integer /String)
	int binding; //local binding of the variable
	struct Lsymbol *next; //points to the next Local Symbol Table entry
}Lsymbol;

typedef struct Paramstruct{
	char *name; //name of the parameter
	char* type; //type of the parameter
	struct ASTNode *val;
	struct Paramstruct *next; //points to the next paramter list entry
}Paramstruct;

typedef struct Typetable{
	char *name;   //type name
	int size;	//size of the type
	struct Fieldlist *fields; //pointer to the head of fields list
	struct Typetable *next; //pointer to the next type table entry
}Typetable;	

struct Fieldlist{
	char *name;  //name of the field
	int fieldIndex;  //the position of the field in the field list
	struct Typetable *type;  //pointer to the type entry of the field's type
	struct Classtable *Ctype; //pointer to the class containing the field
	struct Fieldlist *next;  //pointer to the next field
}Fieldlist;

struct Memberfunclist	{
	char *name;	//name of the member function in the class
	struct Typetable *type;  //pointer to typetable
	struct Paramstruct *paramlist;  //pointer to the head of the formal paramter list
	int Funcposition;	//position of the function in the class table
	int Flabel;		//A label for identifying the starting address of the function's code in the memory
	struct Memberfunclist *next;    //pointer to next Memberfunclist entry
}Memberfunclist;

// nodetype 1-read
// 	     2-write
// 	     3-connector
// 	     4- '='
// 	     5- '+'
// 	     6- '-'
// 	     7- '*'
// 	     8- '/'
//	     9- LT
//	     10-GT
//	     11- LE
//           12- GE
//	      13- NE
//		14- EQ
//		15- IF_ELSE_THEN
//		16- WHILE
//		17-OR
//		18-AND
//		19-MODULUS
//		20-ALLOC
//		21- FREE
//		22- INITIALIZE
//type  0- num
//	1-ID
//	2-nonleaf
//	3-break
//	4-continue
//	5-string
//	6-FUNCTION
//	7-array element
//	8-FIELD
//	9- NULL
//	10-fieldfunction
//	11-NEW OBJECT

//expr_type bool
//	     int
//	      str
//           typeless


typedef struct ASTNode{
 int val; //value of a number for NUM nodes
 int type; //type of variable
 char *varname; //name of a variable for ID nodes
 int nodetype; //information about non-leaf nodes -read/write/connector/+/- etc
 char* expr_type; //information about type of expression ex- arithmetic, boolean, typeless
 struct ASTNode *left,*right,*third; //left and right branches
 struct Gsymbol *Gentry; //pointer to GST entry for global variables and functions
 struct Lsymbol *Lentry; //pointer to the function's LST for local variables and arguments
 struct Paramstruct *paramlist; //pointer to the parameter list given as argument to a function call
}ASTNode;

void GInstall(struct Gsymbol **GTable,char *name, struct Typetable *type, int size,int binding,struct Paramstruct *paramlist,int flabel);
struct Gsymbol *GLookup(struct Gsymbol *Table,char *name);
struct ASTNode* createTree(int val,int type,int nodetype,char* expr_type,struct ASTNode *l,struct ASTNode *r,struct ASTNode *t);
struct ASTNode* createID(int val,int type, char *varname,int nodetype,char* expr_type,struct Gsymbol *Gentry,struct ASTNode *l,struct ASTNode *r,struct ASTNode *t,struct Paramstruct *paramlist);
int get_Address(FILE *target,struct ASTNode * t);
void codeGen(struct ASTNode *t, FILE *target, int break_label, int continue_label);
int funct_codeGen(struct ASTNode *t, FILE *target);
int expression_codeGen(struct ASTNode *t,FILE *target);
int check_Reserved(char * Keywords[21], char * variable);
struct Typetable* TypeTableCreate();
struct Typetable *TLookup(struct Typetable *T_Table,char *name);
struct Fieldlist *FLookup(struct Fieldlist *F_list,char *name);
struct Lsymbol *Lookup(struct Lsymbol *LTable,char *name);
struct Paramstruct *PLookup(struct Paramstruct *pml,char *name);
void LInstall(struct Lsymbol **LTable,char *name, struct Typetable *type,int binding);
int check_func_param(struct Paramstruct *head1, struct Paramstruct *head2);
int check_func_arg(struct Paramstruct *head1, struct Paramstruct *head2);
void read_codeGen(struct ASTNode*t, FILE *target);
void write_codeGen(struct ASTNode*t, FILE *target);
void push_arg_in_stack(struct Paramstruct * root, FILE *target);
void assg_codeGen(struct ASTNode*t, FILE *target);
int bool_codeGen(struct ASTNode *t, FILE *target);
void while_codeGen(struct ASTNode *t, FILE *target);
void if_else_codeGen(struct ASTNode * t, FILE *target,int break_label, int continue_label);
void return_codeGen(FILE *target, struct ASTNode *t);
void TInstall(struct Typetable ** T_Table,char *name);
struct Classtable * CInstall(struct Classtable** CTable,char *name,char *parent_class_name);
struct Classtable *CLookup(struct Classtable* CTable, char *name);
void Class_Finstall(struct Classtable *Cptr,struct Classtable *c_temp,struct Typetable *ttableptr,char *name,int f_position);
void Class_Minstall(struct Classtable *Cptr,char *name,struct Typetable *type,struct Paramstruct *Paramlist,int m_position,int a);
struct Memberfunclist *Class_Mlookup(struct Classtable *Ctype,char *Name);
struct Fieldlist * Class_Flookup(struct Classtable *Ctype,char *Name);


