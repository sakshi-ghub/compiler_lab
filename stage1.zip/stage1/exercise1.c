struct tnode* makeLeafNode(int n)
{
    struct tnode *temp;
    temp = (struct tnode*)malloc(sizeof(struct tnode));
    temp->op = NULL;
    temp->val = n;
    temp->left = NULL;
    temp->right = NULL;
    return temp;
}

struct tnode* makeOperatorNode(char c,struct tnode *l,struct tnode *r){
    struct tnode *temp;
    temp = (struct tnode*)malloc(sizeof(struct tnode));
    temp->op = malloc(sizeof(char));
    *(temp->op) = c;
    temp->left = l;
    temp->right = r;
    return temp;
}

void evaluate_pre(struct tnode *t){
	if(t==NULL)
	{ return;}

    if(t->op == NULL)
    {
        printf("%d ",t->val);
    }
    else
    {
 	printf("%c ", *t->op);
    }
    evaluate_pre(t->left);
    evaluate_pre(t->right);

}


void evaluate_post(struct tnode *t){
        if(t==NULL)
        { return;}


    evaluate_post(t->left);
    evaluate_post(t->right);

    if(t->op == NULL)
    {
        printf("%d ",t->val);
    }
    else
    {
        printf("%c ", *t->op);
    }

}

int codeGen(struct tnode *t,FILE *target){
	int i,j;
	if(t==NULL)
		return 0;
	static int regNo;
	if(regNo>19)
	{
		printf("Out of registers\n");
		exit(0);
	}
	if(t->op==NULL)
	{
		fprintf(target, "MOV R%d, %d\n",regNo++,t->val);
		return (regNo-1);
	}
	else
	{
		i=codeGen(t->left,target);
		j=codeGen(t->right,target);
		fprintf(target, "ADD R%d, R%d\n",i,j);
		regNo--;
		return i;
	}
}


