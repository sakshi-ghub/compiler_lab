/* A Bison parser, made by GNU Bison 3.5.1.  */

/* Bison implementation for Yacc-like parsers in C

   Copyright (C) 1984, 1989-1990, 2000-2015, 2018-2020 Free Software Foundation,
   Inc.

   This program is free software: you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation, either version 3 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program.  If not, see <http://www.gnu.org/licenses/>.  */

/* As a special exception, you may create a larger work that contains
   part or all of the Bison parser skeleton and distribute that work
   under terms of your choice, so long as that work isn't itself a
   parser generator using the skeleton or a modified version thereof
   as a parser skeleton.  Alternatively, if you modify or redistribute
   the parser skeleton itself, you may (at your option) remove this
   special exception, which will cause the skeleton and the resulting
   Bison output files to be licensed under the GNU General Public
   License without this special exception.

   This special exception was added by the Free Software Foundation in
   version 2.2 of Bison.  */

/* C LALR(1) parser skeleton written by Richard Stallman, by
   simplifying the original so-called "semantic" parser.  */

/* All symbols defined below should begin with yy or YY, to avoid
   infringing on user name space.  This should be done even for local
   variables, as they might otherwise be expanded by user macros.
   There are some unavoidable exceptions within include files to
   define necessary library symbols; they are noted "INFRINGES ON
   USER NAME SPACE" below.  */

/* Undocumented macros, especially those whose name start with YY_,
   are private implementation details.  Do not rely on them.  */

/* Identify Bison output.  */
#define YYBISON 1

/* Bison version.  */
#define YYBISON_VERSION "3.5.1"

/* Skeleton name.  */
#define YYSKELETON_NAME "yacc.c"

/* Pure parsers.  */
#define YYPURE 0

/* Push parsers.  */
#define YYPUSH 0

/* Pull parsers.  */
#define YYPULL 1




/* First part of user prologue.  */
#line 1 "task1.y"

	#include<stdlib.h>
	#include<stdio.h>
	#include<string.h>
	#include "task1.h"
	#include "task1.c"
	int yylex(void);
	extern FILE *yyin;
	int lbinding=1;
	int position=0;
	int f_position=0;
	int m_position=0;
	extern int yylineno;
	int yyerror(char const *s);
	int Class_index=0;
	FILE * target;
	int GLabel;
	int temp_address=1;
	

#line 91 "y.tab.c"

# ifndef YY_CAST
#  ifdef __cplusplus
#   define YY_CAST(Type, Val) static_cast<Type> (Val)
#   define YY_REINTERPRET_CAST(Type, Val) reinterpret_cast<Type> (Val)
#  else
#   define YY_CAST(Type, Val) ((Type) (Val))
#   define YY_REINTERPRET_CAST(Type, Val) ((Type) (Val))
#  endif
# endif
# ifndef YY_NULLPTR
#  if defined __cplusplus
#   if 201103L <= __cplusplus
#    define YY_NULLPTR nullptr
#   else
#    define YY_NULLPTR 0
#   endif
#  else
#   define YY_NULLPTR ((void*)0)
#  endif
# endif

/* Enabling verbose error messages.  */
#ifdef YYERROR_VERBOSE
# undef YYERROR_VERBOSE
# define YYERROR_VERBOSE 1
#else
# define YYERROR_VERBOSE 0
#endif

/* Use api.header.include to #include this header
   instead of duplicating it here.  */
#ifndef YY_YY_Y_TAB_H_INCLUDED
# define YY_YY_Y_TAB_H_INCLUDED
/* Debug traces.  */
#ifndef YYDEBUG
# define YYDEBUG 0
#endif
#if YYDEBUG
extern int yydebug;
#endif

/* Token type.  */
#ifndef YYTOKENTYPE
# define YYTOKENTYPE
  enum yytokentype
  {
    ID = 258,
    NUM = 259,
    INT = 260,
    STR = 261,
    SEMICOLON = 262,
    COMMA = 263,
    ASGN = 264,
    ALLOC = 265,
    FREE = 266,
    READ = 267,
    WRITE = 268,
    IF = 269,
    THEN = 270,
    ELSE = 271,
    ENDIF = 272,
    PLUS = 273,
    MINUS = 274,
    MUL = 275,
    DIV = 276,
    MAIN = 277,
    DECL = 278,
    ENDDECL = 279,
    BEGINE = 280,
    END = 281,
    STRING = 282,
    RETURN = 283,
    LT = 284,
    GT = 285,
    LE = 286,
    GE = 287,
    EQ = 288,
    NE = 289,
    DOT = 290,
    WHILE = 291,
    DO = 292,
    ENDWHILE = 293,
    BREAK = 294,
    CONTINUE = 295,
    MOD = 296,
    TYPE = 297,
    ENDTYPE = 298,
    null = 299,
    INITIALIZE = 300,
    CLASS = 301,
    ENDCLASS = 302,
    SELF = 303,
    NEW = 304,
    Extends = 305,
    OR = 306,
    AND = 307
  };
#endif
/* Tokens.  */
#define ID 258
#define NUM 259
#define INT 260
#define STR 261
#define SEMICOLON 262
#define COMMA 263
#define ASGN 264
#define ALLOC 265
#define FREE 266
#define READ 267
#define WRITE 268
#define IF 269
#define THEN 270
#define ELSE 271
#define ENDIF 272
#define PLUS 273
#define MINUS 274
#define MUL 275
#define DIV 276
#define MAIN 277
#define DECL 278
#define ENDDECL 279
#define BEGINE 280
#define END 281
#define STRING 282
#define RETURN 283
#define LT 284
#define GT 285
#define LE 286
#define GE 287
#define EQ 288
#define NE 289
#define DOT 290
#define WHILE 291
#define DO 292
#define ENDWHILE 293
#define BREAK 294
#define CONTINUE 295
#define MOD 296
#define TYPE 297
#define ENDTYPE 298
#define null 299
#define INITIALIZE 300
#define CLASS 301
#define ENDCLASS 302
#define SELF 303
#define NEW 304
#define Extends 305
#define OR 306
#define AND 307

/* Value type.  */
#if ! defined YYSTYPE && ! defined YYSTYPE_IS_DECLARED
union YYSTYPE
{
#line 22 "task1.y"

	char *string;
	int a;
	struct Paramstruct *Pl;
	struct ASTNode *no;
	struct Fieldlist *Fl;

#line 255 "y.tab.c"

};
typedef union YYSTYPE YYSTYPE;
# define YYSTYPE_IS_TRIVIAL 1
# define YYSTYPE_IS_DECLARED 1
#endif


extern YYSTYPE yylval;

int yyparse (void);

#endif /* !YY_YY_Y_TAB_H_INCLUDED  */



#ifdef short
# undef short
#endif

/* On compilers that do not define __PTRDIFF_MAX__ etc., make sure
   <limits.h> and (if available) <stdint.h> are included
   so that the code can choose integer types of a good width.  */

#ifndef __PTRDIFF_MAX__
# include <limits.h> /* INFRINGES ON USER NAME SPACE */
# if defined __STDC_VERSION__ && 199901 <= __STDC_VERSION__
#  include <stdint.h> /* INFRINGES ON USER NAME SPACE */
#  define YY_STDINT_H
# endif
#endif

/* Narrow types that promote to a signed type and that can represent a
   signed or unsigned integer of at least N bits.  In tables they can
   save space and decrease cache pressure.  Promoting to a signed type
   helps avoid bugs in integer arithmetic.  */

#ifdef __INT_LEAST8_MAX__
typedef __INT_LEAST8_TYPE__ yytype_int8;
#elif defined YY_STDINT_H
typedef int_least8_t yytype_int8;
#else
typedef signed char yytype_int8;
#endif

#ifdef __INT_LEAST16_MAX__
typedef __INT_LEAST16_TYPE__ yytype_int16;
#elif defined YY_STDINT_H
typedef int_least16_t yytype_int16;
#else
typedef short yytype_int16;
#endif

#if defined __UINT_LEAST8_MAX__ && __UINT_LEAST8_MAX__ <= __INT_MAX__
typedef __UINT_LEAST8_TYPE__ yytype_uint8;
#elif (!defined __UINT_LEAST8_MAX__ && defined YY_STDINT_H \
       && UINT_LEAST8_MAX <= INT_MAX)
typedef uint_least8_t yytype_uint8;
#elif !defined __UINT_LEAST8_MAX__ && UCHAR_MAX <= INT_MAX
typedef unsigned char yytype_uint8;
#else
typedef short yytype_uint8;
#endif

#if defined __UINT_LEAST16_MAX__ && __UINT_LEAST16_MAX__ <= __INT_MAX__
typedef __UINT_LEAST16_TYPE__ yytype_uint16;
#elif (!defined __UINT_LEAST16_MAX__ && defined YY_STDINT_H \
       && UINT_LEAST16_MAX <= INT_MAX)
typedef uint_least16_t yytype_uint16;
#elif !defined __UINT_LEAST16_MAX__ && USHRT_MAX <= INT_MAX
typedef unsigned short yytype_uint16;
#else
typedef int yytype_uint16;
#endif

#ifndef YYPTRDIFF_T
# if defined __PTRDIFF_TYPE__ && defined __PTRDIFF_MAX__
#  define YYPTRDIFF_T __PTRDIFF_TYPE__
#  define YYPTRDIFF_MAXIMUM __PTRDIFF_MAX__
# elif defined PTRDIFF_MAX
#  ifndef ptrdiff_t
#   include <stddef.h> /* INFRINGES ON USER NAME SPACE */
#  endif
#  define YYPTRDIFF_T ptrdiff_t
#  define YYPTRDIFF_MAXIMUM PTRDIFF_MAX
# else
#  define YYPTRDIFF_T long
#  define YYPTRDIFF_MAXIMUM LONG_MAX
# endif
#endif

#ifndef YYSIZE_T
# ifdef __SIZE_TYPE__
#  define YYSIZE_T __SIZE_TYPE__
# elif defined size_t
#  define YYSIZE_T size_t
# elif defined __STDC_VERSION__ && 199901 <= __STDC_VERSION__
#  include <stddef.h> /* INFRINGES ON USER NAME SPACE */
#  define YYSIZE_T size_t
# else
#  define YYSIZE_T unsigned
# endif
#endif

#define YYSIZE_MAXIMUM                                  \
  YY_CAST (YYPTRDIFF_T,                                 \
           (YYPTRDIFF_MAXIMUM < YY_CAST (YYSIZE_T, -1)  \
            ? YYPTRDIFF_MAXIMUM                         \
            : YY_CAST (YYSIZE_T, -1)))

#define YYSIZEOF(X) YY_CAST (YYPTRDIFF_T, sizeof (X))

/* Stored state numbers (used for stacks). */
typedef yytype_int16 yy_state_t;

/* State numbers in computations.  */
typedef int yy_state_fast_t;

#ifndef YY_
# if defined YYENABLE_NLS && YYENABLE_NLS
#  if ENABLE_NLS
#   include <libintl.h> /* INFRINGES ON USER NAME SPACE */
#   define YY_(Msgid) dgettext ("bison-runtime", Msgid)
#  endif
# endif
# ifndef YY_
#  define YY_(Msgid) Msgid
# endif
#endif

#ifndef YY_ATTRIBUTE_PURE
# if defined __GNUC__ && 2 < __GNUC__ + (96 <= __GNUC_MINOR__)
#  define YY_ATTRIBUTE_PURE __attribute__ ((__pure__))
# else
#  define YY_ATTRIBUTE_PURE
# endif
#endif

#ifndef YY_ATTRIBUTE_UNUSED
# if defined __GNUC__ && 2 < __GNUC__ + (7 <= __GNUC_MINOR__)
#  define YY_ATTRIBUTE_UNUSED __attribute__ ((__unused__))
# else
#  define YY_ATTRIBUTE_UNUSED
# endif
#endif

/* Suppress unused-variable warnings by "using" E.  */
#if ! defined lint || defined __GNUC__
# define YYUSE(E) ((void) (E))
#else
# define YYUSE(E) /* empty */
#endif

#if defined __GNUC__ && ! defined __ICC && 407 <= __GNUC__ * 100 + __GNUC_MINOR__
/* Suppress an incorrect diagnostic about yylval being uninitialized.  */
# define YY_IGNORE_MAYBE_UNINITIALIZED_BEGIN                            \
    _Pragma ("GCC diagnostic push")                                     \
    _Pragma ("GCC diagnostic ignored \"-Wuninitialized\"")              \
    _Pragma ("GCC diagnostic ignored \"-Wmaybe-uninitialized\"")
# define YY_IGNORE_MAYBE_UNINITIALIZED_END      \
    _Pragma ("GCC diagnostic pop")
#else
# define YY_INITIAL_VALUE(Value) Value
#endif
#ifndef YY_IGNORE_MAYBE_UNINITIALIZED_BEGIN
# define YY_IGNORE_MAYBE_UNINITIALIZED_BEGIN
# define YY_IGNORE_MAYBE_UNINITIALIZED_END
#endif
#ifndef YY_INITIAL_VALUE
# define YY_INITIAL_VALUE(Value) /* Nothing. */
#endif

#if defined __cplusplus && defined __GNUC__ && ! defined __ICC && 6 <= __GNUC__
# define YY_IGNORE_USELESS_CAST_BEGIN                          \
    _Pragma ("GCC diagnostic push")                            \
    _Pragma ("GCC diagnostic ignored \"-Wuseless-cast\"")
# define YY_IGNORE_USELESS_CAST_END            \
    _Pragma ("GCC diagnostic pop")
#endif
#ifndef YY_IGNORE_USELESS_CAST_BEGIN
# define YY_IGNORE_USELESS_CAST_BEGIN
# define YY_IGNORE_USELESS_CAST_END
#endif


#define YY_ASSERT(E) ((void) (0 && (E)))

#if ! defined yyoverflow || YYERROR_VERBOSE

/* The parser invokes alloca or malloc; define the necessary symbols.  */

# ifdef YYSTACK_USE_ALLOCA
#  if YYSTACK_USE_ALLOCA
#   ifdef __GNUC__
#    define YYSTACK_ALLOC __builtin_alloca
#   elif defined __BUILTIN_VA_ARG_INCR
#    include <alloca.h> /* INFRINGES ON USER NAME SPACE */
#   elif defined _AIX
#    define YYSTACK_ALLOC __alloca
#   elif defined _MSC_VER
#    include <malloc.h> /* INFRINGES ON USER NAME SPACE */
#    define alloca _alloca
#   else
#    define YYSTACK_ALLOC alloca
#    if ! defined _ALLOCA_H && ! defined EXIT_SUCCESS
#     include <stdlib.h> /* INFRINGES ON USER NAME SPACE */
      /* Use EXIT_SUCCESS as a witness for stdlib.h.  */
#     ifndef EXIT_SUCCESS
#      define EXIT_SUCCESS 0
#     endif
#    endif
#   endif
#  endif
# endif

# ifdef YYSTACK_ALLOC
   /* Pacify GCC's 'empty if-body' warning.  */
#  define YYSTACK_FREE(Ptr) do { /* empty */; } while (0)
#  ifndef YYSTACK_ALLOC_MAXIMUM
    /* The OS might guarantee only one guard page at the bottom of the stack,
       and a page size can be as small as 4096 bytes.  So we cannot safely
       invoke alloca (N) if N exceeds 4096.  Use a slightly smaller number
       to allow for a few compiler-allocated temporary stack slots.  */
#   define YYSTACK_ALLOC_MAXIMUM 4032 /* reasonable circa 2006 */
#  endif
# else
#  define YYSTACK_ALLOC YYMALLOC
#  define YYSTACK_FREE YYFREE
#  ifndef YYSTACK_ALLOC_MAXIMUM
#   define YYSTACK_ALLOC_MAXIMUM YYSIZE_MAXIMUM
#  endif
#  if (defined __cplusplus && ! defined EXIT_SUCCESS \
       && ! ((defined YYMALLOC || defined malloc) \
             && (defined YYFREE || defined free)))
#   include <stdlib.h> /* INFRINGES ON USER NAME SPACE */
#   ifndef EXIT_SUCCESS
#    define EXIT_SUCCESS 0
#   endif
#  endif
#  ifndef YYMALLOC
#   define YYMALLOC malloc
#   if ! defined malloc && ! defined EXIT_SUCCESS
void *malloc (YYSIZE_T); /* INFRINGES ON USER NAME SPACE */
#   endif
#  endif
#  ifndef YYFREE
#   define YYFREE free
#   if ! defined free && ! defined EXIT_SUCCESS
void free (void *); /* INFRINGES ON USER NAME SPACE */
#   endif
#  endif
# endif
#endif /* ! defined yyoverflow || YYERROR_VERBOSE */


#if (! defined yyoverflow \
     && (! defined __cplusplus \
         || (defined YYSTYPE_IS_TRIVIAL && YYSTYPE_IS_TRIVIAL)))

/* A type that is properly aligned for any stack member.  */
union yyalloc
{
  yy_state_t yyss_alloc;
  YYSTYPE yyvs_alloc;
};

/* The size of the maximum gap between one aligned stack and the next.  */
# define YYSTACK_GAP_MAXIMUM (YYSIZEOF (union yyalloc) - 1)

/* The size of an array large to enough to hold all stacks, each with
   N elements.  */
# define YYSTACK_BYTES(N) \
     ((N) * (YYSIZEOF (yy_state_t) + YYSIZEOF (YYSTYPE)) \
      + YYSTACK_GAP_MAXIMUM)

# define YYCOPY_NEEDED 1

/* Relocate STACK from its old location to the new one.  The
   local variables YYSIZE and YYSTACKSIZE give the old and new number of
   elements in the stack, and YYPTR gives the new location of the
   stack.  Advance YYPTR to a properly aligned location for the next
   stack.  */
# define YYSTACK_RELOCATE(Stack_alloc, Stack)                           \
    do                                                                  \
      {                                                                 \
        YYPTRDIFF_T yynewbytes;                                         \
        YYCOPY (&yyptr->Stack_alloc, Stack, yysize);                    \
        Stack = &yyptr->Stack_alloc;                                    \
        yynewbytes = yystacksize * YYSIZEOF (*Stack) + YYSTACK_GAP_MAXIMUM; \
        yyptr += yynewbytes / YYSIZEOF (*yyptr);                        \
      }                                                                 \
    while (0)

#endif

#if defined YYCOPY_NEEDED && YYCOPY_NEEDED
/* Copy COUNT objects from SRC to DST.  The source and destination do
   not overlap.  */
# ifndef YYCOPY
#  if defined __GNUC__ && 1 < __GNUC__
#   define YYCOPY(Dst, Src, Count) \
      __builtin_memcpy (Dst, Src, YY_CAST (YYSIZE_T, (Count)) * sizeof (*(Src)))
#  else
#   define YYCOPY(Dst, Src, Count)              \
      do                                        \
        {                                       \
          YYPTRDIFF_T yyi;                      \
          for (yyi = 0; yyi < (Count); yyi++)   \
            (Dst)[yyi] = (Src)[yyi];            \
        }                                       \
      while (0)
#  endif
# endif
#endif /* !YYCOPY_NEEDED */

/* YYFINAL -- State number of the termination state.  */
#define YYFINAL  5
/* YYLAST -- Last index in YYTABLE.  */
#define YYLAST   579

/* YYNTOKENS -- Number of terminals.  */
#define YYNTOKENS  59
/* YYNNTS -- Number of nonterminals.  */
#define YYNNTS  52
/* YYNRULES -- Number of rules.  */
#define YYNRULES  125
/* YYNSTATES -- Number of states.  */
#define YYNSTATES  279

#define YYUNDEFTOK  2
#define YYMAXUTOK   307


/* YYTRANSLATE(TOKEN-NUM) -- Symbol number corresponding to TOKEN-NUM
   as returned by yylex, with out-of-bounds checking.  */
#define YYTRANSLATE(YYX)                                                \
  (0 <= (YYX) && (YYX) <= YYMAXUTOK ? yytranslate[YYX] : YYUNDEFTOK)

/* YYTRANSLATE[TOKEN-NUM] -- Symbol number corresponding to TOKEN-NUM
   as returned by yylex.  */
static const yytype_int8 yytranslate[] =
{
       0,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
      55,    56,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,    57,     2,    58,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,    53,     2,    54,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     1,     2,     3,     4,
       5,     6,     7,     8,     9,    10,    11,    12,    13,    14,
      15,    16,    17,    18,    19,    20,    21,    22,    23,    24,
      25,    26,    27,    28,    29,    30,    31,    32,    33,    34,
      35,    36,    37,    38,    39,    40,    41,    42,    43,    44,
      45,    46,    47,    48,    49,    50,    51,    52
};

#if YYDEBUG
  /* YYRLINE[YYN] -- Source line where rule number YYN was defined.  */
static const yytype_int16 yyrline[] =
{
       0,    44,    44,    44,    44,    48,    48,    72,    75,    76,
      79,    79,   100,   124,   127,   156,   201,   204,   205,   208,
     231,   232,   243,   244,   255,   280,   281,   284,   325,   328,
     328,   375,   378,   379,   382,   382,   392,   393,   396,   432,
     458,   485,   510,   511,   514,   528,   529,   532,   572,   532,
     575,   575,   582,   585,   588,   589,   592,   622,   650,   655,
     656,   658,   663,   664,   665,   666,   668,   673,   674,   675,
     677,   694,   696,   713,   715,   732,   734,   772,   795,   796,
     797,   798,   799,   800,   801,   802,   830,   861,   862,   863,
     864,   865,   866,   867,   868,   869,   870,   871,   872,   875,
     929,   988,  1013,  1031,  1058,  1079,  1112,  1136,  1163,  1174,
    1189,  1193,  1195,  1205,  1193,  1208,  1241,  1273,  1304,  1305,
    1308,  1324,  1341,  1360,  1361,  1362
};
#endif

#if YYDEBUG || YYERROR_VERBOSE || 0
/* YYTNAME[SYMBOL-NUM] -- String name of the symbol SYMBOL-NUM.
   First, the terminals, then, starting at YYNTOKENS, nonterminals.  */
static const char *const yytname[] =
{
  "$end", "error", "$undefined", "ID", "NUM", "INT", "STR", "SEMICOLON",
  "COMMA", "ASGN", "ALLOC", "FREE", "READ", "WRITE", "IF", "THEN", "ELSE",
  "ENDIF", "PLUS", "MINUS", "MUL", "DIV", "MAIN", "DECL", "ENDDECL",
  "BEGINE", "END", "STRING", "RETURN", "LT", "GT", "LE", "GE", "EQ", "NE",
  "DOT", "WHILE", "DO", "ENDWHILE", "BREAK", "CONTINUE", "MOD", "TYPE",
  "ENDTYPE", "null", "INITIALIZE", "CLASS", "ENDCLASS", "SELF", "NEW",
  "Extends", "OR", "AND", "'{'", "'}'", "'('", "')'", "'['", "']'",
  "$accept", "Program", "$@1", "$@2", "TypeDefBlock", "$@3", "TypeDefList",
  "TypeDef", "$@4", "FieldDeclList", "FieldDecl", "ClassDefBlock",
  "ClassDefList", "ClassDef", "Cname", "Fieldlists", "Fld", "MethodDecl",
  "MDecl", "MethodDefns", "GDeclBlock", "$@5", "GDeclList", "GDecl", "$@6",
  "GidList", "Gid", "ParamList", "Param", "FDefBlock", "FDefList", "$@7",
  "$@8", "Body", "$@9", "Retstmt", "Slist", "Stmt", "Expr", "FIELD",
  "FieldFunction", "element", "ArgList", "MainBlock", "$@10", "$@11",
  "$@12", "LdeclBlock", "LDeclList", "LDecl", "IdList", "TypeName", YY_NULLPTR
};
#endif

# ifdef YYPRINT
/* YYTOKNUM[NUM] -- (External) token number corresponding to the
   (internal) symbol number NUM (which must be that of a token).  */
static const yytype_int16 yytoknum[] =
{
       0,   256,   257,   258,   259,   260,   261,   262,   263,   264,
     265,   266,   267,   268,   269,   270,   271,   272,   273,   274,
     275,   276,   277,   278,   279,   280,   281,   282,   283,   284,
     285,   286,   287,   288,   289,   290,   291,   292,   293,   294,
     295,   296,   297,   298,   299,   300,   301,   302,   303,   304,
     305,   306,   307,   123,   125,    40,    41,    91,    93
};
# endif

#define YYPACT_NINF (-210)

#define yypact_value_is_default(Yyn) \
  ((Yyn) == YYPACT_NINF)

#define YYTABLE_NINF (-1)

#define yytable_value_is_error(Yyn) \
  0

  /* YYPACT[STATE-NUM] -- Index in YYTABLE of the portion describing
     STATE-NUM.  */
static const yytype_int16 yypact[] =
{
     -10,  -210,    48,  -210,    22,  -210,    36,  -210,     7,  -210,
      90,  -210,    58,  -210,  -210,    70,    27,  -210,   110,   105,
     126,   172,  -210,  -210,   155,   126,  -210,  -210,  -210,  -210,
      18,  -210,   176,  -210,  -210,   171,  -210,  -210,   162,  -210,
    -210,   180,   126,  -210,  -210,   185,   167,  -210,  -210,   187,
    -210,  -210,   384,  -210,   188,  -210,   -42,   130,  -210,   138,
     139,  -210,  -210,   193,    12,   126,   197,  -210,   185,  -210,
     126,   150,   126,   160,  -210,   126,    69,  -210,   202,   148,
    -210,   161,   199,  -210,    83,   126,  -210,  -210,  -210,  -210,
     163,   209,  -210,   165,   168,  -210,   200,   200,   406,  -210,
    -210,  -210,   419,  -210,   219,   204,   204,  -210,  -210,  -210,
     152,   198,   178,   181,  -210,   230,  -210,   362,  -210,  -210,
    -210,    40,   189,    39,   118,    39,    39,   227,   236,   210,
     218,  -210,     0,   238,    41,   246,    39,    -2,   -24,  -210,
    -210,   215,    39,   151,   216,  -210,  -210,    25,   179,   449,
     473,  -210,  -210,   249,    39,   231,    97,   257,    75,   206,
     255,   208,   217,   207,  -210,   386,   -17,    -9,   268,   106,
     270,   421,  -210,    39,    39,    39,    39,    39,    39,    39,
      39,    39,    39,    39,    39,    39,   271,   221,  -210,  -210,
    -210,  -210,   235,  -210,   220,   272,   223,   225,   263,  -210,
     278,   291,   232,  -210,   233,   287,  -210,  -210,   284,   292,
     245,  -210,   497,    84,   247,  -210,   114,   114,  -210,  -210,
     359,   359,   359,   359,    85,    85,  -210,   521,   538,   248,
     294,   323,   316,  -210,   250,  -210,   251,   302,  -210,  -210,
    -210,   301,   306,   260,  -210,  -210,   106,   109,  -210,   106,
     106,  -210,  -210,   310,   311,   324,   326,   282,  -210,  -210,
     334,    87,  -210,   497,    91,   100,   355,  -210,  -210,  -210,
    -210,   337,  -210,  -210,  -210,  -210,   338,  -210,  -210
};

  /* YYDEFACT[STATE-NUM] -- Default reduction number in state STATE-NUM.
     Performed when YYTABLE does not specify something else to do.  Zero
     means the default is an error.  */
static const yytype_int8 yydefact[] =
{
       7,     5,     0,     2,     0,     1,    16,    10,     0,     9,
       0,     3,     0,     6,     8,    20,     0,    18,     0,    31,
       0,     0,    15,    17,     0,     0,    46,   125,   123,   124,
       0,    13,     0,    21,    23,     0,    33,    34,     0,    11,
      12,     0,     0,    29,    32,     0,   123,    45,     4,     0,
      14,    22,     0,    26,     0,    30,    38,     0,    37,     0,
       0,    46,    25,     0,     0,    43,     0,    35,     0,   111,
      43,     0,    28,     0,    24,    43,     0,    42,     0,     0,
      36,     0,    47,    19,     0,     0,    39,    44,    40,   112,
       0,     0,    41,     0,     0,    27,   117,   117,     0,   113,
      48,   116,     0,   119,     0,     0,     0,   115,   118,   122,
       0,    55,     0,     0,   120,     0,    52,    50,   114,    49,
     121,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,    54,     0,     0,     0,     0,     0,     0,    85,    84,
      97,     0,     0,     0,    96,    98,    95,     0,     0,     0,
       0,    68,    69,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,    99,     0,     0,     0,     0,   110,
       0,     0,    64,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,    65,    55,
      55,   101,     0,    51,     0,     0,     0,     0,     0,   100,
       0,     0,     0,    57,     0,     0,    56,   105,     0,     0,
      99,   109,   108,     0,   101,    83,    78,    79,    80,    81,
      89,    90,    91,    92,    94,    93,    82,    87,    88,   100,
       0,     0,     0,    53,     0,    61,     0,     0,    60,    58,
      59,     0,     0,     0,    74,    75,   110,     0,    86,   110,
     110,    66,    55,     0,     0,     0,     0,     0,    72,    70,
       0,     0,   107,   106,     0,     0,     0,    63,    67,    73,
      71,     0,    76,   103,   102,   104,     0,    77,    62
};

  /* YYPGOTO[NTERM-NUM].  */
static const yytype_int16 yypgoto[] =
{
    -210,  -210,  -210,  -210,  -210,  -210,  -210,   339,  -210,  -210,
     318,  -210,  -210,   330,  -210,  -210,  -210,  -210,   297,  -210,
    -210,  -210,  -210,   315,  -210,  -210,   283,   -58,   275,   296,
    -210,  -210,  -210,   264,  -210,  -210,  -182,  -210,  -120,  -117,
    -210,  -115,  -209,  -210,  -210,  -210,  -210,   256,  -210,   259,
    -210,    46
};

  /* YYDEFGOTO[NTERM-NUM].  */
static const yytype_int16 yydefgoto[] =
{
      -1,     2,     6,    19,     3,     4,     8,     9,    12,    30,
      31,    11,    16,    17,    18,    42,    51,    52,    53,    71,
      26,    55,    35,    36,    45,    57,    58,    76,    77,    38,
      47,    90,   106,   112,   130,   155,   117,   131,   212,   144,
     145,   146,   213,    48,    81,    93,   105,    99,   102,   103,
     110,    78
};

  /* YYTABLE[YYPACT[STATE-NUM]] -- What to do in state STATE-NUM.  If
     positive, shift that token.  If negative, reduce the rule whose
     number is the opposite.  If YYTABLE_NINF, syntax error.  */
static const yytype_int16 yytable[] =
{
     132,   166,   133,   143,   148,   149,   150,   231,   232,   156,
       7,   168,    82,    65,   163,    66,   165,    84,   135,    74,
     167,    27,   171,    28,    29,     7,   157,   171,   138,   139,
      15,   169,     1,   136,   192,   157,   198,   261,   201,   208,
     264,   265,   138,   139,   138,   139,   129,   209,     5,   134,
      13,   159,   187,   216,   217,   218,   219,   220,   221,   222,
     223,   224,   225,   226,   227,   228,    32,    75,   160,   140,
     266,    37,    39,   141,    22,   135,    32,    85,   138,   139,
     142,    37,    10,   140,    49,   140,   161,   141,    54,   141,
     162,    85,   247,    15,   142,   247,   142,   136,    63,   247,
     138,   139,   200,   173,   174,   175,   176,   194,   247,   138,
     139,    20,   138,   139,   132,   132,   133,   133,    49,   140,
      21,   138,   139,   141,   195,    86,   183,   263,    25,    27,
     142,    28,    29,   211,   175,   176,   262,    67,    68,    91,
     248,   140,   196,   273,   104,   141,   197,   274,   104,   132,
     140,   133,   142,   140,   141,   183,   275,   141,   172,   114,
     115,   142,   140,    24,   142,    27,   141,    46,    29,   173,
     174,   175,   176,   147,    27,    33,    28,    29,    34,    41,
     177,   178,   179,   180,   181,   182,   188,    50,    56,    59,
      60,    64,   183,    69,    70,    43,    73,   173,   174,   175,
     176,    79,   184,   185,    83,    87,    88,    85,   177,   178,
     179,   180,   181,   182,   206,    75,    95,    89,    96,    94,
     183,    97,   109,    98,   116,   173,   174,   175,   176,   111,
     184,   185,   118,   120,   151,   119,   177,   178,   179,   180,
     181,   182,   233,   152,   137,   153,   154,   158,   183,   164,
     170,   186,   191,   173,   174,   175,   176,   193,   184,   185,
     199,   202,   203,   204,   177,   178,   179,   180,   181,   182,
     238,   210,   205,   214,   229,   234,   183,   230,   236,   235,
     237,   173,   174,   175,   176,   239,   184,   185,   241,   242,
     243,   244,   177,   178,   179,   180,   181,   182,   240,   245,
     246,   251,   249,   250,   183,   257,   255,   256,   258,   173,
     174,   175,   176,   259,   184,   185,   260,   267,   268,   121,
     177,   178,   179,   180,   181,   182,   121,   122,   123,   124,
     125,   269,   183,   270,   122,   123,   124,   125,   271,   252,
     253,   272,   184,   185,   277,   278,    23,    14,    40,    62,
      44,    80,   126,   100,   254,   127,   128,    72,   121,   126,
      92,   108,   127,   128,   129,   121,   122,   123,   124,   125,
     113,   129,   276,   122,   123,   124,   125,   173,   174,   175,
     176,     0,     0,     0,     0,     0,     0,    27,     0,    28,
      29,   126,   181,   182,   127,   128,     0,     0,   126,     0,
     183,   127,   128,   129,   173,   174,   175,   176,    61,    27,
     129,    28,    29,     0,     0,   177,   178,   179,   180,   181,
     182,     0,    27,     0,    28,    29,     0,   183,     0,     0,
     101,     0,     0,     0,     0,     0,     0,   184,   185,   173,
     174,   175,   176,   107,   207,     0,     0,     0,     0,     0,
     177,   178,   179,   180,   181,   182,     0,     0,     0,     0,
       0,     0,   183,     0,   189,     0,     0,   173,   174,   175,
     176,     0,   184,   185,     0,     0,     0,   215,   177,   178,
     179,   180,   181,   182,     0,     0,     0,     0,     0,     0,
     183,   173,   174,   175,   176,     0,     0,     0,     0,     0,
     184,   185,   177,   178,   179,   180,   181,   182,     0,     0,
     190,     0,     0,     0,   183,   173,   174,   175,   176,     0,
       0,     0,     0,     0,   184,   185,   177,   178,   179,   180,
     181,   182,     0,     0,     0,     0,     0,     0,   183,   173,
     174,   175,   176,     0,     0,     0,     0,     0,   184,   185,
     177,   178,   179,   180,   181,   182,   173,   174,   175,   176,
       0,     0,   183,     0,     0,     0,     0,   177,   178,   179,
     180,   181,   182,   185,     0,     0,     0,     0,     0,   183
};

static const yytype_int16 yycheck[] =
{
     117,     3,   117,   123,   124,   125,   126,   189,   190,     9,
       3,    35,    70,    55,   134,    57,   136,    75,    35,     7,
     137,     3,   142,     5,     6,     3,    35,   147,     3,     4,
       3,    55,    42,    57,   154,    35,   156,   246,   158,    56,
     249,   250,     3,     4,     3,     4,    48,    56,     0,     9,
      43,    10,    27,   173,   174,   175,   176,   177,   178,   179,
     180,   181,   182,   183,   184,   185,    20,    55,    27,    44,
     252,    25,    54,    48,    47,    35,    30,     8,     3,     4,
      55,    35,    46,    44,    38,    44,    45,    48,    42,    48,
      49,     8,     8,     3,    55,     8,    55,    57,    52,     8,
       3,     4,    27,    18,    19,    20,    21,    10,     8,     3,
       4,    53,     3,     4,   231,   232,   231,   232,    72,    44,
      50,     3,     4,    48,    27,    56,    41,   247,    23,     3,
      55,     5,     6,    27,    20,    21,    27,     7,     8,    56,
      56,    44,    45,    56,    98,    48,    49,    56,   102,   266,
      44,   266,    55,    44,    48,    41,    56,    48,     7,     7,
       8,    55,    44,    53,    55,     3,    48,     5,     6,    18,
      19,    20,    21,    55,     3,     3,     5,     6,    23,     3,
      29,    30,    31,    32,    33,    34,     7,     7,     3,    22,
       3,     3,    41,    55,    55,    24,     3,    18,    19,    20,
      21,     4,    51,    52,    54,     3,    58,     8,    29,    30,
      31,    32,    33,    34,     7,    55,     7,    56,    53,    56,
      41,    53,     3,    23,    26,    18,    19,    20,    21,    25,
      51,    52,    54,     3,     7,    54,    29,    30,    31,    32,
      33,    34,     7,     7,    55,    35,    28,     9,    41,     3,
      35,    35,     3,    18,    19,    20,    21,    26,    51,    52,
       3,    55,     7,    55,    29,    30,    31,    32,    33,    34,
       7,     3,    55,     3,     3,    55,    41,    56,    55,     7,
      55,    18,    19,    20,    21,     7,    51,    52,    56,    56,
       3,     7,    29,    30,    31,    32,    33,    34,     7,     7,
      55,     7,    55,    55,    41,     3,    56,    56,     7,    18,
      19,    20,    21,     7,    51,    52,    56,     7,     7,     3,
      29,    30,    31,    32,    33,    34,     3,    11,    12,    13,
      14,     7,    41,     7,    11,    12,    13,    14,    56,    16,
      17,     7,    51,    52,     7,     7,    16,     8,    30,    52,
      35,    68,    36,    97,    38,    39,    40,    61,     3,    36,
      85,   102,    39,    40,    48,     3,    11,    12,    13,    14,
     106,    48,    17,    11,    12,    13,    14,    18,    19,    20,
      21,    -1,    -1,    -1,    -1,    -1,    -1,     3,    -1,     5,
       6,    36,    33,    34,    39,    40,    -1,    -1,    36,    -1,
      41,    39,    40,    48,    18,    19,    20,    21,    24,     3,
      48,     5,     6,    -1,    -1,    29,    30,    31,    32,    33,
      34,    -1,     3,    -1,     5,     6,    -1,    41,    -1,    -1,
      24,    -1,    -1,    -1,    -1,    -1,    -1,    51,    52,    18,
      19,    20,    21,    24,    58,    -1,    -1,    -1,    -1,    -1,
      29,    30,    31,    32,    33,    34,    -1,    -1,    -1,    -1,
      -1,    -1,    41,    -1,    15,    -1,    -1,    18,    19,    20,
      21,    -1,    51,    52,    -1,    -1,    -1,    56,    29,    30,
      31,    32,    33,    34,    -1,    -1,    -1,    -1,    -1,    -1,
      41,    18,    19,    20,    21,    -1,    -1,    -1,    -1,    -1,
      51,    52,    29,    30,    31,    32,    33,    34,    -1,    -1,
      37,    -1,    -1,    -1,    41,    18,    19,    20,    21,    -1,
      -1,    -1,    -1,    -1,    51,    52,    29,    30,    31,    32,
      33,    34,    -1,    -1,    -1,    -1,    -1,    -1,    41,    18,
      19,    20,    21,    -1,    -1,    -1,    -1,    -1,    51,    52,
      29,    30,    31,    32,    33,    34,    18,    19,    20,    21,
      -1,    -1,    41,    -1,    -1,    -1,    -1,    29,    30,    31,
      32,    33,    34,    52,    -1,    -1,    -1,    -1,    -1,    41
};

  /* YYSTOS[STATE-NUM] -- The (internal number of the) accessing
     symbol of state STATE-NUM.  */
static const yytype_int8 yystos[] =
{
       0,    42,    60,    63,    64,     0,    61,     3,    65,    66,
      46,    70,    67,    43,    66,     3,    71,    72,    73,    62,
      53,    50,    47,    72,    53,    23,    79,     3,     5,     6,
      68,    69,   110,     3,    23,    81,    82,   110,    88,    54,
      69,     3,    74,    24,    82,    83,     5,    89,   102,   110,
       7,    75,    76,    77,   110,    80,     3,    84,    85,    22,
       3,    24,    77,   110,     3,    55,    57,     7,     8,    55,
      55,    78,    88,     3,     7,    55,    86,    87,   110,     4,
      85,   103,    86,    54,    86,     8,    56,     3,    58,    56,
      90,    56,    87,   104,    56,     7,    53,    53,    23,   106,
     106,    24,   107,   108,   110,   105,    91,    24,   108,     3,
     109,    25,    92,    92,     7,     8,    26,    95,    54,    54,
       3,     3,    11,    12,    13,    14,    36,    39,    40,    48,
      93,    96,    98,   100,     9,    35,    57,    55,     3,     4,
      44,    48,    55,    97,    98,    99,   100,    55,    97,    97,
      97,     7,     7,    35,    28,    94,     9,    35,     9,    10,
      27,    45,    49,    97,     3,    97,     3,    98,    35,    55,
      35,    97,     7,    18,    19,    20,    21,    29,    30,    31,
      32,    33,    34,    41,    51,    52,    35,    27,     7,    15,
      37,     3,    97,    26,    10,    27,    45,    49,    97,     3,
      27,    97,    55,     7,    55,    55,     7,    58,    56,    56,
       3,    27,    97,   101,     3,    56,    97,    97,    97,    97,
      97,    97,    97,    97,    97,    97,    97,    97,    97,     3,
      56,    95,    95,     7,    55,     7,    55,    55,     7,     7,
       7,    56,    56,     3,     7,     7,    55,     8,    56,    55,
      55,     7,    16,    17,    38,    56,    56,     3,     7,     7,
      56,   101,    27,    97,   101,   101,    95,     7,     7,     7,
       7,    56,     7,    56,    56,    56,    17,     7,     7
};

  /* YYR1[YYN] -- Symbol number of symbol that rule YYN derives.  */
static const yytype_int8 yyr1[] =
{
       0,    59,    61,    62,    60,    64,    63,    63,    65,    65,
      67,    66,    68,    68,    69,    70,    70,    71,    71,    72,
      73,    73,    74,    74,    75,    76,    76,    77,    78,    80,
      79,    79,    81,    81,    83,    82,    84,    84,    85,    85,
      85,    86,    86,    86,    87,    88,    88,    90,    91,    89,
      93,    92,    92,    94,    95,    95,    96,    96,    96,    96,
      96,    96,    96,    96,    96,    96,    96,    96,    96,    96,
      96,    96,    96,    96,    96,    96,    96,    96,    97,    97,
      97,    97,    97,    97,    97,    97,    97,    97,    97,    97,
      97,    97,    97,    97,    97,    97,    97,    97,    97,    98,
      98,    98,    99,    99,    99,   100,   101,   101,   101,   101,
     101,   103,   104,   105,   102,   106,   106,   106,   107,   107,
     108,   109,   109,   110,   110,   110
};

  /* YYR2[YYN] -- Number of symbols on the right hand side of rule YYN.  */
static const yytype_int8 yyr2[] =
{
       0,     2,     0,     0,     7,     0,     4,     0,     2,     1,
       0,     5,     2,     1,     3,     3,     0,     2,     1,     8,
       1,     3,     2,     0,     3,     2,     1,     6,     1,     0,
       4,     0,     2,     1,     0,     4,     3,     1,     1,     4,
       4,     3,     1,     0,     2,     2,     0,     0,     0,    11,
       0,     5,     2,     3,     2,     0,     4,     4,     4,     4,
       4,     4,     8,     6,     3,     3,     5,     6,     2,     2,
       6,     6,     6,     6,     5,     5,     7,     7,     3,     3,
       3,     3,     3,     3,     1,     1,     4,     3,     3,     3,
       3,     3,     3,     3,     3,     1,     1,     1,     1,     3,
       3,     3,     6,     6,     6,     4,     3,     3,     1,     1,
       0,     0,     0,     0,    11,     3,     2,     0,     2,     1,
       3,     3,     1,     1,     1,     1
};


#define yyerrok         (yyerrstatus = 0)
#define yyclearin       (yychar = YYEMPTY)
#define YYEMPTY         (-2)
#define YYEOF           0

#define YYACCEPT        goto yyacceptlab
#define YYABORT         goto yyabortlab
#define YYERROR         goto yyerrorlab


#define YYRECOVERING()  (!!yyerrstatus)

#define YYBACKUP(Token, Value)                                    \
  do                                                              \
    if (yychar == YYEMPTY)                                        \
      {                                                           \
        yychar = (Token);                                         \
        yylval = (Value);                                         \
        YYPOPSTACK (yylen);                                       \
        yystate = *yyssp;                                         \
        goto yybackup;                                            \
      }                                                           \
    else                                                          \
      {                                                           \
        yyerror (YY_("syntax error: cannot back up")); \
        YYERROR;                                                  \
      }                                                           \
  while (0)

/* Error token number */
#define YYTERROR        1
#define YYERRCODE       256



/* Enable debugging if requested.  */
#if YYDEBUG

# ifndef YYFPRINTF
#  include <stdio.h> /* INFRINGES ON USER NAME SPACE */
#  define YYFPRINTF fprintf
# endif

# define YYDPRINTF(Args)                        \
do {                                            \
  if (yydebug)                                  \
    YYFPRINTF Args;                             \
} while (0)

/* This macro is provided for backward compatibility. */
#ifndef YY_LOCATION_PRINT
# define YY_LOCATION_PRINT(File, Loc) ((void) 0)
#endif


# define YY_SYMBOL_PRINT(Title, Type, Value, Location)                    \
do {                                                                      \
  if (yydebug)                                                            \
    {                                                                     \
      YYFPRINTF (stderr, "%s ", Title);                                   \
      yy_symbol_print (stderr,                                            \
                  Type, Value); \
      YYFPRINTF (stderr, "\n");                                           \
    }                                                                     \
} while (0)


/*-----------------------------------.
| Print this symbol's value on YYO.  |
`-----------------------------------*/

static void
yy_symbol_value_print (FILE *yyo, int yytype, YYSTYPE const * const yyvaluep)
{
  FILE *yyoutput = yyo;
  YYUSE (yyoutput);
  if (!yyvaluep)
    return;
# ifdef YYPRINT
  if (yytype < YYNTOKENS)
    YYPRINT (yyo, yytoknum[yytype], *yyvaluep);
# endif
  YY_IGNORE_MAYBE_UNINITIALIZED_BEGIN
  YYUSE (yytype);
  YY_IGNORE_MAYBE_UNINITIALIZED_END
}


/*---------------------------.
| Print this symbol on YYO.  |
`---------------------------*/

static void
yy_symbol_print (FILE *yyo, int yytype, YYSTYPE const * const yyvaluep)
{
  YYFPRINTF (yyo, "%s %s (",
             yytype < YYNTOKENS ? "token" : "nterm", yytname[yytype]);

  yy_symbol_value_print (yyo, yytype, yyvaluep);
  YYFPRINTF (yyo, ")");
}

/*------------------------------------------------------------------.
| yy_stack_print -- Print the state stack from its BOTTOM up to its |
| TOP (included).                                                   |
`------------------------------------------------------------------*/

static void
yy_stack_print (yy_state_t *yybottom, yy_state_t *yytop)
{
  YYFPRINTF (stderr, "Stack now");
  for (; yybottom <= yytop; yybottom++)
    {
      int yybot = *yybottom;
      YYFPRINTF (stderr, " %d", yybot);
    }
  YYFPRINTF (stderr, "\n");
}

# define YY_STACK_PRINT(Bottom, Top)                            \
do {                                                            \
  if (yydebug)                                                  \
    yy_stack_print ((Bottom), (Top));                           \
} while (0)


/*------------------------------------------------.
| Report that the YYRULE is going to be reduced.  |
`------------------------------------------------*/

static void
yy_reduce_print (yy_state_t *yyssp, YYSTYPE *yyvsp, int yyrule)
{
  int yylno = yyrline[yyrule];
  int yynrhs = yyr2[yyrule];
  int yyi;
  YYFPRINTF (stderr, "Reducing stack by rule %d (line %d):\n",
             yyrule - 1, yylno);
  /* The symbols being reduced.  */
  for (yyi = 0; yyi < yynrhs; yyi++)
    {
      YYFPRINTF (stderr, "   $%d = ", yyi + 1);
      yy_symbol_print (stderr,
                       yystos[+yyssp[yyi + 1 - yynrhs]],
                       &yyvsp[(yyi + 1) - (yynrhs)]
                                              );
      YYFPRINTF (stderr, "\n");
    }
}

# define YY_REDUCE_PRINT(Rule)          \
do {                                    \
  if (yydebug)                          \
    yy_reduce_print (yyssp, yyvsp, Rule); \
} while (0)

/* Nonzero means print parse trace.  It is left uninitialized so that
   multiple parsers can coexist.  */
int yydebug;
#else /* !YYDEBUG */
# define YYDPRINTF(Args)
# define YY_SYMBOL_PRINT(Title, Type, Value, Location)
# define YY_STACK_PRINT(Bottom, Top)
# define YY_REDUCE_PRINT(Rule)
#endif /* !YYDEBUG */


/* YYINITDEPTH -- initial size of the parser's stacks.  */
#ifndef YYINITDEPTH
# define YYINITDEPTH 200
#endif

/* YYMAXDEPTH -- maximum size the stacks can grow to (effective only
   if the built-in stack extension method is used).

   Do not make this value too large; the results are undefined if
   YYSTACK_ALLOC_MAXIMUM < YYSTACK_BYTES (YYMAXDEPTH)
   evaluated with infinite-precision integer arithmetic.  */

#ifndef YYMAXDEPTH
# define YYMAXDEPTH 10000
#endif


#if YYERROR_VERBOSE

# ifndef yystrlen
#  if defined __GLIBC__ && defined _STRING_H
#   define yystrlen(S) (YY_CAST (YYPTRDIFF_T, strlen (S)))
#  else
/* Return the length of YYSTR.  */
static YYPTRDIFF_T
yystrlen (const char *yystr)
{
  YYPTRDIFF_T yylen;
  for (yylen = 0; yystr[yylen]; yylen++)
    continue;
  return yylen;
}
#  endif
# endif

# ifndef yystpcpy
#  if defined __GLIBC__ && defined _STRING_H && defined _GNU_SOURCE
#   define yystpcpy stpcpy
#  else
/* Copy YYSRC to YYDEST, returning the address of the terminating '\0' in
   YYDEST.  */
static char *
yystpcpy (char *yydest, const char *yysrc)
{
  char *yyd = yydest;
  const char *yys = yysrc;

  while ((*yyd++ = *yys++) != '\0')
    continue;

  return yyd - 1;
}
#  endif
# endif

# ifndef yytnamerr
/* Copy to YYRES the contents of YYSTR after stripping away unnecessary
   quotes and backslashes, so that it's suitable for yyerror.  The
   heuristic is that double-quoting is unnecessary unless the string
   contains an apostrophe, a comma, or backslash (other than
   backslash-backslash).  YYSTR is taken from yytname.  If YYRES is
   null, do not copy; instead, return the length of what the result
   would have been.  */
static YYPTRDIFF_T
yytnamerr (char *yyres, const char *yystr)
{
  if (*yystr == '"')
    {
      YYPTRDIFF_T yyn = 0;
      char const *yyp = yystr;

      for (;;)
        switch (*++yyp)
          {
          case '\'':
          case ',':
            goto do_not_strip_quotes;

          case '\\':
            if (*++yyp != '\\')
              goto do_not_strip_quotes;
            else
              goto append;

          append:
          default:
            if (yyres)
              yyres[yyn] = *yyp;
            yyn++;
            break;

          case '"':
            if (yyres)
              yyres[yyn] = '\0';
            return yyn;
          }
    do_not_strip_quotes: ;
    }

  if (yyres)
    return yystpcpy (yyres, yystr) - yyres;
  else
    return yystrlen (yystr);
}
# endif

/* Copy into *YYMSG, which is of size *YYMSG_ALLOC, an error message
   about the unexpected token YYTOKEN for the state stack whose top is
   YYSSP.

   Return 0 if *YYMSG was successfully written.  Return 1 if *YYMSG is
   not large enough to hold the message.  In that case, also set
   *YYMSG_ALLOC to the required number of bytes.  Return 2 if the
   required number of bytes is too large to store.  */
static int
yysyntax_error (YYPTRDIFF_T *yymsg_alloc, char **yymsg,
                yy_state_t *yyssp, int yytoken)
{
  enum { YYERROR_VERBOSE_ARGS_MAXIMUM = 5 };
  /* Internationalized format string. */
  const char *yyformat = YY_NULLPTR;
  /* Arguments of yyformat: reported tokens (one for the "unexpected",
     one per "expected"). */
  char const *yyarg[YYERROR_VERBOSE_ARGS_MAXIMUM];
  /* Actual size of YYARG. */
  int yycount = 0;
  /* Cumulated lengths of YYARG.  */
  YYPTRDIFF_T yysize = 0;

  /* There are many possibilities here to consider:
     - If this state is a consistent state with a default action, then
       the only way this function was invoked is if the default action
       is an error action.  In that case, don't check for expected
       tokens because there are none.
     - The only way there can be no lookahead present (in yychar) is if
       this state is a consistent state with a default action.  Thus,
       detecting the absence of a lookahead is sufficient to determine
       that there is no unexpected or expected token to report.  In that
       case, just report a simple "syntax error".
     - Don't assume there isn't a lookahead just because this state is a
       consistent state with a default action.  There might have been a
       previous inconsistent state, consistent state with a non-default
       action, or user semantic action that manipulated yychar.
     - Of course, the expected token list depends on states to have
       correct lookahead information, and it depends on the parser not
       to perform extra reductions after fetching a lookahead from the
       scanner and before detecting a syntax error.  Thus, state merging
       (from LALR or IELR) and default reductions corrupt the expected
       token list.  However, the list is correct for canonical LR with
       one exception: it will still contain any token that will not be
       accepted due to an error action in a later state.
  */
  if (yytoken != YYEMPTY)
    {
      int yyn = yypact[+*yyssp];
      YYPTRDIFF_T yysize0 = yytnamerr (YY_NULLPTR, yytname[yytoken]);
      yysize = yysize0;
      yyarg[yycount++] = yytname[yytoken];
      if (!yypact_value_is_default (yyn))
        {
          /* Start YYX at -YYN if negative to avoid negative indexes in
             YYCHECK.  In other words, skip the first -YYN actions for
             this state because they are default actions.  */
          int yyxbegin = yyn < 0 ? -yyn : 0;
          /* Stay within bounds of both yycheck and yytname.  */
          int yychecklim = YYLAST - yyn + 1;
          int yyxend = yychecklim < YYNTOKENS ? yychecklim : YYNTOKENS;
          int yyx;

          for (yyx = yyxbegin; yyx < yyxend; ++yyx)
            if (yycheck[yyx + yyn] == yyx && yyx != YYTERROR
                && !yytable_value_is_error (yytable[yyx + yyn]))
              {
                if (yycount == YYERROR_VERBOSE_ARGS_MAXIMUM)
                  {
                    yycount = 1;
                    yysize = yysize0;
                    break;
                  }
                yyarg[yycount++] = yytname[yyx];
                {
                  YYPTRDIFF_T yysize1
                    = yysize + yytnamerr (YY_NULLPTR, yytname[yyx]);
                  if (yysize <= yysize1 && yysize1 <= YYSTACK_ALLOC_MAXIMUM)
                    yysize = yysize1;
                  else
                    return 2;
                }
              }
        }
    }

  switch (yycount)
    {
# define YYCASE_(N, S)                      \
      case N:                               \
        yyformat = S;                       \
      break
    default: /* Avoid compiler warnings. */
      YYCASE_(0, YY_("syntax error"));
      YYCASE_(1, YY_("syntax error, unexpected %s"));
      YYCASE_(2, YY_("syntax error, unexpected %s, expecting %s"));
      YYCASE_(3, YY_("syntax error, unexpected %s, expecting %s or %s"));
      YYCASE_(4, YY_("syntax error, unexpected %s, expecting %s or %s or %s"));
      YYCASE_(5, YY_("syntax error, unexpected %s, expecting %s or %s or %s or %s"));
# undef YYCASE_
    }

  {
    /* Don't count the "%s"s in the final size, but reserve room for
       the terminator.  */
    YYPTRDIFF_T yysize1 = yysize + (yystrlen (yyformat) - 2 * yycount) + 1;
    if (yysize <= yysize1 && yysize1 <= YYSTACK_ALLOC_MAXIMUM)
      yysize = yysize1;
    else
      return 2;
  }

  if (*yymsg_alloc < yysize)
    {
      *yymsg_alloc = 2 * yysize;
      if (! (yysize <= *yymsg_alloc
             && *yymsg_alloc <= YYSTACK_ALLOC_MAXIMUM))
        *yymsg_alloc = YYSTACK_ALLOC_MAXIMUM;
      return 1;
    }

  /* Avoid sprintf, as that infringes on the user's name space.
     Don't have undefined behavior even if the translation
     produced a string with the wrong number of "%s"s.  */
  {
    char *yyp = *yymsg;
    int yyi = 0;
    while ((*yyp = *yyformat) != '\0')
      if (*yyp == '%' && yyformat[1] == 's' && yyi < yycount)
        {
          yyp += yytnamerr (yyp, yyarg[yyi++]);
          yyformat += 2;
        }
      else
        {
          ++yyp;
          ++yyformat;
        }
  }
  return 0;
}
#endif /* YYERROR_VERBOSE */

/*-----------------------------------------------.
| Release the memory associated to this symbol.  |
`-----------------------------------------------*/

static void
yydestruct (const char *yymsg, int yytype, YYSTYPE *yyvaluep)
{
  YYUSE (yyvaluep);
  if (!yymsg)
    yymsg = "Deleting";
  YY_SYMBOL_PRINT (yymsg, yytype, yyvaluep, yylocationp);

  YY_IGNORE_MAYBE_UNINITIALIZED_BEGIN
  YYUSE (yytype);
  YY_IGNORE_MAYBE_UNINITIALIZED_END
}




/* The lookahead symbol.  */
int yychar;

/* The semantic value of the lookahead symbol.  */
YYSTYPE yylval;
/* Number of syntax errors so far.  */
int yynerrs;


/*----------.
| yyparse.  |
`----------*/

int
yyparse (void)
{
    yy_state_fast_t yystate;
    /* Number of tokens to shift before error messages enabled.  */
    int yyerrstatus;

    /* The stacks and their tools:
       'yyss': related to states.
       'yyvs': related to semantic values.

       Refer to the stacks through separate pointers, to allow yyoverflow
       to reallocate them elsewhere.  */

    /* The state stack.  */
    yy_state_t yyssa[YYINITDEPTH];
    yy_state_t *yyss;
    yy_state_t *yyssp;

    /* The semantic value stack.  */
    YYSTYPE yyvsa[YYINITDEPTH];
    YYSTYPE *yyvs;
    YYSTYPE *yyvsp;

    YYPTRDIFF_T yystacksize;

  int yyn;
  int yyresult;
  /* Lookahead token as an internal (translated) token number.  */
  int yytoken = 0;
  /* The variables used to return semantic value and location from the
     action routines.  */
  YYSTYPE yyval;

#if YYERROR_VERBOSE
  /* Buffer for error messages, and its allocated size.  */
  char yymsgbuf[128];
  char *yymsg = yymsgbuf;
  YYPTRDIFF_T yymsg_alloc = sizeof yymsgbuf;
#endif

#define YYPOPSTACK(N)   (yyvsp -= (N), yyssp -= (N))

  /* The number of symbols on the RHS of the reduced rule.
     Keep to zero when no symbol should be popped.  */
  int yylen = 0;

  yyssp = yyss = yyssa;
  yyvsp = yyvs = yyvsa;
  yystacksize = YYINITDEPTH;

  YYDPRINTF ((stderr, "Starting parse\n"));

  yystate = 0;
  yyerrstatus = 0;
  yynerrs = 0;
  yychar = YYEMPTY; /* Cause a token to be read.  */
  goto yysetstate;


/*------------------------------------------------------------.
| yynewstate -- push a new state, which is found in yystate.  |
`------------------------------------------------------------*/
yynewstate:
  /* In all cases, when you get here, the value and location stacks
     have just been pushed.  So pushing a state here evens the stacks.  */
  yyssp++;


/*--------------------------------------------------------------------.
| yysetstate -- set current state (the top of the stack) to yystate.  |
`--------------------------------------------------------------------*/
yysetstate:
  YYDPRINTF ((stderr, "Entering state %d\n", yystate));
  YY_ASSERT (0 <= yystate && yystate < YYNSTATES);
  YY_IGNORE_USELESS_CAST_BEGIN
  *yyssp = YY_CAST (yy_state_t, yystate);
  YY_IGNORE_USELESS_CAST_END

  if (yyss + yystacksize - 1 <= yyssp)
#if !defined yyoverflow && !defined YYSTACK_RELOCATE
    goto yyexhaustedlab;
#else
    {
      /* Get the current used size of the three stacks, in elements.  */
      YYPTRDIFF_T yysize = yyssp - yyss + 1;

# if defined yyoverflow
      {
        /* Give user a chance to reallocate the stack.  Use copies of
           these so that the &'s don't force the real ones into
           memory.  */
        yy_state_t *yyss1 = yyss;
        YYSTYPE *yyvs1 = yyvs;

        /* Each stack pointer address is followed by the size of the
           data in use in that stack, in bytes.  This used to be a
           conditional around just the two extra args, but that might
           be undefined if yyoverflow is a macro.  */
        yyoverflow (YY_("memory exhausted"),
                    &yyss1, yysize * YYSIZEOF (*yyssp),
                    &yyvs1, yysize * YYSIZEOF (*yyvsp),
                    &yystacksize);
        yyss = yyss1;
        yyvs = yyvs1;
      }
# else /* defined YYSTACK_RELOCATE */
      /* Extend the stack our own way.  */
      if (YYMAXDEPTH <= yystacksize)
        goto yyexhaustedlab;
      yystacksize *= 2;
      if (YYMAXDEPTH < yystacksize)
        yystacksize = YYMAXDEPTH;

      {
        yy_state_t *yyss1 = yyss;
        union yyalloc *yyptr =
          YY_CAST (union yyalloc *,
                   YYSTACK_ALLOC (YY_CAST (YYSIZE_T, YYSTACK_BYTES (yystacksize))));
        if (! yyptr)
          goto yyexhaustedlab;
        YYSTACK_RELOCATE (yyss_alloc, yyss);
        YYSTACK_RELOCATE (yyvs_alloc, yyvs);
# undef YYSTACK_RELOCATE
        if (yyss1 != yyssa)
          YYSTACK_FREE (yyss1);
      }
# endif

      yyssp = yyss + yysize - 1;
      yyvsp = yyvs + yysize - 1;

      YY_IGNORE_USELESS_CAST_BEGIN
      YYDPRINTF ((stderr, "Stack size increased to %ld\n",
                  YY_CAST (long, yystacksize)));
      YY_IGNORE_USELESS_CAST_END

      if (yyss + yystacksize - 1 <= yyssp)
        YYABORT;
    }
#endif /* !defined yyoverflow && !defined YYSTACK_RELOCATE */

  if (yystate == YYFINAL)
    YYACCEPT;

  goto yybackup;


/*-----------.
| yybackup.  |
`-----------*/
yybackup:
  /* Do appropriate processing given the current state.  Read a
     lookahead token if we need one and don't already have one.  */

  /* First try to decide what to do without reference to lookahead token.  */
  yyn = yypact[yystate];
  if (yypact_value_is_default (yyn))
    goto yydefault;

  /* Not known => get a lookahead token if don't already have one.  */

  /* YYCHAR is either YYEMPTY or YYEOF or a valid lookahead symbol.  */
  if (yychar == YYEMPTY)
    {
      YYDPRINTF ((stderr, "Reading a token: "));
      yychar = yylex ();
    }

  if (yychar <= YYEOF)
    {
      yychar = yytoken = YYEOF;
      YYDPRINTF ((stderr, "Now at end of input.\n"));
    }
  else
    {
      yytoken = YYTRANSLATE (yychar);
      YY_SYMBOL_PRINT ("Next token is", yytoken, &yylval, &yylloc);
    }

  /* If the proper action on seeing token YYTOKEN is to reduce or to
     detect an error, take that action.  */
  yyn += yytoken;
  if (yyn < 0 || YYLAST < yyn || yycheck[yyn] != yytoken)
    goto yydefault;
  yyn = yytable[yyn];
  if (yyn <= 0)
    {
      if (yytable_value_is_error (yyn))
        goto yyerrlab;
      yyn = -yyn;
      goto yyreduce;
    }

  /* Count tokens shifted since error; after three, turn off error
     status.  */
  if (yyerrstatus)
    yyerrstatus--;

  /* Shift the lookahead token.  */
  YY_SYMBOL_PRINT ("Shifting", yytoken, &yylval, &yylloc);
  yystate = yyn;
  YY_IGNORE_MAYBE_UNINITIALIZED_BEGIN
  *++yyvsp = yylval;
  YY_IGNORE_MAYBE_UNINITIALIZED_END

  /* Discard the shifted token.  */
  yychar = YYEMPTY;
  goto yynewstate;


/*-----------------------------------------------------------.
| yydefault -- do the default action for the current state.  |
`-----------------------------------------------------------*/
yydefault:
  yyn = yydefact[yystate];
  if (yyn == 0)
    goto yyerrlab;
  goto yyreduce;


/*-----------------------------.
| yyreduce -- do a reduction.  |
`-----------------------------*/
yyreduce:
  /* yyn is the number of a rule to reduce with.  */
  yylen = yyr2[yyn];

  /* If YYLEN is nonzero, implement the default value of the action:
     '$$ = $1'.

     Otherwise, the following line sets YYVAL to garbage.
     This behavior is undocumented and Bison
     users should not rely upon it.  Assigning to YYVAL
     unconditionally makes the parser a bit smaller, and it avoids a
     GCC warning that YYVAL may be used uninitialized.  */
  yyval = yyvsp[1-yylen];


  YY_REDUCE_PRINT (yyn);
  switch (yyn)
    {
  case 2:
#line 44 "task1.y"
                       {if(T_Table==NULL) T_Table=TypeTableCreate(); GLabel=getLabel();/*fprintf(target,"JMP L%d\n",GLabel);*/}
#line 1681 "y.tab.c"
    break;

  case 3:
#line 44 "task1.y"
                                                                                                                                             {/*fprintf(target,"L%d:\n",GLabel);*/}
#line 1687 "y.tab.c"
    break;

  case 5:
#line 48 "task1.y"
                    {T_Table=TypeTableCreate();/*printf("check-11");if(T_Table==NULL) printf("***");*/}
#line 1693 "y.tab.c"
    break;

  case 6:
#line 48 "task1.y"
                                                                                                                            {   ttableptr=T_Table;
																	printf("---------------------\n");
																	printf("Type Table\n");
																	printf("---------------------\n");
																	while(ttableptr!=NULL)
																	{
																		printf("%s ",ttableptr->name);
																		F_list=ttableptr->fields;
																		if(F_list)
																		{
																			printf("Fields = ");
																			while(F_list)
																			{
																				printf("%s - ",F_list->name);
																				F_list=F_list->next;
																			}
																		}
																		else
																			printf("Fields = NULL");
																		ttableptr=ttableptr->next;
																		printf("\n");
																	}
																	printf("---------------------\n");
																}
#line 1722 "y.tab.c"
    break;

  case 7:
#line 72 "task1.y"
                {T_Table=TypeTableCreate();}
#line 1728 "y.tab.c"
    break;

  case 10:
#line 79 "task1.y"
                        {TInstall(&T_Table,(yyvsp[0].string));}
#line 1734 "y.tab.c"
    break;

  case 11:
#line 79 "task1.y"
                                                                              {	
												ttableptr=TLookup(T_Table,(yyvsp[-4].string));
												if(!ttableptr)
	   											{	
	   												yyerror("type not defined in type table");exit(0);
	   											}
												ttableptr->fields=(yyvsp[-1].Fl);
												if(!ttableptr->fields)
													exit(0);
												F_list=(yyvsp[-1].Fl);
												/*while(F_list)
												{
													printf("%s ",F_list->name);
													F_list=F_list->next;
												}
												printf("\n");*/
												F_list=NULL;
												position=0;
											}
#line 1758 "y.tab.c"
    break;

  case 12:
#line 100 "task1.y"
                                                {	//printf("check1");
								struct Fieldlist *f_temp;
								f_temp=(yyvsp[-1].Fl);
								
								while(f_temp->next!=NULL)
								{
									//printf("%s---%s   ",f_temp->name,$<Fl>2->name);
									if(strcmp(f_temp->name,(yyvsp[0].Fl)->name))
										f_temp=f_temp->next;
									else
									{
										yyerror("ERROR- Two fields of same name");exit(0);
									}
								}
								if(!strcmp(f_temp->name,(yyvsp[0].Fl)->name))
								{
									
									yyerror("ERROR- Two fields of same name");exit(0);
								}
								//printf("%s---%s\n",f_temp->name,$<Fl>2->name);
								f_temp->next=(yyvsp[0].Fl);
								(yyval.Fl)=(yyvsp[-1].Fl); 
					 		}
#line 1786 "y.tab.c"
    break;

  case 13:
#line 124 "task1.y"
                                        {(yyval.Fl)=(yyvsp[0].Fl);}
#line 1792 "y.tab.c"
    break;

  case 14:
#line 127 "task1.y"
                                                { 
							//printf("check2");
							struct Fieldlist* F_list;
							F_list=(struct Fieldlist*)malloc(sizeof(struct Fieldlist));
							F_list->name=(char*)malloc(sizeof(char)*100);
							//printf("check12");
							//printf("%s",$<string>1);
							ttableptr=TLookup(T_Table,(yyvsp[-2].string));
							if(!ttableptr)
	   						{
	   							yyerror("type not defined in type table");exit(0);
	   						}
							F_list->type=ttableptr;
							strcpy(F_list->name,(yyvsp[-1].string));
							//printf("%s \n",F_list->name);
							if(position>8)
							{
								yyerror("Has more than 8 fields");exit(0);
							}
							F_list->fieldIndex=position;
							position++;
							F_list->next=NULL;
							(yyval.Fl)=F_list;
							//free(F_list);
							
						}
#line 1823 "y.tab.c"
    break;

  case 15:
#line 156 "task1.y"
                                                 {	Cptr=CTable;
						 	printf("---------------------\n");
							printf("Class Table\n");
							printf("---------------------\n");
							while(Cptr!=NULL)
							{
								printf("%s \n",Cptr->Name);
								f_temp=Cptr->Memberfield;
								if(f_temp)
								{
									printf("Fields = ");
									while(f_temp)
									{
										printf("%s - fieldindex = %d, ",f_temp->name,f_temp->fieldIndex);
										if(f_temp->type)
											printf("%s  ",f_temp->type->name);
										else if(f_temp->Ctype)
											printf("%s  ",f_temp->Ctype->Name);
										f_temp=f_temp->next;
									}
									//printf("  ");
								}
								else
									printf("Fields = NULL");
								printf("\n");
								
								m_temp=Cptr->Vfuncptr;
								if(m_temp)
								{
									printf("Members = ");
									while(m_temp)
									{
										printf("%s - funcposition = %d, type=%s   ",m_temp->name,m_temp->Funcposition,m_temp->type->name);
										m_temp=m_temp->next;
									}
								}
								else
									printf("Members = NULL");
								printf("\n");
								printf("\n");
								
								Cptr=Cptr->Next;
							}
							printf("---------------------\n");
						}
#line 1873 "y.tab.c"
    break;

  case 17:
#line 204 "task1.y"
                                        {Cptr=NULL;}
#line 1879 "y.tab.c"
    break;

  case 18:
#line 205 "task1.y"
                                {Cptr=NULL;}
#line 1885 "y.tab.c"
    break;

  case 19:
#line 208 "task1.y"
                                                                             {
									 		if(Cptr)
									 		{
									 			Cptr->Fieldcount=f_position;Cptr->Methodcount=m_position;Cptr->Class_index=Class_index;
									 		}
									 		f_position=0;m_position=0;Class_index++;
									 		while(temp_address<=8)
									 		{
									 			int Reg_i=getReg();
									 			if(Reg_i==-1)
									 				exit(0);
									 			fprintf(target, "MOV R%d, -1\n",Reg_i);
									 			fprintf(target,"MOV [%d], R%d\n",address, Reg_i);
									 			Reg_i=freeReg();
									 			if(Reg_i==-1)
									 				exit(0);
									 			temp_address++;
									 			address++;
									 		}
									 		temp_address=1;
									 	}
#line 1911 "y.tab.c"
    break;

  case 20:
#line 231 "task1.y"
                                {Cptr = CInstall(&CTable,(yyvsp[0].string),NULL);}
#line 1917 "y.tab.c"
    break;

  case 21:
#line 232 "task1.y"
                                {
					P_Cptr=CLookup(CTable,(yyvsp[0].string));
					if(P_Cptr==NULL)
					{
						yyerror("Parent class not found in class table");exit(0);
					} 
					Cptr = CInstall(&CTable,(yyvsp[-2].string),P_Cptr);
					//printf("--%s--%s---",Cptr->Name,Cptr->Parentptr->Name);
				}
#line 1931 "y.tab.c"
    break;

  case 23:
#line 244 "task1.y"
                  { 
			if(Cptr->Parentptr)
			{ 
				f_position=Cptr->Parentptr->Fieldcount;
				m_position=Cptr->Parentptr->Methodcount;
				Cptr->Memberfield=Cptr->Parentptr->Memberfield;
				Cptr->Vfuncptr=Cptr->Parentptr->Vfuncptr;
			}
		 }
#line 1945 "y.tab.c"
    break;

  case 24:
#line 255 "task1.y"
                                                {
							ttableptr=TLookup(T_Table,(yyvsp[-2].string));
	   						c_temp=CLookup(CTable,(yyvsp[-2].string));
	   						
	   						if(!ttableptr && !c_temp)
	   						{
	   							yyerror("type not defined in type table");exit(0);
	   						}
	   						if(f_position>8)
							{
								yyerror("class has more than 8 fields");exit(0);
							}
							if(ttableptr)
								Class_Finstall(Cptr,c_temp,ttableptr,(yyvsp[-1].string),f_position);
							else if(c_temp)
								Class_Finstall(Cptr,c_temp,ttableptr,(yyvsp[-1].string),f_position);
							
							//if(Cptr->Memberfield!=NULL)
							//	printf("**%s**",Cptr->Memberfield->name);
							
							f_position++;
							
						}
#line 1973 "y.tab.c"
    break;

  case 27:
#line 284 "task1.y"
                                                     {
							int a;
           						a=get_func_label();
							ttableptr=TLookup(T_Table,(yyvsp[-5].string));
						//	printf("%s ",ttableptr->name);
	   						if(!ttableptr)
	   						{
	   							yyerror("type not defined in type table");exit(0);
	   						}
	   						if(m_position>8)
							{
								yyerror("class has more than 8 methods");exit(0);
							}
							m_temp=Class_Mlookup(Cptr->Parentptr,(yyvsp[-4].string));
							if(!m_temp)
							{
								fprintf(target,"MOV [%d], %d\n",address, a);
								temp_address++;
								address++;
								Class_Minstall(Cptr,(yyvsp[-4].string),ttableptr,(yyvsp[-2].Pl),m_position,a);
							}
							else
							{
								if(check_func_param(m_temp->paramlist,(yyvsp[-2].Pl)))
								{
									fprintf(target,"MOV [%d], %d\n",address, a);
									temp_address++;
									address++;
									m_temp=Class_Mlookup(Cptr,(yyvsp[-4].string));
									m_temp->Flabel=a;
								}
								else
								{
									yyerror("Parameter doesnt match for parent and derived class");exit(0);
								}
							}
								
							m_position++;
						}
#line 2017 "y.tab.c"
    break;

  case 29:
#line 328 "task1.y"
                                    {/*fprintf(target, "MOV SP, %d\nMOV BP, %d\nCALL MAIN\nINT 10\n", address,address+1);*/}
#line 2023 "y.tab.c"
    break;

  case 30:
#line 329 "task1.y"
        {
	printf("----------------\n");
	printf("Global Symbol Table\n");
	printf("------------------\n");
	temp=GTable;
	while(temp)
        {
              printf("%s ",temp->name);
              if(temp->type)
            	  printf("type = %s ",temp->type->name);
              else if(temp->Ctype)
              	  printf("type = %s ",temp->Ctype->Name);
              printf("size = %d ",temp->size);
              printf("binding = %d ",temp->binding);
	      if(temp->paramlist)
	      {
			printf("paramlist.. ");
			struct Paramstruct *p;
			p=temp->paramlist;
			while(p)
			{	
				printf("name = %s,type= %s ",p->name,p->type);
				p=p->next;
			}
	      }
	      else
		printf("paramlist = NULL ");
		if(temp->type)
	     		F_list=temp->type->fields;
	     if(F_list)
	     {
		printf("Fields = ");
		while(F_list)
		{
			printf("%s - ",F_list->name);
			F_list=F_list->next;
		}
	     }
	     else
		printf("Fields = NULL");
	     
              temp=temp->next;
              printf("\n");
        }
        printf("--------------\n");
        }
#line 2074 "y.tab.c"
    break;

  case 34:
#line 382 "task1.y"
                      {
				ttableptr=TLookup(T_Table,(yyvsp[0].string));
	   			Cptr=CLookup(CTable,(yyvsp[0].string));
	   			if(!ttableptr && !Cptr)
	   			{ yyerror("type not defined in type table");exit(0);}
			}
#line 2085 "y.tab.c"
    break;

  case 38:
#line 396 "task1.y"
                {
				if(check_Reserved(Keywords,(yyvsp[0].string)))
				{
					yyerror("ERROR a reserved word declared as variable");
				}
       			else if(!GLookup(GTable,(yyvsp[0].string)))
				{
					GInstall(&GTable,(yyvsp[0].string),NULL,1,address,NULL,0);
					int reg_i=getReg();
					if (reg_i == -1)
            					exit(1);
					//--fprintf(target, "MOV R%d, -1\n",reg_i);
					//--fprintf(target, "MOV [%d], R%d\n",address,reg_i);
					reg_i = freeReg();
        				if (reg_i == -1)
            					exit(1);
            				temp=GLookup(GTable,(yyvsp[0].string));
					if(Cptr)
					{
						temp->Ctype=Cptr;
						address+=2;
					}
					else
					{
						temp->type=ttableptr;	
						address++;
					}
					
					
				}
				else
				{
					yyerror("ERROR-Multiple Declaration of same Variable");exit(0);
				}
			}
#line 2125 "y.tab.c"
    break;

  case 39:
#line 432 "task1.y"
                                {
           				int a;
           				a=get_func_label();
           				if(check_Reserved(Keywords,(yyvsp[-3].string)))
					{
						yyerror("ERROR a reserved word declared as variable");
					}
					else if(!GLookup(GTable,(yyvsp[-3].string)))
					{
						GInstall(&GTable,(yyvsp[-3].string),NULL,0,0,(yyvsp[-1].Pl),a);
						temp=GLookup(GTable,(yyvsp[-3].string));
						if(Cptr)
						{
							temp->Ctype=Cptr;
						}
						else
						{
							temp->type=ttableptr;	
						}
					}
					else
					{
						yyerror("ERROR-Multiple Declaration of same variable");exit(0);
					}
				}
#line 2155 "y.tab.c"
    break;

  case 40:
#line 458 "task1.y"
                                {
	   				//int b;
	   				if(check_Reserved(Keywords,(yyvsp[-3].string)))
					{
						yyerror("ERROR a reserved word declared as variable");
					}
					else if(!GLookup(GTable,(yyvsp[-3].string)))
					{
						GInstall(&GTable,(yyvsp[-3].string),NULL,(yyvsp[-1].a),address,NULL,0);
						temp=GLookup(GTable,(yyvsp[-3].string));
						if(Cptr)
						{
							temp->Ctype=Cptr;
						}
						else
						{
							temp->type=ttableptr;
						}
						address+=(yyvsp[-1].a);
					}
					else
					{
						yyerror("ERROR-Multiple Declaration of same Variable\n");exit(0);
					}
				}
#line 2185 "y.tab.c"
    break;

  case 41:
#line 485 "task1.y"
                                         {
						struct Paramstruct *temp_list;
						temp_list=(yyvsp[-2].Pl);
						//int flag=0;
						while(temp_list->next!=NULL)
						{
							//printf("%s %s --",temp_list->name,$<Pl>3->name);
							if(strcmp(temp_list->name,(yyvsp[0].Pl)->name))
								temp_list=temp_list->next;
							else
							{
								yyerror("ERROR- Failed Name equivalence of formal parameter");exit(0);
								//temp_list=temp_list->next;
							}
							//flag=1;
						}
						if(!strcmp(temp_list->name,(yyvsp[0].Pl)->name))
						{
							//printf("%s %s--\n",temp_list->name,$<Pl>3->name);
							yyerror("ERROR- Failed Name equivalence of parameter");exit(0);
						}
						temp_list->next=(yyvsp[0].Pl);
						(yyval.Pl)=(yyvsp[-2].Pl);
						//free(list);	  
					 }
#line 2215 "y.tab.c"
    break;

  case 42:
#line 510 "task1.y"
                                {(yyval.Pl)=(yyvsp[0].Pl);}
#line 2221 "y.tab.c"
    break;

  case 43:
#line 511 "task1.y"
                  {(yyval.Pl)=NULL;}
#line 2227 "y.tab.c"
    break;

  case 44:
#line 514 "task1.y"
                                {
       					struct Paramstruct * list;
					list=(struct Paramstruct*)malloc(sizeof(struct Paramstruct));
					list->name=(char*)malloc(sizeof(char)*100);
					strcpy(list->name,(yyvsp[0].string));
					list->type=(char*)malloc(sizeof(char)*100);
					strcpy(list->type,(yyvsp[-1].string));
					//list->type=$<a>1;
					list->next=NULL;
					(yyval.Pl)=list;
					//free(list);
				}
#line 2244 "y.tab.c"
    break;

  case 47:
#line 532 "task1.y"
                                            {
						pml=(yyvsp[0].Pl); gtemp=GLookup(GTable,(yyvsp[-2].string));m_temp=Class_Mlookup(Cptr,(yyvsp[-2].string));
					//	printf("**%s** ",Cptr->Name);
						if(gtemp==NULL && m_temp==NULL)
							yyerror("Function not declared");
						else if(m_temp && !check_func_param((yyvsp[0].Pl),m_temp->paramlist))
						{
							yyerror("Paramater error");exit(0);
						}
						else if(gtemp && !check_func_param((yyvsp[0].Pl),gtemp->paramlist))
						{
							yyerror("Paramter error");exit(0);
						}
						else
						{
							/* --if(m_temp)
								fprintf(target, "F%d:\n",m_temp->Flabel);
							else if(gtemp)
								fprintf(target, "F%d:\n",gtemp->flabel);
							fprintf(target,"PUSH BP\n");
							fprintf(target,"MOV BP, SP\n");*/
							int binding=-3;
							while(pml)
							{
								ttableptr=TLookup(T_Table,pml->type);
								if(!ttableptr)
								{	yyerror("ERROR - Type not defined in type table");exit(0);}
								LInstall(&temp_table,pml->name,ttableptr,binding);
								binding--;
								pml=pml->next;
							}
							if(m_temp)
							{
								ttableptr=TLookup(T_Table,"void");
								LInstall(&temp_table,"self",ttableptr,binding);
								binding--;
							}
						}
						//printf("check1");
									
					}
#line 2290 "y.tab.c"
    break;

  case 48:
#line 572 "task1.y"
                                                                                                                           {LTable=temp_table;temp_table=NULL;}
#line 2296 "y.tab.c"
    break;

  case 49:
#line 572 "task1.y"
                                                                                                                                                                        {m_temp=NULL;}
#line 2302 "y.tab.c"
    break;

  case 50:
#line 575 "task1.y"
                       {	/*--codeGen($<no>2,target,break_label,continue_label);*/temp1=LTable;
	  					/*---while(temp1)
	  					{	//printf("check1");
	  						if(temp1->binding>=1)
	  							fprintf(target,"POP R0\n");
	  						temp1=temp1->next;
	  					}*/}
#line 2314 "y.tab.c"
    break;

  case 52:
#line 582 "task1.y"
                        {	/*codeGen(NULL,target,break_label,continue_label);*/}
#line 2320 "y.tab.c"
    break;

  case 53:
#line 585 "task1.y"
                                {/*return_codeGen(target,$<no>2);*/}
#line 2326 "y.tab.c"
    break;

  case 54:
#line 588 "task1.y"
                     {(yyval.no) = createTree(0,2,3,"typeless",(yyvsp[-1].no),(yyvsp[0].no),NULL);}
#line 2332 "y.tab.c"
    break;

  case 55:
#line 589 "task1.y"
           {(yyval.no)=NULL;}
#line 2338 "y.tab.c"
    break;

  case 56:
#line 592 "task1.y"
                                 {	//printf("check1");
					gtemp=GLookup(GTable,(yyvsp[-3].string)); ltemp=Lookup(LTable,(yyvsp[-3].string)); //temp_list=PLookup(pml,$<string>1);
     					if(gtemp == NULL && ltemp==NULL){
                                        	yyerror("Undefined variable4");//exit(1);
					}
					/*if(ltemp && temp_list)
					{
						yyerror("Redefinition of variable");
						exit(0);
					}*/
					else
					{
						//printf("check1");
						if(ltemp)
                                			{(yyvsp[-3].no) = createID(0,1,(yyvsp[-3].string),0,ltemp->type->name,gtemp,NULL,NULL,NULL,NULL);/*printf("check2 ");printf("%d",ltemp->type);*/}
                                		/*else if(temp_list)
                                			{$<no>1 = createID(0,1,$<string>1,0,temp_list->type,NULL,NULL,NULL,NULL,NULL);}printf("check2 ");printf("%d",ltemp->type);*/
                                		else
                                		{
                                			if(gtemp->type)
                                				(yyvsp[-3].no) = createID(0,1,(yyvsp[-3].string),0,gtemp->type->name,gtemp,NULL,NULL,NULL,NULL);
                                			else if(gtemp->Ctype)
                                				(yyvsp[-3].no) = createID(0,1,(yyvsp[-3].string),0,gtemp->Ctype->Name,gtemp,NULL,NULL,NULL,NULL);
                                		}
                                			
                                	(yyvsp[-3].no)->Lentry = ltemp;
					(yyval.no) = createTree(0,2,4,"typeless",(yyvsp[-3].no),(yyvsp[-1].no),NULL);
				}
		}
#line 2372 "y.tab.c"
    break;

  case 57:
#line 622 "task1.y"
                                   {   gtemp=GLookup(GTable,(yyvsp[-3].string)); ltemp=Lookup(LTable,(yyvsp[-3].string));// temp_list=PLookup(pml,$<string>1);
     					if(gtemp == NULL && ltemp==NULL){
                                        	yyerror("Undefined variable4");//exit(1);
					}
					/*if(ltemp && temp_list)
					{
						yyerror("Redefinition of variable");
						exit(0);
					}*/
					else
					{
						if(ltemp)
                                			(yyvsp[-3].no) = createID(0,1,(yyvsp[-3].string),0,ltemp->type->name,gtemp,NULL,NULL,NULL,NULL);
                                		/*else if(temp_list)
                                			$<no>1 = createID(0,1,$<string>1,0,temp_list->type,NULL,NULL,NULL,NULL,NULL);*/
                                		else
                                		{
                                			if(gtemp->type)
                                				(yyvsp[-3].no) = createID(0,1,(yyvsp[-3].string),0,gtemp->type->name,gtemp,NULL,NULL,NULL,NULL);
                                			else if(gtemp->Ctype)
                                				(yyvsp[-3].no) = createID(0,1,(yyvsp[-3].string),0,gtemp->Ctype->Name,gtemp,NULL,NULL,NULL,NULL);
                                		}
                                        	(yyvsp[-3].no)->Lentry = ltemp;
						(yyvsp[-1].no)=createID(0,5,(yyvsp[-1].string),0,"str",NULL,NULL,NULL,NULL,NULL);
                                        	(yyval.no) = createTree(0,2,4,"typeless",(yyvsp[-3].no),(yyvsp[-1].no),NULL);
                                      }
                                  }
#line 2404 "y.tab.c"
    break;

  case 58:
#line 650 "task1.y"
                                        {
						 (yyvsp[-1].no)=createID(0,5,(yyvsp[-1].string),0,"str",NULL,NULL,NULL,NULL,NULL);
                                                (yyval.no) = createTree(0,2,4,"typeless",(yyvsp[-3].no),(yyvsp[-1].no),NULL);
                                           }
#line 2413 "y.tab.c"
    break;

  case 59:
#line 655 "task1.y"
                                      {(yyval.no) = createTree(0,2,4,"typeless",(yyvsp[-3].no),(yyvsp[-1].no),NULL);}
#line 2419 "y.tab.c"
    break;

  case 60:
#line 656 "task1.y"
                                        {(yyval.no) = createTree(0,2,4,"typeless",(yyvsp[-3].no),(yyvsp[-1].no),NULL);}
#line 2425 "y.tab.c"
    break;

  case 61:
#line 658 "task1.y"
                                        {
						(yyvsp[-1].no)=createID(0,5,(yyvsp[-1].string),0,"str",NULL,NULL,NULL,NULL,NULL);
						(yyval.no) = createTree(0,2,4,"typeless",(yyvsp[-3].no),(yyvsp[-1].no),NULL);
					}
#line 2434 "y.tab.c"
    break;

  case 62:
#line 663 "task1.y"
                                                        {(yyval.no) =createTree(0,2,15,"typeless",(yyvsp[-6].no),(yyvsp[-4].no),(yyvsp[-2].no));}
#line 2440 "y.tab.c"
    break;

  case 63:
#line 664 "task1.y"
                                             {(yyval.no) =createTree(0,2,15,"typeless",(yyvsp[-4].no),(yyvsp[-2].no),NULL);}
#line 2446 "y.tab.c"
    break;

  case 64:
#line 665 "task1.y"
                                        {(yyval.no) = createTree(0,2,1,"typeless",NULL,(yyvsp[-1].no),NULL);}
#line 2452 "y.tab.c"
    break;

  case 65:
#line 666 "task1.y"
                                        {(yyval.no) = createTree(0,2,2,"typeless",NULL,(yyvsp[-1].no),NULL);}
#line 2458 "y.tab.c"
    break;

  case 66:
#line 668 "task1.y"
                                         { 
	    				 	 (yyvsp[-2].no)=createID(0,5,(yyvsp[-2].string),0,"str",NULL,NULL,NULL,NULL,NULL);
	    				  	(yyval.no) = createTree(0,2,2,"typeless",NULL,(yyvsp[-2].no),NULL);
					}
#line 2467 "y.tab.c"
    break;

  case 67:
#line 673 "task1.y"
                                                 {(yyval.no)=createTree(0,2,16,"typeless",(yyvsp[-4].no),(yyvsp[-2].no),NULL);}
#line 2473 "y.tab.c"
    break;

  case 68:
#line 674 "task1.y"
                                {(yyval.no)=createTree(0,3,0,"typeless",NULL,NULL,NULL);}
#line 2479 "y.tab.c"
    break;

  case 69:
#line 675 "task1.y"
                                {(yyval.no)=createTree(0,4,0,"typeless",NULL,NULL,NULL);}
#line 2485 "y.tab.c"
    break;

  case 70:
#line 677 "task1.y"
                                               {
							gtemp=GLookup(GTable,(yyvsp[-5].string)); ltemp=Lookup(LTable,(yyvsp[-5].string));
     							if(gtemp == NULL && ltemp==NULL){
                                        			yyerror("Undefined variable");exit(1);
							}
							else
							{
								if(ltemp)
                                					(yyvsp[-5].no) = createID(0,1,(yyvsp[-5].string),0,ltemp->type->name,gtemp,NULL,NULL,NULL,NULL);
                                				else
                                					(yyvsp[-5].no) = createID(0,1,(yyvsp[-5].string),0,gtemp->type->name,gtemp,NULL,NULL,NULL,NULL);
                                		
                                				(yyvsp[-5].no)->Lentry = ltemp;
                                			}
							(yyval.no)=createTree(0,2,22,"typeless",(yyvsp[-5].no),NULL,NULL);
						}
#line 2506 "y.tab.c"
    break;

  case 71:
#line 694 "task1.y"
                                                  {(yyval.no)=createTree(0,2,22,"typeless",(yyvsp[-5].no),NULL,NULL);}
#line 2512 "y.tab.c"
    break;

  case 72:
#line 696 "task1.y"
                                          {
							gtemp=GLookup(GTable,(yyvsp[-5].string)); ltemp=Lookup(LTable,(yyvsp[-5].string));
     							if(gtemp == NULL && ltemp==NULL){
                                        			yyerror("Undefined variable");exit(1);
							}
							else
							{
								if(ltemp)
                                					(yyvsp[-5].no) = createID(0,1,(yyvsp[-5].string),0,ltemp->type->name,gtemp,NULL,NULL,NULL,NULL);
                                				else
                                					(yyvsp[-5].no) = createID(0,1,(yyvsp[-5].string),0,gtemp->type->name,gtemp,NULL,NULL,NULL,NULL);
                                		
                                				(yyvsp[-5].no)->Lentry = ltemp;
                                			}
							(yyval.no)=createTree(0,2,20,"typeless",(yyvsp[-5].no),NULL,NULL);
						}
#line 2533 "y.tab.c"
    break;

  case 73:
#line 713 "task1.y"
                                             {(yyval.no)=createTree(0,2,20,"typeless",(yyvsp[-5].no),NULL,NULL);}
#line 2539 "y.tab.c"
    break;

  case 74:
#line 715 "task1.y"
                                    {
							gtemp=GLookup(GTable,(yyvsp[-4].string)); ltemp=Lookup(LTable,(yyvsp[-4].string));
     							if(gtemp == NULL && ltemp==NULL){
                                        			yyerror("Undefined variable");exit(1);
							}
							else
							{
								if(ltemp)
                                					(yyvsp[-4].no) = createID(0,1,(yyvsp[-4].string),0,ltemp->type->name,gtemp,NULL,NULL,NULL,NULL);
                                				else
                                					(yyvsp[-4].no) = createID(0,1,(yyvsp[-4].string),0,gtemp->type->name,gtemp,NULL,NULL,NULL,NULL);
                                		
                                				(yyvsp[-4].no)->Lentry = ltemp;
                                			}
							(yyval.no)=createTree(0,2,21,"typeless",(yyvsp[-4].no),NULL,NULL);
					}
#line 2560 "y.tab.c"
    break;

  case 75:
#line 732 "task1.y"
                                        {(yyval.no)=createTree(0,2,21,"typeless",(yyvsp[-4].no),NULL,NULL);}
#line 2566 "y.tab.c"
    break;

  case 76:
#line 734 "task1.y"
                                           {
						gtemp=GLookup(GTable,(yyvsp[-6].string));
						if(gtemp == NULL){
                                        		yyerror("Undefined variable");exit(1);
						}
						else
						{
							if(gtemp->Ctype == NULL)
							{
								yyerror("ERROR-1");exit(0);
							}
							P_Cptr=CLookup(CTable,(yyvsp[-2].string));
							if(P_Cptr)
							{
								(yyvsp[-2].no) = createID(0,1,(yyvsp[-2].string),0,P_Cptr->Name,NULL,NULL,NULL,NULL,NULL);
								while(P_Cptr)
								{	
									/*if(gtemp->type)
										$<no>1 = createID(0,1,$<string>1,0,gtemp->type->name,gtemp,NULL,NULL,NULL,NULL);
									else if(gtemp->Ctype) */
								//printf("check1");
								//printf("**%s**%s** ",P_Cptr->Name,gtemp->Ctype->Name);
									if(strcmp(P_Cptr->Name,gtemp->Ctype->Name)==0)
									{
										(yyvsp[-6].no) = createID(0,1,(yyvsp[-6].string),0,gtemp->Ctype->Name,gtemp,NULL,NULL,NULL,NULL);
										(yyval.no)=createTree(0,11,0,(yyvsp[-2].string),(yyvsp[-6].no),(yyvsp[-2].no),NULL);
										break;
									}
									P_Cptr=P_Cptr->Parentptr;
								}
							}
							if(P_Cptr==NULL)
							{
								yyerror("Different class initialization error");exit(0);
							}
						}
					}
#line 2608 "y.tab.c"
    break;

  case 77:
#line 772 "task1.y"
                                                {
							
							P_Cptr=CLookup(CTable,(yyvsp[-2].string));
							if(P_Cptr)
							{
								(yyvsp[-2].no) = createID(0,1,(yyvsp[-2].string),0,P_Cptr->Name,NULL,NULL,NULL,NULL,NULL);
								while(P_Cptr)
								{	
									if(strcmp(P_Cptr->Name,(yyvsp[-6].no)->expr_type)==0)
									{
										(yyval.no)=createTree(0,11,0,(yyvsp[-2].string),(yyvsp[-6].no),(yyvsp[-2].no),NULL);
										break;
									}
									P_Cptr=P_Cptr->Parentptr;
								}
							}
							if(P_Cptr==NULL)
							{
								yyerror("Different class initialization error");exit(0);
							}
						}
#line 2634 "y.tab.c"
    break;

  case 78:
#line 795 "task1.y"
                         {(yyval.no) = createTree(0,2,5,"int",(yyvsp[-2].no),(yyvsp[0].no),NULL);}
#line 2640 "y.tab.c"
    break;

  case 79:
#line 796 "task1.y"
                          {(yyval.no) = createTree(0,2,6,"int",(yyvsp[-2].no),(yyvsp[0].no),NULL);}
#line 2646 "y.tab.c"
    break;

  case 80:
#line 797 "task1.y"
                        {(yyval.no) = createTree(0,2,7,"int",(yyvsp[-2].no),(yyvsp[0].no),NULL);}
#line 2652 "y.tab.c"
    break;

  case 81:
#line 798 "task1.y"
                        {(yyval.no) = createTree(0,2,8,"int",(yyvsp[-2].no),(yyvsp[0].no),NULL);}
#line 2658 "y.tab.c"
    break;

  case 82:
#line 799 "task1.y"
                         {(yyval.no) = createTree(0,2,19,"int",(yyvsp[-2].no),(yyvsp[0].no),NULL);}
#line 2664 "y.tab.c"
    break;

  case 83:
#line 800 "task1.y"
                       {(yyval.no)=(yyvsp[-1].no);}
#line 2670 "y.tab.c"
    break;

  case 84:
#line 801 "task1.y"
                {(yyval.no) =createTree((yyvsp[0].a),0,0,"int",NULL,NULL,NULL);}
#line 2676 "y.tab.c"
    break;

  case 85:
#line 802 "task1.y"
                                {	
					gtemp=GLookup(GTable,(yyvsp[0].string)); ltemp=Lookup(LTable,(yyvsp[0].string)); //temp_list=PLookup(pml,$<string>1);
     					if(gtemp == NULL && ltemp==NULL){
                                        	yyerror("Undefined variable");exit(1);
					}
					/*if(ltemp && temp_list)
					{
						yyerror("Redefinition of variable");
						exit(0);
					}*/
					else
					{
						if(ltemp)
                                			(yyvsp[0].no) = createID(0,1,(yyvsp[0].string),0,ltemp->type->name,gtemp,NULL,NULL,NULL,NULL);
                                		/*else if(temp_list)
                                			{$<no>1 = createID(0,1,$<string>1,0,temp_list->type,NULL,NULL,NULL,NULL,NULL);}printf("check2 ");printf("%d",temp_list->type);*/
                                		else
                                		{
                                			if(gtemp->type)
                                				(yyvsp[0].no) = createID(0,1,(yyvsp[0].string),0,gtemp->type->name,gtemp,NULL,NULL,NULL,NULL);
                                			else if(gtemp->Ctype)
                                				(yyvsp[0].no) = createID(0,1,(yyvsp[0].string),0,gtemp->Ctype->Name,gtemp,NULL,NULL,NULL,NULL);
                                		}
                                		
                                		(yyvsp[0].no)->Lentry = ltemp;
                                		(yyval.no)=(yyvsp[0].no);
                                	}
				}
#line 2709 "y.tab.c"
    break;

  case 86:
#line 830 "task1.y"
                             {
                                temp = GLookup(GTable,(yyvsp[-3].string));
                                if(temp == NULL){
                                	yyerror("EROR- Undefined function1");
                                }
                                else if(!check_func_arg((yyvsp[-1].Pl),temp->paramlist))
				 {
					yyerror("argument error");
				 }
                                else
                                {	
                                	(yyval.no) = createID(0,6,(yyvsp[-3].string),0,temp->type->name,temp,NULL,NULL,NULL,(yyvsp[-1].Pl));
                                	(yyval.no)->Gentry = temp;
                                }
                              }
#line 2729 "y.tab.c"
    break;

  case 87:
#line 861 "task1.y"
                        {(yyval.no) = createTree(0,2,17,"bool",(yyvsp[-2].no),(yyvsp[0].no),NULL);}
#line 2735 "y.tab.c"
    break;

  case 88:
#line 862 "task1.y"
                        {(yyval.no) = createTree(0,2,18,"bool",(yyvsp[-2].no),(yyvsp[0].no),NULL);}
#line 2741 "y.tab.c"
    break;

  case 89:
#line 863 "task1.y"
                        {(yyval.no) = createTree(0,2,9,"bool",(yyvsp[-2].no),(yyvsp[0].no),NULL);}
#line 2747 "y.tab.c"
    break;

  case 90:
#line 864 "task1.y"
                        {(yyval.no) = createTree(0,2,10,"bool",(yyvsp[-2].no),(yyvsp[0].no),NULL);}
#line 2753 "y.tab.c"
    break;

  case 91:
#line 865 "task1.y"
                        {(yyval.no) = createTree(0,2,11,"bool",(yyvsp[-2].no),(yyvsp[0].no),NULL);}
#line 2759 "y.tab.c"
    break;

  case 92:
#line 866 "task1.y"
                        {(yyval.no) = createTree(0,2,12,"bool",(yyvsp[-2].no),(yyvsp[0].no),NULL);}
#line 2765 "y.tab.c"
    break;

  case 93:
#line 867 "task1.y"
                        {(yyval.no) = createTree(0,2,13,"bool",(yyvsp[-2].no),(yyvsp[0].no),NULL);}
#line 2771 "y.tab.c"
    break;

  case 94:
#line 868 "task1.y"
                        {(yyval.no) = createTree(0,2,14,"bool",(yyvsp[-2].no),(yyvsp[0].no),NULL);}
#line 2777 "y.tab.c"
    break;

  case 95:
#line 869 "task1.y"
                         {(yyval.no)= (yyvsp[0].no);}
#line 2783 "y.tab.c"
    break;

  case 96:
#line 870 "task1.y"
                 {(yyval.no)= (yyvsp[0].no);}
#line 2789 "y.tab.c"
    break;

  case 97:
#line 871 "task1.y"
                        { (yyval.no) = createTree(0,9,0,"void",NULL,NULL,NULL);}
#line 2795 "y.tab.c"
    break;

  case 98:
#line 872 "task1.y"
                        {(yyval.no)=(yyvsp[0].no);}
#line 2801 "y.tab.c"
    break;

  case 99:
#line 875 "task1.y"
                        {	
				gtemp=GLookup(GTable,(yyvsp[-2].string)); ltemp=Lookup(LTable,(yyvsp[-2].string));
     				if(gtemp == NULL && ltemp==NULL){
                                       yyerror("Undefined variable");exit(1);
				}
				else
				{
					if(ltemp)
					{	//if(ltemp->type==NULL)
							//exit(0);
						F_list= FLookup(ltemp->type->fields,(yyvsp[0].string));
						if(F_list==NULL || F_list->type==NULL)
						{
							yyerror("Undefined variable");exit(1);
						}
						//if(F_list!=NULL)exit(0);
                               		(yyvsp[-2].no) = createID(0,1,(yyvsp[-2].string),0,ltemp->type->name,gtemp,NULL,NULL,NULL,NULL);
                               		
                               		(yyvsp[0].no) = createID(F_list->fieldIndex,1,(yyvsp[0].string),0,F_list->type->name,NULL,NULL,NULL,NULL,NULL);
                               		(yyval.no) = createTree(0,8,0,F_list->type->name,(yyvsp[-2].no),(yyvsp[0].no),NULL);
                               		
                               	}
                                	else
                                	{
                                		//if(gtemp->type==NULL)
						//	exit(0);
						if(gtemp->type)
							F_list= FLookup(gtemp->type->fields,(yyvsp[0].string));
						else if(gtemp->Ctype)
							F_list= FLookup(gtemp->Ctype->Memberfield,(yyvsp[0].string));
							
						if(F_list==NULL || F_list->type==NULL)
						{
							yyerror("Undefined variable");exit(1);
						}
						//if(F_list!=NULL)exit(0);
						if(gtemp->type)
                               			(yyvsp[-2].no) = createID(0,1,(yyvsp[-2].string),0,gtemp->type->name,gtemp,NULL,NULL,NULL,NULL);
                               		else if(gtemp->Ctype)
                               			(yyvsp[-2].no) = createID(0,1,(yyvsp[-2].string),0,gtemp->Ctype->Name,gtemp,NULL,NULL,NULL,NULL);
                               			
                               		(yyvsp[0].no) = createID(F_list->fieldIndex,1,(yyvsp[-2].string),0,F_list->type->name,NULL,NULL,NULL,NULL,NULL);
                               		(yyval.no) = createTree(0,8,0,F_list->type->name,(yyvsp[-2].no),(yyvsp[0].no),NULL);
                               		//if(F_list!=NULL)exit(0);
                               	}
                                		
                                	(yyvsp[-2].no)->Lentry = ltemp;
                                	(yyval.no)->Gentry = gtemp;
                                	(yyval.no)->Lentry = ltemp;
                                	
                               }
                              // $<no>$=NULL;
			}
#line 2859 "y.tab.c"
    break;

  case 100:
#line 929 "task1.y"
                        {
        				ttableptr=TLookup(T_Table,(yyvsp[-2].no)->expr_type);
        				c_temp=CLookup(CTable,(yyvsp[-2].no)->expr_type);
        				if(ttableptr)
        					F_list= FLookup(ttableptr->fields,(yyvsp[0].string));
        				else if(c_temp)
        					F_list= FLookup(c_temp->Memberfield,(yyvsp[0].string));
        				if(F_list==NULL || F_list->type==NULL)
					{
						yyerror("Undefined variable2");exit(1);
					}
					
					if(F_list->type)
                               		(yyvsp[0].no) = createID(F_list->fieldIndex,1,(yyvsp[0].string),0,F_list->type->name,NULL,NULL,NULL,NULL,NULL);
                               	else if(F_list->Ctype)
                               		(yyvsp[0].no) = createID(F_list->fieldIndex,1,(yyvsp[0].string),0,F_list->Ctype->Name,NULL,NULL,NULL,NULL,NULL);
                               		
                               	if(F_list->type)
                               		(yyval.no) = createTree(0,8,0,F_list->type->name,(yyvsp[-2].no),(yyvsp[0].no),NULL);
                               	else if(F_list->Ctype)
                               		(yyval.no) = createTree(0,8,0,F_list->Ctype->Name,(yyvsp[-2].no),(yyvsp[0].no),NULL);
        				/*gtemp=$<no>1->Gentry;
        				ltemp=$<no>1->Lentry;
        				if(gtemp == NULL && ltemp==NULL){
                                       	yyerror("Undefined variable1");exit(1);
					}
					else
					{
						if(ltemp)
						{
							if(ltemp->type==NULL)
							    exit(0);
							F_list= FLookup(ltemp->type->fields,$<string>3);
							if(F_list==NULL || F_list->type==NULL)
							{
								yyerror("Undefined variable2");exit(1);
							}
                               			$<no>3 = createID(F_list->fieldIndex,1,$<string>3,0,F_list->type->name,NULL,NULL,NULL,NULL,NULL);
                               			$<no>$ = createTree(0,8,0,F_list->type->name,$<no>1,$<no>3,NULL);
                               		}
                                		else
                                		{
                                			if(gtemp->type==NULL)
							     exit(0);
							F_list= FLookup(gtemp->type->fields,$<string>3);
							if(F_list==NULL || F_list->type==NULL)
							{
								yyerror("Undefined variable3");exit(1);
							}
                               			$<no>3 = createID(F_list->fieldIndex,1,$<string>1,0,F_list->type->name,NULL,NULL,NULL,NULL,NULL);
                               			$<no>$ = createTree(0,8,0,F_list->type->name,$<no>1,$<no>3,NULL);
                               		}
                                		
                                		$<no>1->Lentry = ltemp;
                                		$<no>$->Gentry = gtemp;
                                		$<no>$->Lentry = ltemp;
                               	}*/
                               	//$<no>$=NULL;
				}
#line 2923 "y.tab.c"
    break;

  case 101:
#line 988 "task1.y"
                                                 {
							//if(Cptr!=NULL) exit(0);
							//if(Cptr!=NULL) printf("**%s**",Cptr->Name);
							
							f_temp=Class_Flookup(Cptr,(yyvsp[0].string));//printf("**%s**",f_temp->name);
							if(f_temp==NULL)
							{	yyerror("Field not present1");exit(0);}
							
							else
                                			{	//if(f_temp->type==NULL)
                                				//	exit(0);
                                				(yyvsp[-2].no)= createID(0,1,"self",0,"typeless",NULL,NULL,NULL,NULL,NULL);
                                				if(f_temp->type)
                                					(yyvsp[0].no) = createID(f_temp->fieldIndex,1,(yyvsp[0].string),0,f_temp->type->name,NULL,NULL,NULL,NULL,NULL);
                                				else if(f_temp->Ctype)
                                					(yyvsp[0].no) = createID(f_temp->fieldIndex,1,(yyvsp[0].string),0,f_temp->Ctype->Name,NULL,NULL,NULL,NULL,NULL);
                                					
                                				if(f_temp->type)	
                               					(yyval.no) = createTree(0,8,0,f_temp->type->name,(yyvsp[-2].no),(yyvsp[0].no),NULL);
                               				else if(f_temp->Ctype)
                               					(yyval.no) = createTree(0,8,0,f_temp->Ctype->Name,(yyvsp[-2].no),(yyvsp[0].no),NULL);
                     					 }
						}
#line 2951 "y.tab.c"
    break;

  case 102:
#line 1013 "task1.y"
                                              {
							//printf("check1a");
							m_temp=Class_Mlookup(Cptr,(yyvsp[-3].string));
							if(m_temp==NULL)
								yyerror("Function not declared");
							else if(!check_func_arg((yyvsp[-1].Pl),m_temp->paramlist))
							{
								yyerror("Argument error");exit(0);
							}
							else
                                			{	
                                				//if(Cptr)
                                			//	printf("%s--%s ",Cptr->Name,$<string>3);
                                				(yyvsp[-5].no) = createID(0,1,"self",0,"typeless",NULL,NULL,NULL,NULL,NULL);
                                				(yyvsp[-3].no) = createID(m_temp->Flabel,10,(yyvsp[-3].string),0,m_temp->type->name,NULL,NULL,NULL,NULL,NULL);
                                				(yyval.no) = createID(0,10,(yyvsp[-3].string),0,m_temp->type->name,NULL,(yyvsp[-5].no),(yyvsp[-3].no),NULL,(yyvsp[-1].Pl));
                     					 }
						}
#line 2974 "y.tab.c"
    break;

  case 103:
#line 1031 "task1.y"
                                            {
						gtemp=GLookup(GTable,(yyvsp[-5].string));
						if(gtemp == NULL){
                                        		yyerror("Undefined variable");exit(1);
						}
						else
						{
							Cptr=gtemp->Ctype;
							//if(Cptr)
						//	printf("%s--%s ",Cptr->Name,$<string>3);
							m_temp=Class_Mlookup(Cptr,(yyvsp[-3].string));
							if(m_temp==NULL)
								yyerror("Function not declared");
							else if(!check_func_arg((yyvsp[-1].Pl),m_temp->paramlist))
							{
								yyerror("Argument Error");exit(0);
							}
							else
                                			{	
                                				(yyvsp[-5].no) = createID(0,1,(yyvsp[-5].string),0,gtemp->Ctype->Name,gtemp,NULL,NULL,NULL,NULL);
                                				(yyvsp[-3].no) = createID(m_temp->Flabel,10,(yyvsp[-3].string),0,m_temp->type->name,NULL,NULL,NULL,NULL,NULL);
                                				(yyval.no) = createID(0,10,(yyvsp[-3].string),0,m_temp->type->name,NULL,(yyvsp[-5].no),(yyvsp[-3].no),NULL,(yyvsp[-1].Pl));
                     					}
						}
						//printf("check1b");
					}
#line 3005 "y.tab.c"
    break;

  case 104:
#line 1058 "task1.y"
                                                {
								c_temp=CLookup(CTable,(yyvsp[-5].no)->expr_type);
							//	if(c_temp)
							//	printf("%s--%s ",c_temp->Name,$<string>3);
								//printf("**%s**",c_temp->Vfuncptr->name);
								m_temp=Class_Mlookup(c_temp,(yyvsp[-3].string));
								if(m_temp==NULL)
									yyerror("Function not declared2");
								else if(!check_func_arg((yyvsp[-1].Pl),m_temp->paramlist))
								{
									yyerror("Argument error");exit(0);
								}
								else
                                				{	
                                					(yyvsp[-3].no) = createID(m_temp->Flabel,10,(yyvsp[-3].string),0,m_temp->type->name,NULL,NULL,NULL,NULL,NULL);
                                					(yyval.no) = createID(0,10,(yyvsp[-3].string),0,m_temp->type->name,NULL,(yyvsp[-5].no),(yyvsp[-3].no),NULL,(yyvsp[-1].Pl));
                     						 }
                     					//printf("Check1a");
                     					}
#line 3029 "y.tab.c"
    break;

  case 105:
#line 1079 "task1.y"
                          {
                                temp=GLookup(GTable,(yyvsp[-3].string));
                                if(temp)
                                {
                                	if((yyvsp[-1].no)->type==0)
                                	{
                                		if((yyvsp[-1].no)->val>=temp->size)
						{
							yyerror("Index out of range");
							exit(0);
						}
                                	}
                                	else
                                	{
						if(strcmp((yyvsp[-1].no)->expr_type,"int")!=0)
						{
							{
								yyerror("Type mismatch");
								exit(0);
							}
						}
					}	
                                       (yyval.no) = createID(0,7,(yyvsp[-3].string),0,temp->type->name,temp,(yyvsp[-1].no),NULL,NULL,NULL);                                
                                }
                                else
                                {
                                        yyerror("ERROR-Variable not declared");
                                        exit(0);
                                }
                        }
#line 3064 "y.tab.c"
    break;

  case 106:
#line 1112 "task1.y"
                                {
                                        struct Paramstruct *temp_list,*list;
                                        list=(struct Paramstruct*)malloc(sizeof(struct Paramstruct));
                                        list->type=(char*)malloc(sizeof(char)*100);
                         		 list->type=(yyvsp[0].no)->expr_type;
                         		 list->val=(yyvsp[0].no);
                         		 list->next=NULL;
                         		 
                                        temp_list=(yyvsp[-2].Pl);
                                        //int flag=0;
                                       if(temp_list)
                                        {
                                        	while(temp_list->next!=NULL)
                                        	{
                                        	    temp_list=temp_list->next;
                                        	}
                                        	temp_list->next=list;
                                        	(yyval.Pl)=(yyvsp[-2].Pl);
                                        }
                                        else
                                        //free(list);    
						(yyval.Pl)=list;    
                               }
#line 3092 "y.tab.c"
    break;

  case 107:
#line 1136 "task1.y"
                               {
        				(yyvsp[0].no)=createID(0,5,(yyvsp[0].string),0,"str",NULL,NULL,NULL,NULL,NULL);
        				struct Paramstruct *temp_list,*list;
                                        list=(struct Paramstruct*)malloc(sizeof(struct Paramstruct));
                                        list->type=(char*)malloc(sizeof(char)*100);
                         		 list->type=(yyvsp[0].no)->expr_type;
                         		 list->name=(char*)malloc(sizeof(char)*100);
                         		 list->name=(yyvsp[0].string);
                         		 list->val=(yyvsp[0].no);
                         		 list->next=NULL;
                         		 
                         		 temp_list=(yyvsp[-2].Pl);
                                        //int flag=0;
                                        if(temp_list)
                                        {
                                        	while(temp_list->next!=NULL)
                                        	{
                                        	    temp_list=temp_list->next;
                                        	}
                                        	temp_list->next=list;
                                        	(yyval.Pl)=(yyvsp[-2].Pl);
                                        }
                                        else
                                        //free(list);    
						(yyval.Pl)=list;  
                               }
#line 3123 "y.tab.c"
    break;

  case 108:
#line 1163 "task1.y"
                {
                         struct Paramstruct * list;
                         list=(struct Paramstruct*)malloc(sizeof(struct Paramstruct));
                         list->type=(char*)malloc(sizeof(char)*100);
                         list->type=(yyvsp[0].no)->expr_type;
                         list->val=(yyvsp[0].no);
                         list->next=NULL;
                         (yyval.Pl)=list;
                         //free(list);
                }
#line 3138 "y.tab.c"
    break;

  case 109:
#line 1174 "task1.y"
                {
       		(yyvsp[0].no)=createID(0,5,(yyvsp[0].string),0,"str",NULL,NULL,NULL,NULL,NULL);
       		
       			struct Paramstruct * list;
                         	list=(struct Paramstruct*)malloc(sizeof(struct Paramstruct));
                         	list->type=(char*)malloc(sizeof(char)*100);
                        	list->type=(yyvsp[0].no)->expr_type;
                         	list->name=(char*)malloc(sizeof(char)*100);
                         	strcpy(list->name,(yyvsp[0].string));
                         	list->val=(yyvsp[0].no);
                         	list->next=NULL;
                         	(yyval.Pl)=list;
                         //free(list);
                }
#line 3157 "y.tab.c"
    break;

  case 110:
#line 1189 "task1.y"
          {(yyval.Pl)=NULL;}
#line 3163 "y.tab.c"
    break;

  case 111:
#line 1193 "task1.y"
                              {pml=NULL; /*--fprintf(target, "MAIN:\n"); fprintf(target,"PUSH BP\n"); fprintf(target,"MOV BP, SP\n");*/}
#line 3169 "y.tab.c"
    break;

  case 112:
#line 1195 "task1.y"
                                        {	
						ttableptr=TLookup(T_Table,(yyvsp[-4].string));
						if(!ttableptr)
	   					{
	   						yyerror("type not defined in type table");exit(0);
	   					}
	  					GInstall(&GTable,"MAIN",ttableptr,0,0,NULL,0);
	  					//LTable=NULL;
						//some more work to be done
					}
#line 3184 "y.tab.c"
    break;

  case 113:
#line 1205 "task1.y"
                                                          {LTable=temp_table;temp_table=NULL;}
#line 3190 "y.tab.c"
    break;

  case 115:
#line 1208 "task1.y"
                                         {
						temp1=temp_table;
						printf("LST---------\n");
					
					//	if(temp_table!=NULL)
					//		printf("check2");
					
						while(temp1)
        					{
         						printf("%s ",temp1->name);
         						if(temp1->binding>0);
        					        printf("type=%s ",temp1->type->name);
        					       // printf("size =%d ",temp1->size);
        					       printf("binding =%d ",temp1->binding);
         					       F_list=temp1->type->fields;
	 					       if(F_list)
	    					       {
								printf("Fields = ");
								while(F_list)
								{
									printf("%s - ",F_list->name);
									F_list=F_list->next;
								}
	    						 }
	     						else
								printf("Fields = NULL");
              						temp1=temp1->next;
              						printf("\n");
        					}
        					printf("-----------------\n");
        					lbinding=1;
        				}
#line 3227 "y.tab.c"
    break;

  case 116:
#line 1241 "task1.y"
                                {
	        			lbinding=1;temp1=temp_table;
					printf("LST---------\n");
					
					//if(temp_table!=NULL)
					//	printf("check2");
					
					while(temp1)
        				{
              					printf("%s ",temp1->name);
              					if(temp1->binding>0);
              					printf("type=%s ",temp1->type->name);
             					// printf("size =%d ",temp1->size);
              					printf("binding =%d ",temp1->binding);
              					F_list=temp1->type->fields;
	     					if(F_list)
	     					{
							printf("Fields = ");
							while(F_list)
							{
								printf("%s - ",F_list->name);
								F_list=F_list->next;
							}
	     					}
	     					else
							printf("Fields = NULL");
              					temp1=temp1->next;
              					printf("\n");
        				}
        				printf("-----------------\n");
        				}
#line 3263 "y.tab.c"
    break;

  case 117:
#line 1273 "task1.y"
         {
        	lbinding=1;temp1=temp_table;
		printf("LST---------\n");
		if(temp_table==NULL)
			exit(0);
		while(temp1)
        	{
              		printf("%s ",temp1->name);
              		if(temp1->binding>0);
              		printf("type=%s ",temp1->type->name);
             		// printf("size =%d ",temp1->size);
              		printf("binding =%d ",temp1->binding);
              		F_list=temp1->type->fields;
	     		if(F_list)
	     		{
				printf("Fields = ");
				while(F_list)
				{
					printf("%s - ",F_list->name);
					F_list=F_list->next;
				}
	     		}
	     		else
				printf("Fields = NULL");
              		temp1=temp1->next;
             		printf("\n");
        	}
        	printf("-----------------\n");
        }
#line 3297 "y.tab.c"
    break;

  case 120:
#line 1308 "task1.y"
                                            {	
						ttableptr=TLookup(T_Table,(yyvsp[-2].string));
						if(!ttableptr)
	   					{
	   						yyerror("type not defined in type table");exit(0);
	   					}
						
       					temp1=temp_table;
						while(temp1 && temp1->type==NULL)
						{
							temp1->type=ttableptr;
							temp1=temp1->next;
						}
					}
#line 3316 "y.tab.c"
    break;

  case 121:
#line 1324 "task1.y"
                                        {	//printf("check2");
				if(check_Reserved(Keywords,(yyvsp[0].string)))
				{
					yyerror("ERROR reserved word declared as variable");
				}
				else if(!Lookup(temp_table,(yyvsp[0].string)))
	 		     	{
	 		     		//printf("**%d **",lbinding);
	 				LInstall(&temp_table,(yyvsp[0].string),NULL,lbinding);
					lbinding++;
				       //--- fprintf(target,"PUSH R0\n");
				}
				else
				{
					yyerror("ERROR-Multiple Declaration of same variable");
				}
			     }
#line 3338 "y.tab.c"
    break;

  case 122:
#line 1341 "task1.y"
                     {	//printf("check3");
			if(check_Reserved(Keywords,(yyvsp[0].string)))
			{
				yyerror("ERROR reserved word declared as variable");
			}
			else if(!Lookup(temp_table,(yyvsp[0].string)))
                         {
                         	// printf("**%d **",lbinding);
                         	 LInstall(&temp_table,(yyvsp[0].string),NULL,lbinding);
                                lbinding++;
                                //--- fprintf(target,"PUSH R0\n");
                         }
                         else
			 {
                                yyerror("ERROR-Multiple Declaration of same variable");
			 }
		}
#line 3360 "y.tab.c"
    break;

  case 123:
#line 1360 "task1.y"
                      {(yyval.string)=(yyvsp[0].string);}
#line 3366 "y.tab.c"
    break;

  case 124:
#line 1361 "task1.y"
                      {(yyval.string)=(yyvsp[0].string);}
#line 3372 "y.tab.c"
    break;

  case 125:
#line 1362 "task1.y"
                      {(yyval.string)=(yyvsp[0].string);}
#line 3378 "y.tab.c"
    break;


#line 3382 "y.tab.c"

      default: break;
    }
  /* User semantic actions sometimes alter yychar, and that requires
     that yytoken be updated with the new translation.  We take the
     approach of translating immediately before every use of yytoken.
     One alternative is translating here after every semantic action,
     but that translation would be missed if the semantic action invokes
     YYABORT, YYACCEPT, or YYERROR immediately after altering yychar or
     if it invokes YYBACKUP.  In the case of YYABORT or YYACCEPT, an
     incorrect destructor might then be invoked immediately.  In the
     case of YYERROR or YYBACKUP, subsequent parser actions might lead
     to an incorrect destructor call or verbose syntax error message
     before the lookahead is translated.  */
  YY_SYMBOL_PRINT ("-> $$ =", yyr1[yyn], &yyval, &yyloc);

  YYPOPSTACK (yylen);
  yylen = 0;
  YY_STACK_PRINT (yyss, yyssp);

  *++yyvsp = yyval;

  /* Now 'shift' the result of the reduction.  Determine what state
     that goes to, based on the state we popped back to and the rule
     number reduced by.  */
  {
    const int yylhs = yyr1[yyn] - YYNTOKENS;
    const int yyi = yypgoto[yylhs] + *yyssp;
    yystate = (0 <= yyi && yyi <= YYLAST && yycheck[yyi] == *yyssp
               ? yytable[yyi]
               : yydefgoto[yylhs]);
  }

  goto yynewstate;


/*--------------------------------------.
| yyerrlab -- here on detecting error.  |
`--------------------------------------*/
yyerrlab:
  /* Make sure we have latest lookahead translation.  See comments at
     user semantic actions for why this is necessary.  */
  yytoken = yychar == YYEMPTY ? YYEMPTY : YYTRANSLATE (yychar);

  /* If not already recovering from an error, report this error.  */
  if (!yyerrstatus)
    {
      ++yynerrs;
#if ! YYERROR_VERBOSE
      yyerror (YY_("syntax error"));
#else
# define YYSYNTAX_ERROR yysyntax_error (&yymsg_alloc, &yymsg, \
                                        yyssp, yytoken)
      {
        char const *yymsgp = YY_("syntax error");
        int yysyntax_error_status;
        yysyntax_error_status = YYSYNTAX_ERROR;
        if (yysyntax_error_status == 0)
          yymsgp = yymsg;
        else if (yysyntax_error_status == 1)
          {
            if (yymsg != yymsgbuf)
              YYSTACK_FREE (yymsg);
            yymsg = YY_CAST (char *, YYSTACK_ALLOC (YY_CAST (YYSIZE_T, yymsg_alloc)));
            if (!yymsg)
              {
                yymsg = yymsgbuf;
                yymsg_alloc = sizeof yymsgbuf;
                yysyntax_error_status = 2;
              }
            else
              {
                yysyntax_error_status = YYSYNTAX_ERROR;
                yymsgp = yymsg;
              }
          }
        yyerror (yymsgp);
        if (yysyntax_error_status == 2)
          goto yyexhaustedlab;
      }
# undef YYSYNTAX_ERROR
#endif
    }



  if (yyerrstatus == 3)
    {
      /* If just tried and failed to reuse lookahead token after an
         error, discard it.  */

      if (yychar <= YYEOF)
        {
          /* Return failure if at end of input.  */
          if (yychar == YYEOF)
            YYABORT;
        }
      else
        {
          yydestruct ("Error: discarding",
                      yytoken, &yylval);
          yychar = YYEMPTY;
        }
    }

  /* Else will try to reuse lookahead token after shifting the error
     token.  */
  goto yyerrlab1;


/*---------------------------------------------------.
| yyerrorlab -- error raised explicitly by YYERROR.  |
`---------------------------------------------------*/
yyerrorlab:
  /* Pacify compilers when the user code never invokes YYERROR and the
     label yyerrorlab therefore never appears in user code.  */
  if (0)
    YYERROR;

  /* Do not reclaim the symbols of the rule whose action triggered
     this YYERROR.  */
  YYPOPSTACK (yylen);
  yylen = 0;
  YY_STACK_PRINT (yyss, yyssp);
  yystate = *yyssp;
  goto yyerrlab1;


/*-------------------------------------------------------------.
| yyerrlab1 -- common code for both syntax error and YYERROR.  |
`-------------------------------------------------------------*/
yyerrlab1:
  yyerrstatus = 3;      /* Each real token shifted decrements this.  */

  for (;;)
    {
      yyn = yypact[yystate];
      if (!yypact_value_is_default (yyn))
        {
          yyn += YYTERROR;
          if (0 <= yyn && yyn <= YYLAST && yycheck[yyn] == YYTERROR)
            {
              yyn = yytable[yyn];
              if (0 < yyn)
                break;
            }
        }

      /* Pop the current state because it cannot handle the error token.  */
      if (yyssp == yyss)
        YYABORT;


      yydestruct ("Error: popping",
                  yystos[yystate], yyvsp);
      YYPOPSTACK (1);
      yystate = *yyssp;
      YY_STACK_PRINT (yyss, yyssp);
    }

  YY_IGNORE_MAYBE_UNINITIALIZED_BEGIN
  *++yyvsp = yylval;
  YY_IGNORE_MAYBE_UNINITIALIZED_END


  /* Shift the error token.  */
  YY_SYMBOL_PRINT ("Shifting", yystos[yyn], yyvsp, yylsp);

  yystate = yyn;
  goto yynewstate;


/*-------------------------------------.
| yyacceptlab -- YYACCEPT comes here.  |
`-------------------------------------*/
yyacceptlab:
  yyresult = 0;
  goto yyreturn;


/*-----------------------------------.
| yyabortlab -- YYABORT comes here.  |
`-----------------------------------*/
yyabortlab:
  yyresult = 1;
  goto yyreturn;


#if !defined yyoverflow || YYERROR_VERBOSE
/*-------------------------------------------------.
| yyexhaustedlab -- memory exhaustion comes here.  |
`-------------------------------------------------*/
yyexhaustedlab:
  yyerror (YY_("memory exhausted"));
  yyresult = 2;
  /* Fall through.  */
#endif


/*-----------------------------------------------------.
| yyreturn -- parsing is finished, return the result.  |
`-----------------------------------------------------*/
yyreturn:
  if (yychar != YYEMPTY)
    {
      /* Make sure we have latest lookahead translation.  See comments at
         user semantic actions for why this is necessary.  */
      yytoken = YYTRANSLATE (yychar);
      yydestruct ("Cleanup: discarding lookahead",
                  yytoken, &yylval);
    }
  /* Do not reclaim the symbols of the rule whose action triggered
     this YYABORT or YYACCEPT.  */
  YYPOPSTACK (yylen);
  YY_STACK_PRINT (yyss, yyssp);
  while (yyssp != yyss)
    {
      yydestruct ("Cleanup: popping",
                  yystos[+*yyssp], yyvsp);
      YYPOPSTACK (1);
    }
#ifndef yyoverflow
  if (yyss != yyssa)
    YYSTACK_FREE (yyss);
#endif
#if YYERROR_VERBOSE
  if (yymsg != yymsgbuf)
    YYSTACK_FREE (yymsg);
#endif
  return yyresult;
}
#line 1364 "task1.y"


int yyerror(char const *s)
{
	printf("yyerror %s at line no %d\n",s,yylineno);exit(0);
}

int main(void)
{
	FILE *fp;
	fp=fopen("input","r");
	yyin=fp;
	target=fopen("task2.xsm","w");
	if(target==NULL)
	{
		printf("Can not be written to file\n");
		exit(0);
	}
	fprintf(target, "%d\n%d\n%d\n%d\n%d\n%d\n%d\n%d\n",0,2056,0,0,0,0,0,0);
	fprintf(target, "BRKP\n");
	//exit(0);
	yyparse();
	fclose(target);
	
	return 0;
}
