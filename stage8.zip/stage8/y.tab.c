/* A Bison parser, made by GNU Bison 3.5.1.  */

/* Bison implementation for Yacc-like parsers in C

   Copyright (C) 1984, 1989-1990, 2000-2015, 2018-2020 Free Software Foundation,
   Inc.

   This program is free software: you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation, either version 3 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program.  If not, see <http://www.gnu.org/licenses/>.  */

/* As a special exception, you may create a larger work that contains
   part or all of the Bison parser skeleton and distribute that work
   under terms of your choice, so long as that work isn't itself a
   parser generator using the skeleton or a modified version thereof
   as a parser skeleton.  Alternatively, if you modify or redistribute
   the parser skeleton itself, you may (at your option) remove this
   special exception, which will cause the skeleton and the resulting
   Bison output files to be licensed under the GNU General Public
   License without this special exception.

   This special exception was added by the Free Software Foundation in
   version 2.2 of Bison.  */

/* C LALR(1) parser skeleton written by Richard Stallman, by
   simplifying the original so-called "semantic" parser.  */

/* All symbols defined below should begin with yy or YY, to avoid
   infringing on user name space.  This should be done even for local
   variables, as they might otherwise be expanded by user macros.
   There are some unavoidable exceptions within include files to
   define necessary library symbols; they are noted "INFRINGES ON
   USER NAME SPACE" below.  */

/* Undocumented macros, especially those whose name start with YY_,
   are private implementation details.  Do not rely on them.  */

/* Identify Bison output.  */
#define YYBISON 1

/* Bison version.  */
#define YYBISON_VERSION "3.5.1"

/* Skeleton name.  */
#define YYSKELETON_NAME "yacc.c"

/* Pure parsers.  */
#define YYPURE 0

/* Push parsers.  */
#define YYPUSH 0

/* Pull parsers.  */
#define YYPULL 1




/* First part of user prologue.  */
#line 1 "task1.y"

	#include<stdlib.h>
	#include<stdio.h>
	#include<string.h>
	#include "task1.h"
	#include "task1.c"
	int yylex(void);
	extern FILE *yyin;
	int lbinding=1;
	int position=0;
	int f_position=0;
	int m_position=0;
	extern int yylineno;
	int yyerror(char const *s);
	int Class_index=0;
	FILE * target;
	int GLabel;
	int temp_address=1;
	

#line 91 "y.tab.c"

# ifndef YY_CAST
#  ifdef __cplusplus
#   define YY_CAST(Type, Val) static_cast<Type> (Val)
#   define YY_REINTERPRET_CAST(Type, Val) reinterpret_cast<Type> (Val)
#  else
#   define YY_CAST(Type, Val) ((Type) (Val))
#   define YY_REINTERPRET_CAST(Type, Val) ((Type) (Val))
#  endif
# endif
# ifndef YY_NULLPTR
#  if defined __cplusplus
#   if 201103L <= __cplusplus
#    define YY_NULLPTR nullptr
#   else
#    define YY_NULLPTR 0
#   endif
#  else
#   define YY_NULLPTR ((void*)0)
#  endif
# endif

/* Enabling verbose error messages.  */
#ifdef YYERROR_VERBOSE
# undef YYERROR_VERBOSE
# define YYERROR_VERBOSE 1
#else
# define YYERROR_VERBOSE 0
#endif

/* Use api.header.include to #include this header
   instead of duplicating it here.  */
#ifndef YY_YY_Y_TAB_H_INCLUDED
# define YY_YY_Y_TAB_H_INCLUDED
/* Debug traces.  */
#ifndef YYDEBUG
# define YYDEBUG 0
#endif
#if YYDEBUG
extern int yydebug;
#endif

/* Token type.  */
#ifndef YYTOKENTYPE
# define YYTOKENTYPE
  enum yytokentype
  {
    ID = 258,
    NUM = 259,
    INT = 260,
    STR = 261,
    SEMICOLON = 262,
    COMMA = 263,
    ASGN = 264,
    ALLOC = 265,
    FREE = 266,
    READ = 267,
    WRITE = 268,
    IF = 269,
    THEN = 270,
    ELSE = 271,
    ENDIF = 272,
    PLUS = 273,
    MINUS = 274,
    MUL = 275,
    DIV = 276,
    MAIN = 277,
    DECL = 278,
    ENDDECL = 279,
    BEGINE = 280,
    END = 281,
    STRING = 282,
    RETURN = 283,
    LT = 284,
    GT = 285,
    LE = 286,
    GE = 287,
    EQ = 288,
    NE = 289,
    DOT = 290,
    WHILE = 291,
    DO = 292,
    ENDWHILE = 293,
    BREAK = 294,
    CONTINUE = 295,
    MOD = 296,
    TYPE = 297,
    ENDTYPE = 298,
    null = 299,
    INITIALIZE = 300,
    CLASS = 301,
    ENDCLASS = 302,
    SELF = 303,
    NEW = 304,
    Extends = 305,
    OR = 306,
    AND = 307
  };
#endif
/* Tokens.  */
#define ID 258
#define NUM 259
#define INT 260
#define STR 261
#define SEMICOLON 262
#define COMMA 263
#define ASGN 264
#define ALLOC 265
#define FREE 266
#define READ 267
#define WRITE 268
#define IF 269
#define THEN 270
#define ELSE 271
#define ENDIF 272
#define PLUS 273
#define MINUS 274
#define MUL 275
#define DIV 276
#define MAIN 277
#define DECL 278
#define ENDDECL 279
#define BEGINE 280
#define END 281
#define STRING 282
#define RETURN 283
#define LT 284
#define GT 285
#define LE 286
#define GE 287
#define EQ 288
#define NE 289
#define DOT 290
#define WHILE 291
#define DO 292
#define ENDWHILE 293
#define BREAK 294
#define CONTINUE 295
#define MOD 296
#define TYPE 297
#define ENDTYPE 298
#define null 299
#define INITIALIZE 300
#define CLASS 301
#define ENDCLASS 302
#define SELF 303
#define NEW 304
#define Extends 305
#define OR 306
#define AND 307

/* Value type.  */
#if ! defined YYSTYPE && ! defined YYSTYPE_IS_DECLARED
union YYSTYPE
{
#line 22 "task1.y"

	char *string;
	int a;
	struct Paramstruct *Pl;
	struct ASTNode *no;
	struct Fieldlist *Fl;

#line 255 "y.tab.c"

};
typedef union YYSTYPE YYSTYPE;
# define YYSTYPE_IS_TRIVIAL 1
# define YYSTYPE_IS_DECLARED 1
#endif


extern YYSTYPE yylval;

int yyparse (void);

#endif /* !YY_YY_Y_TAB_H_INCLUDED  */



#ifdef short
# undef short
#endif

/* On compilers that do not define __PTRDIFF_MAX__ etc., make sure
   <limits.h> and (if available) <stdint.h> are included
   so that the code can choose integer types of a good width.  */

#ifndef __PTRDIFF_MAX__
# include <limits.h> /* INFRINGES ON USER NAME SPACE */
# if defined __STDC_VERSION__ && 199901 <= __STDC_VERSION__
#  include <stdint.h> /* INFRINGES ON USER NAME SPACE */
#  define YY_STDINT_H
# endif
#endif

/* Narrow types that promote to a signed type and that can represent a
   signed or unsigned integer of at least N bits.  In tables they can
   save space and decrease cache pressure.  Promoting to a signed type
   helps avoid bugs in integer arithmetic.  */

#ifdef __INT_LEAST8_MAX__
typedef __INT_LEAST8_TYPE__ yytype_int8;
#elif defined YY_STDINT_H
typedef int_least8_t yytype_int8;
#else
typedef signed char yytype_int8;
#endif

#ifdef __INT_LEAST16_MAX__
typedef __INT_LEAST16_TYPE__ yytype_int16;
#elif defined YY_STDINT_H
typedef int_least16_t yytype_int16;
#else
typedef short yytype_int16;
#endif

#if defined __UINT_LEAST8_MAX__ && __UINT_LEAST8_MAX__ <= __INT_MAX__
typedef __UINT_LEAST8_TYPE__ yytype_uint8;
#elif (!defined __UINT_LEAST8_MAX__ && defined YY_STDINT_H \
       && UINT_LEAST8_MAX <= INT_MAX)
typedef uint_least8_t yytype_uint8;
#elif !defined __UINT_LEAST8_MAX__ && UCHAR_MAX <= INT_MAX
typedef unsigned char yytype_uint8;
#else
typedef short yytype_uint8;
#endif

#if defined __UINT_LEAST16_MAX__ && __UINT_LEAST16_MAX__ <= __INT_MAX__
typedef __UINT_LEAST16_TYPE__ yytype_uint16;
#elif (!defined __UINT_LEAST16_MAX__ && defined YY_STDINT_H \
       && UINT_LEAST16_MAX <= INT_MAX)
typedef uint_least16_t yytype_uint16;
#elif !defined __UINT_LEAST16_MAX__ && USHRT_MAX <= INT_MAX
typedef unsigned short yytype_uint16;
#else
typedef int yytype_uint16;
#endif

#ifndef YYPTRDIFF_T
# if defined __PTRDIFF_TYPE__ && defined __PTRDIFF_MAX__
#  define YYPTRDIFF_T __PTRDIFF_TYPE__
#  define YYPTRDIFF_MAXIMUM __PTRDIFF_MAX__
# elif defined PTRDIFF_MAX
#  ifndef ptrdiff_t
#   include <stddef.h> /* INFRINGES ON USER NAME SPACE */
#  endif
#  define YYPTRDIFF_T ptrdiff_t
#  define YYPTRDIFF_MAXIMUM PTRDIFF_MAX
# else
#  define YYPTRDIFF_T long
#  define YYPTRDIFF_MAXIMUM LONG_MAX
# endif
#endif

#ifndef YYSIZE_T
# ifdef __SIZE_TYPE__
#  define YYSIZE_T __SIZE_TYPE__
# elif defined size_t
#  define YYSIZE_T size_t
# elif defined __STDC_VERSION__ && 199901 <= __STDC_VERSION__
#  include <stddef.h> /* INFRINGES ON USER NAME SPACE */
#  define YYSIZE_T size_t
# else
#  define YYSIZE_T unsigned
# endif
#endif

#define YYSIZE_MAXIMUM                                  \
  YY_CAST (YYPTRDIFF_T,                                 \
           (YYPTRDIFF_MAXIMUM < YY_CAST (YYSIZE_T, -1)  \
            ? YYPTRDIFF_MAXIMUM                         \
            : YY_CAST (YYSIZE_T, -1)))

#define YYSIZEOF(X) YY_CAST (YYPTRDIFF_T, sizeof (X))

/* Stored state numbers (used for stacks). */
typedef yytype_int16 yy_state_t;

/* State numbers in computations.  */
typedef int yy_state_fast_t;

#ifndef YY_
# if defined YYENABLE_NLS && YYENABLE_NLS
#  if ENABLE_NLS
#   include <libintl.h> /* INFRINGES ON USER NAME SPACE */
#   define YY_(Msgid) dgettext ("bison-runtime", Msgid)
#  endif
# endif
# ifndef YY_
#  define YY_(Msgid) Msgid
# endif
#endif

#ifndef YY_ATTRIBUTE_PURE
# if defined __GNUC__ && 2 < __GNUC__ + (96 <= __GNUC_MINOR__)
#  define YY_ATTRIBUTE_PURE __attribute__ ((__pure__))
# else
#  define YY_ATTRIBUTE_PURE
# endif
#endif

#ifndef YY_ATTRIBUTE_UNUSED
# if defined __GNUC__ && 2 < __GNUC__ + (7 <= __GNUC_MINOR__)
#  define YY_ATTRIBUTE_UNUSED __attribute__ ((__unused__))
# else
#  define YY_ATTRIBUTE_UNUSED
# endif
#endif

/* Suppress unused-variable warnings by "using" E.  */
#if ! defined lint || defined __GNUC__
# define YYUSE(E) ((void) (E))
#else
# define YYUSE(E) /* empty */
#endif

#if defined __GNUC__ && ! defined __ICC && 407 <= __GNUC__ * 100 + __GNUC_MINOR__
/* Suppress an incorrect diagnostic about yylval being uninitialized.  */
# define YY_IGNORE_MAYBE_UNINITIALIZED_BEGIN                            \
    _Pragma ("GCC diagnostic push")                                     \
    _Pragma ("GCC diagnostic ignored \"-Wuninitialized\"")              \
    _Pragma ("GCC diagnostic ignored \"-Wmaybe-uninitialized\"")
# define YY_IGNORE_MAYBE_UNINITIALIZED_END      \
    _Pragma ("GCC diagnostic pop")
#else
# define YY_INITIAL_VALUE(Value) Value
#endif
#ifndef YY_IGNORE_MAYBE_UNINITIALIZED_BEGIN
# define YY_IGNORE_MAYBE_UNINITIALIZED_BEGIN
# define YY_IGNORE_MAYBE_UNINITIALIZED_END
#endif
#ifndef YY_INITIAL_VALUE
# define YY_INITIAL_VALUE(Value) /* Nothing. */
#endif

#if defined __cplusplus && defined __GNUC__ && ! defined __ICC && 6 <= __GNUC__
# define YY_IGNORE_USELESS_CAST_BEGIN                          \
    _Pragma ("GCC diagnostic push")                            \
    _Pragma ("GCC diagnostic ignored \"-Wuseless-cast\"")
# define YY_IGNORE_USELESS_CAST_END            \
    _Pragma ("GCC diagnostic pop")
#endif
#ifndef YY_IGNORE_USELESS_CAST_BEGIN
# define YY_IGNORE_USELESS_CAST_BEGIN
# define YY_IGNORE_USELESS_CAST_END
#endif


#define YY_ASSERT(E) ((void) (0 && (E)))

#if ! defined yyoverflow || YYERROR_VERBOSE

/* The parser invokes alloca or malloc; define the necessary symbols.  */

# ifdef YYSTACK_USE_ALLOCA
#  if YYSTACK_USE_ALLOCA
#   ifdef __GNUC__
#    define YYSTACK_ALLOC __builtin_alloca
#   elif defined __BUILTIN_VA_ARG_INCR
#    include <alloca.h> /* INFRINGES ON USER NAME SPACE */
#   elif defined _AIX
#    define YYSTACK_ALLOC __alloca
#   elif defined _MSC_VER
#    include <malloc.h> /* INFRINGES ON USER NAME SPACE */
#    define alloca _alloca
#   else
#    define YYSTACK_ALLOC alloca
#    if ! defined _ALLOCA_H && ! defined EXIT_SUCCESS
#     include <stdlib.h> /* INFRINGES ON USER NAME SPACE */
      /* Use EXIT_SUCCESS as a witness for stdlib.h.  */
#     ifndef EXIT_SUCCESS
#      define EXIT_SUCCESS 0
#     endif
#    endif
#   endif
#  endif
# endif

# ifdef YYSTACK_ALLOC
   /* Pacify GCC's 'empty if-body' warning.  */
#  define YYSTACK_FREE(Ptr) do { /* empty */; } while (0)
#  ifndef YYSTACK_ALLOC_MAXIMUM
    /* The OS might guarantee only one guard page at the bottom of the stack,
       and a page size can be as small as 4096 bytes.  So we cannot safely
       invoke alloca (N) if N exceeds 4096.  Use a slightly smaller number
       to allow for a few compiler-allocated temporary stack slots.  */
#   define YYSTACK_ALLOC_MAXIMUM 4032 /* reasonable circa 2006 */
#  endif
# else
#  define YYSTACK_ALLOC YYMALLOC
#  define YYSTACK_FREE YYFREE
#  ifndef YYSTACK_ALLOC_MAXIMUM
#   define YYSTACK_ALLOC_MAXIMUM YYSIZE_MAXIMUM
#  endif
#  if (defined __cplusplus && ! defined EXIT_SUCCESS \
       && ! ((defined YYMALLOC || defined malloc) \
             && (defined YYFREE || defined free)))
#   include <stdlib.h> /* INFRINGES ON USER NAME SPACE */
#   ifndef EXIT_SUCCESS
#    define EXIT_SUCCESS 0
#   endif
#  endif
#  ifndef YYMALLOC
#   define YYMALLOC malloc
#   if ! defined malloc && ! defined EXIT_SUCCESS
void *malloc (YYSIZE_T); /* INFRINGES ON USER NAME SPACE */
#   endif
#  endif
#  ifndef YYFREE
#   define YYFREE free
#   if ! defined free && ! defined EXIT_SUCCESS
void free (void *); /* INFRINGES ON USER NAME SPACE */
#   endif
#  endif
# endif
#endif /* ! defined yyoverflow || YYERROR_VERBOSE */


#if (! defined yyoverflow \
     && (! defined __cplusplus \
         || (defined YYSTYPE_IS_TRIVIAL && YYSTYPE_IS_TRIVIAL)))

/* A type that is properly aligned for any stack member.  */
union yyalloc
{
  yy_state_t yyss_alloc;
  YYSTYPE yyvs_alloc;
};

/* The size of the maximum gap between one aligned stack and the next.  */
# define YYSTACK_GAP_MAXIMUM (YYSIZEOF (union yyalloc) - 1)

/* The size of an array large to enough to hold all stacks, each with
   N elements.  */
# define YYSTACK_BYTES(N) \
     ((N) * (YYSIZEOF (yy_state_t) + YYSIZEOF (YYSTYPE)) \
      + YYSTACK_GAP_MAXIMUM)

# define YYCOPY_NEEDED 1

/* Relocate STACK from its old location to the new one.  The
   local variables YYSIZE and YYSTACKSIZE give the old and new number of
   elements in the stack, and YYPTR gives the new location of the
   stack.  Advance YYPTR to a properly aligned location for the next
   stack.  */
# define YYSTACK_RELOCATE(Stack_alloc, Stack)                           \
    do                                                                  \
      {                                                                 \
        YYPTRDIFF_T yynewbytes;                                         \
        YYCOPY (&yyptr->Stack_alloc, Stack, yysize);                    \
        Stack = &yyptr->Stack_alloc;                                    \
        yynewbytes = yystacksize * YYSIZEOF (*Stack) + YYSTACK_GAP_MAXIMUM; \
        yyptr += yynewbytes / YYSIZEOF (*yyptr);                        \
      }                                                                 \
    while (0)

#endif

#if defined YYCOPY_NEEDED && YYCOPY_NEEDED
/* Copy COUNT objects from SRC to DST.  The source and destination do
   not overlap.  */
# ifndef YYCOPY
#  if defined __GNUC__ && 1 < __GNUC__
#   define YYCOPY(Dst, Src, Count) \
      __builtin_memcpy (Dst, Src, YY_CAST (YYSIZE_T, (Count)) * sizeof (*(Src)))
#  else
#   define YYCOPY(Dst, Src, Count)              \
      do                                        \
        {                                       \
          YYPTRDIFF_T yyi;                      \
          for (yyi = 0; yyi < (Count); yyi++)   \
            (Dst)[yyi] = (Src)[yyi];            \
        }                                       \
      while (0)
#  endif
# endif
#endif /* !YYCOPY_NEEDED */

/* YYFINAL -- State number of the termination state.  */
#define YYFINAL  5
/* YYLAST -- Last index in YYTABLE.  */
#define YYLAST   600

/* YYNTOKENS -- Number of terminals.  */
#define YYNTOKENS  59
/* YYNNTS -- Number of nonterminals.  */
#define YYNNTS  53
/* YYNRULES -- Number of rules.  */
#define YYNRULES  126
/* YYNSTATES -- Number of states.  */
#define YYNSTATES  280

#define YYUNDEFTOK  2
#define YYMAXUTOK   307


/* YYTRANSLATE(TOKEN-NUM) -- Symbol number corresponding to TOKEN-NUM
   as returned by yylex, with out-of-bounds checking.  */
#define YYTRANSLATE(YYX)                                                \
  (0 <= (YYX) && (YYX) <= YYMAXUTOK ? yytranslate[YYX] : YYUNDEFTOK)

/* YYTRANSLATE[TOKEN-NUM] -- Symbol number corresponding to TOKEN-NUM
   as returned by yylex.  */
static const yytype_int8 yytranslate[] =
{
       0,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
      55,    56,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,    57,     2,    58,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,    53,     2,    54,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     1,     2,     3,     4,
       5,     6,     7,     8,     9,    10,    11,    12,    13,    14,
      15,    16,    17,    18,    19,    20,    21,    22,    23,    24,
      25,    26,    27,    28,    29,    30,    31,    32,    33,    34,
      35,    36,    37,    38,    39,    40,    41,    42,    43,    44,
      45,    46,    47,    48,    49,    50,    51,    52
};

#if YYDEBUG
  /* YYRLINE[YYN] -- Source line where rule number YYN was defined.  */
static const yytype_int16 yyrline[] =
{
       0,    44,    44,    44,    44,    48,    48,    72,    75,    76,
      79,    79,   100,   124,   127,   156,   206,   209,   210,   213,
     213,   224,   225,   236,   237,   272,   297,   298,   301,   346,
     349,   349,   438,   441,   442,   445,   445,   455,   456,   459,
     495,   521,   548,   573,   574,   577,   591,   592,   595,   636,
     595,   639,   639,   647,   650,   653,   654,   657,   687,   715,
     720,   721,   723,   728,   729,   730,   731,   733,   738,   739,
     740,   742,   759,   761,   778,   780,   797,   799,   840,   864,
     865,   866,   867,   868,   869,   870,   871,   899,   930,   931,
     932,   933,   934,   935,   936,   937,   938,   939,   940,   941,
     944,   998,  1057,  1082,  1100,  1128,  1149,  1182,  1206,  1233,
    1244,  1259,  1263,  1265,  1275,  1263,  1278,  1311,  1343,  1374,
    1375,  1378,  1394,  1411,  1430,  1431,  1432
};
#endif

#if YYDEBUG || YYERROR_VERBOSE || 0
/* YYTNAME[SYMBOL-NUM] -- String name of the symbol SYMBOL-NUM.
   First, the terminals, then, starting at YYNTOKENS, nonterminals.  */
static const char *const yytname[] =
{
  "$end", "error", "$undefined", "ID", "NUM", "INT", "STR", "SEMICOLON",
  "COMMA", "ASGN", "ALLOC", "FREE", "READ", "WRITE", "IF", "THEN", "ELSE",
  "ENDIF", "PLUS", "MINUS", "MUL", "DIV", "MAIN", "DECL", "ENDDECL",
  "BEGINE", "END", "STRING", "RETURN", "LT", "GT", "LE", "GE", "EQ", "NE",
  "DOT", "WHILE", "DO", "ENDWHILE", "BREAK", "CONTINUE", "MOD", "TYPE",
  "ENDTYPE", "null", "INITIALIZE", "CLASS", "ENDCLASS", "SELF", "NEW",
  "Extends", "OR", "AND", "'{'", "'}'", "'('", "')'", "'['", "']'",
  "$accept", "Program", "$@1", "$@2", "TypeDefBlock", "$@3", "TypeDefList",
  "TypeDef", "$@4", "FieldDeclList", "FieldDecl", "ClassDefBlock",
  "ClassDefList", "ClassDef", "$@5", "Cname", "Fieldlists", "Fld",
  "MethodDecl", "MDecl", "MethodDefns", "GDeclBlock", "$@6", "GDeclList",
  "GDecl", "$@7", "GidList", "Gid", "ParamList", "Param", "FDefBlock",
  "FDefList", "$@8", "$@9", "Body", "$@10", "Retstmt", "Slist", "Stmt",
  "Expr", "FIELD", "FieldFunction", "element", "ArgList", "MainBlock",
  "$@11", "$@12", "$@13", "LdeclBlock", "LDeclList", "LDecl", "IdList",
  "TypeName", YY_NULLPTR
};
#endif

# ifdef YYPRINT
/* YYTOKNUM[NUM] -- (External) token number corresponding to the
   (internal) symbol number NUM (which must be that of a token).  */
static const yytype_int16 yytoknum[] =
{
       0,   256,   257,   258,   259,   260,   261,   262,   263,   264,
     265,   266,   267,   268,   269,   270,   271,   272,   273,   274,
     275,   276,   277,   278,   279,   280,   281,   282,   283,   284,
     285,   286,   287,   288,   289,   290,   291,   292,   293,   294,
     295,   296,   297,   298,   299,   300,   301,   302,   303,   304,
     305,   306,   307,   123,   125,    40,    41,    91,    93
};
# endif

#define YYPACT_NINF (-184)

#define yypact_value_is_default(Yyn) \
  ((Yyn) == YYPACT_NINF)

#define YYTABLE_NINF (-1)

#define yytable_value_is_error(Yyn) \
  0

  /* YYPACT[STATE-NUM] -- Index in YYTABLE of the portion describing
     STATE-NUM.  */
static const yytype_int16 yypact[] =
{
      -3,  -184,    43,  -184,    81,  -184,    60,  -184,    -2,  -184,
     106,  -184,    67,  -184,  -184,    63,    21,  -184,  -184,    99,
     181,   128,  -184,  -184,    85,  -184,  -184,  -184,  -184,  -184,
      12,  -184,   137,  -184,   135,   181,   209,  -184,  -184,   158,
    -184,    26,  -184,  -184,   150,  -184,  -184,   173,  -184,   181,
    -184,  -184,   186,   143,   144,  -184,   102,  -184,   197,    44,
     163,  -184,  -184,   181,  -184,  -184,   205,    19,   181,   207,
    -184,   186,   160,   214,  -184,   222,   174,   181,   171,  -184,
     181,    15,   169,  -184,  -184,   181,   180,  -184,  -184,    20,
    -184,  -184,   184,  -184,   185,   232,   217,   217,  -184,   138,
    -184,  -184,  -184,   142,  -184,   239,   218,   218,  -184,  -184,
    -184,   175,   219,   190,   196,  -184,   250,  -184,   383,  -184,
    -184,  -184,    16,   199,   125,   130,   125,   125,   248,   249,
     229,   237,  -184,     0,   257,    42,   264,   125,    27,   104,
    -184,  -184,   233,   125,   172,   235,  -184,  -184,    45,   200,
     470,   494,  -184,  -184,   268,   125,   246,   108,   270,    75,
     223,   274,   227,   238,   228,  -184,   407,   -16,   -14,   280,
      77,   281,   442,  -184,   125,   125,   125,   125,   125,   125,
     125,   125,   125,   125,   125,   125,   125,   289,   240,  -184,
    -184,  -184,  -184,   256,  -184,   243,   287,   244,   245,   284,
    -184,   288,   312,   253,  -184,   254,   298,  -184,  -184,   299,
     304,   265,  -184,   518,    29,   266,  -184,   134,   134,  -184,
    -184,   176,   176,   176,   176,    -8,    -8,  -184,   542,   559,
     267,   305,   344,   337,  -184,   271,  -184,   272,   320,  -184,
    -184,  -184,   317,   319,   273,  -184,  -184,    77,   133,  -184,
      77,    77,  -184,  -184,   327,   330,   331,   332,   296,  -184,
    -184,   347,    36,  -184,   518,    39,    86,   376,  -184,  -184,
    -184,  -184,   352,  -184,  -184,  -184,  -184,   355,  -184,  -184
};

  /* YYDEFACT[STATE-NUM] -- Default reduction number in state STATE-NUM.
     Performed when YYTABLE does not specify something else to do.  Zero
     means the default is an error.  */
static const yytype_int8 yydefact[] =
{
       7,     5,     0,     2,     0,     1,    16,    10,     0,     9,
       0,     3,     0,     6,     8,    21,     0,    18,    19,    32,
       0,     0,    15,    17,     0,    30,    47,   126,   124,   125,
       0,    13,     0,    22,     0,     0,     0,    11,    12,     0,
      24,     0,    34,    35,   124,    46,     4,     0,    14,     0,
      31,    33,     0,     0,     0,    23,     0,    27,     0,    39,
       0,    38,   112,    44,    47,    26,     0,     0,    44,     0,
      36,     0,     0,    48,    43,     0,     0,    29,     0,    25,
      44,     0,     0,    37,   113,     0,     0,    45,    20,     0,
      40,    41,     0,    42,     0,     0,   118,   118,    28,     0,
     114,    49,   117,     0,   120,     0,     0,     0,   116,   119,
     123,     0,    56,     0,     0,   121,     0,    53,    51,   115,
      50,   122,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,    55,     0,     0,     0,     0,     0,     0,    86,
      85,    98,     0,     0,     0,    97,    99,    96,     0,     0,
       0,     0,    69,    70,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,   100,     0,     0,     0,     0,
     111,     0,     0,    65,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,    66,
      56,    56,   102,     0,    52,     0,     0,     0,     0,     0,
     101,     0,     0,     0,    58,     0,     0,    57,   106,     0,
       0,   100,   110,   109,     0,   102,    84,    79,    80,    81,
      82,    90,    91,    92,    93,    95,    94,    83,    88,    89,
     101,     0,     0,     0,    54,     0,    62,     0,     0,    61,
      59,    60,     0,     0,     0,    75,    76,   111,     0,    87,
     111,   111,    67,    56,     0,     0,     0,     0,     0,    73,
      71,     0,     0,   108,   107,     0,     0,     0,    64,    68,
      74,    72,     0,    77,   104,   103,   105,     0,    78,    63
};

  /* YYPGOTO[NTERM-NUM].  */
static const yytype_int16 yypgoto[] =
{
    -184,  -184,  -184,  -184,  -184,  -184,  -184,   357,  -184,  -184,
     336,  -184,  -184,   351,  -184,  -184,  -184,  -184,  -184,   313,
    -184,  -184,  -184,  -184,   329,  -184,  -184,   297,    30,   286,
     308,  -184,  -184,  -184,   275,  -184,  -184,  -183,  -184,  -121,
    -118,  -184,  -116,   -83,  -184,  -184,  -184,  -184,   277,  -184,
     278,  -184,    47
};

  /* YYDEFGOTO[NTERM-NUM].  */
static const yytype_int16 yydefgoto[] =
{
      -1,     2,     6,    19,     3,     4,     8,     9,    12,    30,
      31,    11,    16,    17,    24,    18,    49,    55,    56,    57,
      76,    26,    35,    41,    42,    52,    60,    61,    73,    74,
      36,    45,    86,   107,   113,   131,   156,   118,   132,   213,
     145,   146,   147,   214,    46,    72,    92,   106,   100,   103,
     104,   111,    75
};

  /* YYTABLE[YYPACT[STATE-NUM]] -- What to do in state STATE-NUM.  If
     positive, shift that token.  If negative, reduce the rule whose
     number is the opposite.  If YYTABLE_NINF, syntax error.  */
static const yytype_int16 yytable[] =
{
     133,     7,   134,   144,   149,   150,   151,   232,   233,   157,
     174,   175,   176,   177,   164,    27,   166,    28,    29,   136,
     168,   158,   172,    85,    15,   135,    79,   172,    85,    27,
     167,    28,    29,   184,   193,   158,   199,   248,   202,     1,
     209,    13,   210,     5,   248,   139,   140,   248,   139,   140,
      50,   136,   160,   217,   218,   219,   220,   221,   222,   223,
     224,   225,   226,   227,   228,   229,    37,    32,    22,   161,
     267,    90,   188,   137,    80,   130,    95,    32,   139,   140,
     139,   140,    43,    47,     7,   249,   141,   162,    43,   141,
     142,   163,   274,   142,   248,   275,    58,   143,    81,    68,
     143,    69,   201,    66,   212,    27,    10,    28,    29,    15,
      89,   139,   140,    21,   133,   133,   134,   134,   195,   141,
      20,   141,    25,   142,    47,   142,    64,   264,   139,   140,
     143,    33,   143,   139,   140,   196,   139,   140,    34,   169,
      39,    27,   276,    28,    29,    27,   105,    28,    29,   133,
     105,   134,   141,   197,   176,   177,   142,   198,    40,   170,
     263,   137,   102,   143,   262,    48,   108,   265,   266,   141,
      70,    71,    53,   142,   141,   184,    54,   141,   142,   173,
     143,   142,   115,   116,    27,   148,    28,    29,   143,    59,
     174,   175,   176,   177,   174,   175,   176,   177,    62,    63,
      67,   178,   179,   180,   181,   182,   183,   189,    78,   182,
     183,    82,    27,   184,    44,    29,    84,   184,   174,   175,
     176,   177,    85,   185,   186,    87,    80,    91,    88,   178,
     179,   180,   181,   182,   183,   207,    94,    96,    97,    98,
      99,   184,   110,   112,   119,   117,   174,   175,   176,   177,
     120,   185,   186,   121,   138,   152,   153,   178,   179,   180,
     181,   182,   183,   234,   154,   155,   159,   165,   171,   184,
     187,   192,   194,   200,   174,   175,   176,   177,   203,   185,
     186,   204,   205,   211,   215,   178,   179,   180,   181,   182,
     183,   239,   230,   206,   236,   240,   231,   184,   235,   237,
     238,   244,   174,   175,   176,   177,   245,   185,   186,   242,
     243,   246,   252,   178,   179,   180,   181,   182,   183,   241,
     247,   250,   251,   258,   259,   184,   260,   256,   257,   261,
     174,   175,   176,   177,   268,   185,   186,   269,   270,   271,
     122,   178,   179,   180,   181,   182,   183,   122,   123,   124,
     125,   126,   272,   184,   273,   123,   124,   125,   126,   278,
     253,   254,   279,   185,   186,    14,    38,    23,    83,    65,
      51,    93,    77,   127,   101,   255,   128,   129,     0,   122,
     127,   109,   114,   128,   129,   130,   122,   123,   124,   125,
     126,     0,   130,   277,   123,   124,   125,   126,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,   127,     0,     0,   128,   129,     0,     0,   127,
       0,     0,   128,   129,   130,   174,   175,   176,   177,     0,
       0,   130,     0,     0,     0,     0,   178,   179,   180,   181,
     182,   183,     0,     0,     0,     0,     0,     0,   184,     0,
       0,     0,     0,     0,     0,     0,     0,     0,   185,   186,
     174,   175,   176,   177,     0,   208,     0,     0,     0,     0,
       0,   178,   179,   180,   181,   182,   183,     0,     0,     0,
       0,     0,     0,   184,     0,   190,     0,     0,   174,   175,
     176,   177,     0,   185,   186,     0,     0,     0,   216,   178,
     179,   180,   181,   182,   183,     0,     0,     0,     0,     0,
       0,   184,   174,   175,   176,   177,     0,     0,     0,     0,
       0,   185,   186,   178,   179,   180,   181,   182,   183,     0,
       0,   191,     0,     0,     0,   184,   174,   175,   176,   177,
       0,     0,     0,     0,     0,   185,   186,   178,   179,   180,
     181,   182,   183,     0,     0,     0,     0,     0,     0,   184,
     174,   175,   176,   177,     0,     0,     0,     0,     0,   185,
     186,   178,   179,   180,   181,   182,   183,   174,   175,   176,
     177,     0,     0,   184,     0,     0,     0,     0,   178,   179,
     180,   181,   182,   183,   186,     0,     0,     0,     0,     0,
     184
};

static const yytype_int16 yycheck[] =
{
     118,     3,   118,   124,   125,   126,   127,   190,   191,     9,
      18,    19,    20,    21,   135,     3,   137,     5,     6,    35,
     138,    35,   143,     8,     3,     9,     7,   148,     8,     3,
       3,     5,     6,    41,   155,    35,   157,     8,   159,    42,
      56,    43,    56,     0,     8,     3,     4,     8,     3,     4,
      24,    35,    10,   174,   175,   176,   177,   178,   179,   180,
     181,   182,   183,   184,   185,   186,    54,    20,    47,    27,
     253,    56,    27,    57,    55,    48,    56,    30,     3,     4,
       3,     4,    35,    36,     3,    56,    44,    45,    41,    44,
      48,    49,    56,    48,     8,    56,    49,    55,    68,    55,
      55,    57,    27,    56,    27,     3,    46,     5,     6,     3,
      80,     3,     4,    50,   232,   233,   232,   233,    10,    44,
      53,    44,    23,    48,    77,    48,    24,   248,     3,     4,
      55,     3,    55,     3,     4,    27,     3,     4,    53,    35,
       3,     3,    56,     5,     6,     3,    99,     5,     6,   267,
     103,   267,    44,    45,    20,    21,    48,    49,    23,    55,
      27,    57,    24,    55,   247,     7,    24,   250,   251,    44,
       7,     8,    22,    48,    44,    41,     3,    44,    48,     7,
      55,    48,     7,     8,     3,    55,     5,     6,    55,     3,
      18,    19,    20,    21,    18,    19,    20,    21,    55,    55,
       3,    29,    30,    31,    32,    33,    34,     7,     3,    33,
      34,     4,     3,    41,     5,     6,    56,    41,    18,    19,
      20,    21,     8,    51,    52,     3,    55,    58,    54,    29,
      30,    31,    32,    33,    34,     7,    56,    53,    53,     7,
      23,    41,     3,    25,    54,    26,    18,    19,    20,    21,
      54,    51,    52,     3,    55,     7,     7,    29,    30,    31,
      32,    33,    34,     7,    35,    28,     9,     3,    35,    41,
      35,     3,    26,     3,    18,    19,    20,    21,    55,    51,
      52,     7,    55,     3,     3,    29,    30,    31,    32,    33,
      34,     7,     3,    55,     7,     7,    56,    41,    55,    55,
      55,     3,    18,    19,    20,    21,     7,    51,    52,    56,
      56,     7,     7,    29,    30,    31,    32,    33,    34,     7,
      55,    55,    55,     3,     7,    41,     7,    56,    56,    56,
      18,    19,    20,    21,     7,    51,    52,     7,     7,     7,
       3,    29,    30,    31,    32,    33,    34,     3,    11,    12,
      13,    14,    56,    41,     7,    11,    12,    13,    14,     7,
      16,    17,     7,    51,    52,     8,    30,    16,    71,    56,
      41,    85,    64,    36,    97,    38,    39,    40,    -1,     3,
      36,   103,   107,    39,    40,    48,     3,    11,    12,    13,
      14,    -1,    48,    17,    11,    12,    13,    14,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    36,    -1,    -1,    39,    40,    -1,    -1,    36,
      -1,    -1,    39,    40,    48,    18,    19,    20,    21,    -1,
      -1,    48,    -1,    -1,    -1,    -1,    29,    30,    31,    32,
      33,    34,    -1,    -1,    -1,    -1,    -1,    -1,    41,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    51,    52,
      18,    19,    20,    21,    -1,    58,    -1,    -1,    -1,    -1,
      -1,    29,    30,    31,    32,    33,    34,    -1,    -1,    -1,
      -1,    -1,    -1,    41,    -1,    15,    -1,    -1,    18,    19,
      20,    21,    -1,    51,    52,    -1,    -1,    -1,    56,    29,
      30,    31,    32,    33,    34,    -1,    -1,    -1,    -1,    -1,
      -1,    41,    18,    19,    20,    21,    -1,    -1,    -1,    -1,
      -1,    51,    52,    29,    30,    31,    32,    33,    34,    -1,
      -1,    37,    -1,    -1,    -1,    41,    18,    19,    20,    21,
      -1,    -1,    -1,    -1,    -1,    51,    52,    29,    30,    31,
      32,    33,    34,    -1,    -1,    -1,    -1,    -1,    -1,    41,
      18,    19,    20,    21,    -1,    -1,    -1,    -1,    -1,    51,
      52,    29,    30,    31,    32,    33,    34,    18,    19,    20,
      21,    -1,    -1,    41,    -1,    -1,    -1,    -1,    29,    30,
      31,    32,    33,    34,    52,    -1,    -1,    -1,    -1,    -1,
      41
};

  /* YYSTOS[STATE-NUM] -- The (internal number of the) accessing
     symbol of state STATE-NUM.  */
static const yytype_int8 yystos[] =
{
       0,    42,    60,    63,    64,     0,    61,     3,    65,    66,
      46,    70,    67,    43,    66,     3,    71,    72,    74,    62,
      53,    50,    47,    72,    73,    23,    80,     3,     5,     6,
      68,    69,   111,     3,    53,    81,    89,    54,    69,     3,
      23,    82,    83,   111,     5,    90,   103,   111,     7,    75,
      24,    83,    84,    22,     3,    76,    77,    78,   111,     3,
      85,    86,    55,    55,    24,    78,   111,     3,    55,    57,
       7,     8,   104,    87,    88,   111,    79,    89,     3,     7,
      55,    87,     4,    86,    56,     8,    91,     3,    54,    87,
      56,    58,   105,    88,    56,    56,    53,    53,     7,    23,
     107,   107,    24,   108,   109,   111,   106,    92,    24,   109,
       3,   110,    25,    93,    93,     7,     8,    26,    96,    54,
      54,     3,     3,    11,    12,    13,    14,    36,    39,    40,
      48,    94,    97,    99,   101,     9,    35,    57,    55,     3,
       4,    44,    48,    55,    98,    99,   100,   101,    55,    98,
      98,    98,     7,     7,    35,    28,    95,     9,    35,     9,
      10,    27,    45,    49,    98,     3,    98,     3,    99,    35,
      55,    35,    98,     7,    18,    19,    20,    21,    29,    30,
      31,    32,    33,    34,    41,    51,    52,    35,    27,     7,
      15,    37,     3,    98,    26,    10,    27,    45,    49,    98,
       3,    27,    98,    55,     7,    55,    55,     7,    58,    56,
      56,     3,    27,    98,   102,     3,    56,    98,    98,    98,
      98,    98,    98,    98,    98,    98,    98,    98,    98,    98,
       3,    56,    96,    96,     7,    55,     7,    55,    55,     7,
       7,     7,    56,    56,     3,     7,     7,    55,     8,    56,
      55,    55,     7,    16,    17,    38,    56,    56,     3,     7,
       7,    56,   102,    27,    98,   102,   102,    96,     7,     7,
       7,     7,    56,     7,    56,    56,    56,    17,     7,     7
};

  /* YYR1[YYN] -- Symbol number of symbol that rule YYN derives.  */
static const yytype_int8 yyr1[] =
{
       0,    59,    61,    62,    60,    64,    63,    63,    65,    65,
      67,    66,    68,    68,    69,    70,    70,    71,    71,    73,
      72,    74,    74,    75,    75,    76,    77,    77,    78,    79,
      81,    80,    80,    82,    82,    84,    83,    85,    85,    86,
      86,    86,    87,    87,    87,    88,    89,    89,    91,    92,
      90,    94,    93,    93,    95,    96,    96,    97,    97,    97,
      97,    97,    97,    97,    97,    97,    97,    97,    97,    97,
      97,    97,    97,    97,    97,    97,    97,    97,    97,    98,
      98,    98,    98,    98,    98,    98,    98,    98,    98,    98,
      98,    98,    98,    98,    98,    98,    98,    98,    98,    98,
      99,    99,    99,   100,   100,   100,   101,   102,   102,   102,
     102,   102,   104,   105,   106,   103,   107,   107,   107,   108,
     108,   109,   110,   110,   111,   111,   111
};

  /* YYR2[YYN] -- Number of symbols on the right hand side of rule YYN.  */
static const yytype_int8 yyr2[] =
{
       0,     2,     0,     0,     7,     0,     4,     0,     2,     1,
       0,     5,     2,     1,     3,     3,     0,     2,     1,     0,
       9,     1,     3,     2,     0,     3,     2,     1,     6,     1,
       0,     4,     0,     2,     1,     0,     4,     3,     1,     1,
       4,     4,     3,     1,     0,     2,     2,     0,     0,     0,
      11,     0,     5,     2,     3,     2,     0,     4,     4,     4,
       4,     4,     4,     8,     6,     3,     3,     5,     6,     2,
       2,     6,     6,     6,     6,     5,     5,     7,     7,     3,
       3,     3,     3,     3,     3,     1,     1,     4,     3,     3,
       3,     3,     3,     3,     3,     3,     1,     1,     1,     1,
       3,     3,     3,     6,     6,     6,     4,     3,     3,     1,
       1,     0,     0,     0,     0,    11,     3,     2,     0,     2,
       1,     3,     3,     1,     1,     1,     1
};


#define yyerrok         (yyerrstatus = 0)
#define yyclearin       (yychar = YYEMPTY)
#define YYEMPTY         (-2)
#define YYEOF           0

#define YYACCEPT        goto yyacceptlab
#define YYABORT         goto yyabortlab
#define YYERROR         goto yyerrorlab


#define YYRECOVERING()  (!!yyerrstatus)

#define YYBACKUP(Token, Value)                                    \
  do                                                              \
    if (yychar == YYEMPTY)                                        \
      {                                                           \
        yychar = (Token);                                         \
        yylval = (Value);                                         \
        YYPOPSTACK (yylen);                                       \
        yystate = *yyssp;                                         \
        goto yybackup;                                            \
      }                                                           \
    else                                                          \
      {                                                           \
        yyerror (YY_("syntax error: cannot back up")); \
        YYERROR;                                                  \
      }                                                           \
  while (0)

/* Error token number */
#define YYTERROR        1
#define YYERRCODE       256



/* Enable debugging if requested.  */
#if YYDEBUG

# ifndef YYFPRINTF
#  include <stdio.h> /* INFRINGES ON USER NAME SPACE */
#  define YYFPRINTF fprintf
# endif

# define YYDPRINTF(Args)                        \
do {                                            \
  if (yydebug)                                  \
    YYFPRINTF Args;                             \
} while (0)

/* This macro is provided for backward compatibility. */
#ifndef YY_LOCATION_PRINT
# define YY_LOCATION_PRINT(File, Loc) ((void) 0)
#endif


# define YY_SYMBOL_PRINT(Title, Type, Value, Location)                    \
do {                                                                      \
  if (yydebug)                                                            \
    {                                                                     \
      YYFPRINTF (stderr, "%s ", Title);                                   \
      yy_symbol_print (stderr,                                            \
                  Type, Value); \
      YYFPRINTF (stderr, "\n");                                           \
    }                                                                     \
} while (0)


/*-----------------------------------.
| Print this symbol's value on YYO.  |
`-----------------------------------*/

static void
yy_symbol_value_print (FILE *yyo, int yytype, YYSTYPE const * const yyvaluep)
{
  FILE *yyoutput = yyo;
  YYUSE (yyoutput);
  if (!yyvaluep)
    return;
# ifdef YYPRINT
  if (yytype < YYNTOKENS)
    YYPRINT (yyo, yytoknum[yytype], *yyvaluep);
# endif
  YY_IGNORE_MAYBE_UNINITIALIZED_BEGIN
  YYUSE (yytype);
  YY_IGNORE_MAYBE_UNINITIALIZED_END
}


/*---------------------------.
| Print this symbol on YYO.  |
`---------------------------*/

static void
yy_symbol_print (FILE *yyo, int yytype, YYSTYPE const * const yyvaluep)
{
  YYFPRINTF (yyo, "%s %s (",
             yytype < YYNTOKENS ? "token" : "nterm", yytname[yytype]);

  yy_symbol_value_print (yyo, yytype, yyvaluep);
  YYFPRINTF (yyo, ")");
}

/*------------------------------------------------------------------.
| yy_stack_print -- Print the state stack from its BOTTOM up to its |
| TOP (included).                                                   |
`------------------------------------------------------------------*/

static void
yy_stack_print (yy_state_t *yybottom, yy_state_t *yytop)
{
  YYFPRINTF (stderr, "Stack now");
  for (; yybottom <= yytop; yybottom++)
    {
      int yybot = *yybottom;
      YYFPRINTF (stderr, " %d", yybot);
    }
  YYFPRINTF (stderr, "\n");
}

# define YY_STACK_PRINT(Bottom, Top)                            \
do {                                                            \
  if (yydebug)                                                  \
    yy_stack_print ((Bottom), (Top));                           \
} while (0)


/*------------------------------------------------.
| Report that the YYRULE is going to be reduced.  |
`------------------------------------------------*/

static void
yy_reduce_print (yy_state_t *yyssp, YYSTYPE *yyvsp, int yyrule)
{
  int yylno = yyrline[yyrule];
  int yynrhs = yyr2[yyrule];
  int yyi;
  YYFPRINTF (stderr, "Reducing stack by rule %d (line %d):\n",
             yyrule - 1, yylno);
  /* The symbols being reduced.  */
  for (yyi = 0; yyi < yynrhs; yyi++)
    {
      YYFPRINTF (stderr, "   $%d = ", yyi + 1);
      yy_symbol_print (stderr,
                       yystos[+yyssp[yyi + 1 - yynrhs]],
                       &yyvsp[(yyi + 1) - (yynrhs)]
                                              );
      YYFPRINTF (stderr, "\n");
    }
}

# define YY_REDUCE_PRINT(Rule)          \
do {                                    \
  if (yydebug)                          \
    yy_reduce_print (yyssp, yyvsp, Rule); \
} while (0)

/* Nonzero means print parse trace.  It is left uninitialized so that
   multiple parsers can coexist.  */
int yydebug;
#else /* !YYDEBUG */
# define YYDPRINTF(Args)
# define YY_SYMBOL_PRINT(Title, Type, Value, Location)
# define YY_STACK_PRINT(Bottom, Top)
# define YY_REDUCE_PRINT(Rule)
#endif /* !YYDEBUG */


/* YYINITDEPTH -- initial size of the parser's stacks.  */
#ifndef YYINITDEPTH
# define YYINITDEPTH 200
#endif

/* YYMAXDEPTH -- maximum size the stacks can grow to (effective only
   if the built-in stack extension method is used).

   Do not make this value too large; the results are undefined if
   YYSTACK_ALLOC_MAXIMUM < YYSTACK_BYTES (YYMAXDEPTH)
   evaluated with infinite-precision integer arithmetic.  */

#ifndef YYMAXDEPTH
# define YYMAXDEPTH 10000
#endif


#if YYERROR_VERBOSE

# ifndef yystrlen
#  if defined __GLIBC__ && defined _STRING_H
#   define yystrlen(S) (YY_CAST (YYPTRDIFF_T, strlen (S)))
#  else
/* Return the length of YYSTR.  */
static YYPTRDIFF_T
yystrlen (const char *yystr)
{
  YYPTRDIFF_T yylen;
  for (yylen = 0; yystr[yylen]; yylen++)
    continue;
  return yylen;
}
#  endif
# endif

# ifndef yystpcpy
#  if defined __GLIBC__ && defined _STRING_H && defined _GNU_SOURCE
#   define yystpcpy stpcpy
#  else
/* Copy YYSRC to YYDEST, returning the address of the terminating '\0' in
   YYDEST.  */
static char *
yystpcpy (char *yydest, const char *yysrc)
{
  char *yyd = yydest;
  const char *yys = yysrc;

  while ((*yyd++ = *yys++) != '\0')
    continue;

  return yyd - 1;
}
#  endif
# endif

# ifndef yytnamerr
/* Copy to YYRES the contents of YYSTR after stripping away unnecessary
   quotes and backslashes, so that it's suitable for yyerror.  The
   heuristic is that double-quoting is unnecessary unless the string
   contains an apostrophe, a comma, or backslash (other than
   backslash-backslash).  YYSTR is taken from yytname.  If YYRES is
   null, do not copy; instead, return the length of what the result
   would have been.  */
static YYPTRDIFF_T
yytnamerr (char *yyres, const char *yystr)
{
  if (*yystr == '"')
    {
      YYPTRDIFF_T yyn = 0;
      char const *yyp = yystr;

      for (;;)
        switch (*++yyp)
          {
          case '\'':
          case ',':
            goto do_not_strip_quotes;

          case '\\':
            if (*++yyp != '\\')
              goto do_not_strip_quotes;
            else
              goto append;

          append:
          default:
            if (yyres)
              yyres[yyn] = *yyp;
            yyn++;
            break;

          case '"':
            if (yyres)
              yyres[yyn] = '\0';
            return yyn;
          }
    do_not_strip_quotes: ;
    }

  if (yyres)
    return yystpcpy (yyres, yystr) - yyres;
  else
    return yystrlen (yystr);
}
# endif

/* Copy into *YYMSG, which is of size *YYMSG_ALLOC, an error message
   about the unexpected token YYTOKEN for the state stack whose top is
   YYSSP.

   Return 0 if *YYMSG was successfully written.  Return 1 if *YYMSG is
   not large enough to hold the message.  In that case, also set
   *YYMSG_ALLOC to the required number of bytes.  Return 2 if the
   required number of bytes is too large to store.  */
static int
yysyntax_error (YYPTRDIFF_T *yymsg_alloc, char **yymsg,
                yy_state_t *yyssp, int yytoken)
{
  enum { YYERROR_VERBOSE_ARGS_MAXIMUM = 5 };
  /* Internationalized format string. */
  const char *yyformat = YY_NULLPTR;
  /* Arguments of yyformat: reported tokens (one for the "unexpected",
     one per "expected"). */
  char const *yyarg[YYERROR_VERBOSE_ARGS_MAXIMUM];
  /* Actual size of YYARG. */
  int yycount = 0;
  /* Cumulated lengths of YYARG.  */
  YYPTRDIFF_T yysize = 0;

  /* There are many possibilities here to consider:
     - If this state is a consistent state with a default action, then
       the only way this function was invoked is if the default action
       is an error action.  In that case, don't check for expected
       tokens because there are none.
     - The only way there can be no lookahead present (in yychar) is if
       this state is a consistent state with a default action.  Thus,
       detecting the absence of a lookahead is sufficient to determine
       that there is no unexpected or expected token to report.  In that
       case, just report a simple "syntax error".
     - Don't assume there isn't a lookahead just because this state is a
       consistent state with a default action.  There might have been a
       previous inconsistent state, consistent state with a non-default
       action, or user semantic action that manipulated yychar.
     - Of course, the expected token list depends on states to have
       correct lookahead information, and it depends on the parser not
       to perform extra reductions after fetching a lookahead from the
       scanner and before detecting a syntax error.  Thus, state merging
       (from LALR or IELR) and default reductions corrupt the expected
       token list.  However, the list is correct for canonical LR with
       one exception: it will still contain any token that will not be
       accepted due to an error action in a later state.
  */
  if (yytoken != YYEMPTY)
    {
      int yyn = yypact[+*yyssp];
      YYPTRDIFF_T yysize0 = yytnamerr (YY_NULLPTR, yytname[yytoken]);
      yysize = yysize0;
      yyarg[yycount++] = yytname[yytoken];
      if (!yypact_value_is_default (yyn))
        {
          /* Start YYX at -YYN if negative to avoid negative indexes in
             YYCHECK.  In other words, skip the first -YYN actions for
             this state because they are default actions.  */
          int yyxbegin = yyn < 0 ? -yyn : 0;
          /* Stay within bounds of both yycheck and yytname.  */
          int yychecklim = YYLAST - yyn + 1;
          int yyxend = yychecklim < YYNTOKENS ? yychecklim : YYNTOKENS;
          int yyx;

          for (yyx = yyxbegin; yyx < yyxend; ++yyx)
            if (yycheck[yyx + yyn] == yyx && yyx != YYTERROR
                && !yytable_value_is_error (yytable[yyx + yyn]))
              {
                if (yycount == YYERROR_VERBOSE_ARGS_MAXIMUM)
                  {
                    yycount = 1;
                    yysize = yysize0;
                    break;
                  }
                yyarg[yycount++] = yytname[yyx];
                {
                  YYPTRDIFF_T yysize1
                    = yysize + yytnamerr (YY_NULLPTR, yytname[yyx]);
                  if (yysize <= yysize1 && yysize1 <= YYSTACK_ALLOC_MAXIMUM)
                    yysize = yysize1;
                  else
                    return 2;
                }
              }
        }
    }

  switch (yycount)
    {
# define YYCASE_(N, S)                      \
      case N:                               \
        yyformat = S;                       \
      break
    default: /* Avoid compiler warnings. */
      YYCASE_(0, YY_("syntax error"));
      YYCASE_(1, YY_("syntax error, unexpected %s"));
      YYCASE_(2, YY_("syntax error, unexpected %s, expecting %s"));
      YYCASE_(3, YY_("syntax error, unexpected %s, expecting %s or %s"));
      YYCASE_(4, YY_("syntax error, unexpected %s, expecting %s or %s or %s"));
      YYCASE_(5, YY_("syntax error, unexpected %s, expecting %s or %s or %s or %s"));
# undef YYCASE_
    }

  {
    /* Don't count the "%s"s in the final size, but reserve room for
       the terminator.  */
    YYPTRDIFF_T yysize1 = yysize + (yystrlen (yyformat) - 2 * yycount) + 1;
    if (yysize <= yysize1 && yysize1 <= YYSTACK_ALLOC_MAXIMUM)
      yysize = yysize1;
    else
      return 2;
  }

  if (*yymsg_alloc < yysize)
    {
      *yymsg_alloc = 2 * yysize;
      if (! (yysize <= *yymsg_alloc
             && *yymsg_alloc <= YYSTACK_ALLOC_MAXIMUM))
        *yymsg_alloc = YYSTACK_ALLOC_MAXIMUM;
      return 1;
    }

  /* Avoid sprintf, as that infringes on the user's name space.
     Don't have undefined behavior even if the translation
     produced a string with the wrong number of "%s"s.  */
  {
    char *yyp = *yymsg;
    int yyi = 0;
    while ((*yyp = *yyformat) != '\0')
      if (*yyp == '%' && yyformat[1] == 's' && yyi < yycount)
        {
          yyp += yytnamerr (yyp, yyarg[yyi++]);
          yyformat += 2;
        }
      else
        {
          ++yyp;
          ++yyformat;
        }
  }
  return 0;
}
#endif /* YYERROR_VERBOSE */

/*-----------------------------------------------.
| Release the memory associated to this symbol.  |
`-----------------------------------------------*/

static void
yydestruct (const char *yymsg, int yytype, YYSTYPE *yyvaluep)
{
  YYUSE (yyvaluep);
  if (!yymsg)
    yymsg = "Deleting";
  YY_SYMBOL_PRINT (yymsg, yytype, yyvaluep, yylocationp);

  YY_IGNORE_MAYBE_UNINITIALIZED_BEGIN
  YYUSE (yytype);
  YY_IGNORE_MAYBE_UNINITIALIZED_END
}




/* The lookahead symbol.  */
int yychar;

/* The semantic value of the lookahead symbol.  */
YYSTYPE yylval;
/* Number of syntax errors so far.  */
int yynerrs;


/*----------.
| yyparse.  |
`----------*/

int
yyparse (void)
{
    yy_state_fast_t yystate;
    /* Number of tokens to shift before error messages enabled.  */
    int yyerrstatus;

    /* The stacks and their tools:
       'yyss': related to states.
       'yyvs': related to semantic values.

       Refer to the stacks through separate pointers, to allow yyoverflow
       to reallocate them elsewhere.  */

    /* The state stack.  */
    yy_state_t yyssa[YYINITDEPTH];
    yy_state_t *yyss;
    yy_state_t *yyssp;

    /* The semantic value stack.  */
    YYSTYPE yyvsa[YYINITDEPTH];
    YYSTYPE *yyvs;
    YYSTYPE *yyvsp;

    YYPTRDIFF_T yystacksize;

  int yyn;
  int yyresult;
  /* Lookahead token as an internal (translated) token number.  */
  int yytoken = 0;
  /* The variables used to return semantic value and location from the
     action routines.  */
  YYSTYPE yyval;

#if YYERROR_VERBOSE
  /* Buffer for error messages, and its allocated size.  */
  char yymsgbuf[128];
  char *yymsg = yymsgbuf;
  YYPTRDIFF_T yymsg_alloc = sizeof yymsgbuf;
#endif

#define YYPOPSTACK(N)   (yyvsp -= (N), yyssp -= (N))

  /* The number of symbols on the RHS of the reduced rule.
     Keep to zero when no symbol should be popped.  */
  int yylen = 0;

  yyssp = yyss = yyssa;
  yyvsp = yyvs = yyvsa;
  yystacksize = YYINITDEPTH;

  YYDPRINTF ((stderr, "Starting parse\n"));

  yystate = 0;
  yyerrstatus = 0;
  yynerrs = 0;
  yychar = YYEMPTY; /* Cause a token to be read.  */
  goto yysetstate;


/*------------------------------------------------------------.
| yynewstate -- push a new state, which is found in yystate.  |
`------------------------------------------------------------*/
yynewstate:
  /* In all cases, when you get here, the value and location stacks
     have just been pushed.  So pushing a state here evens the stacks.  */
  yyssp++;


/*--------------------------------------------------------------------.
| yysetstate -- set current state (the top of the stack) to yystate.  |
`--------------------------------------------------------------------*/
yysetstate:
  YYDPRINTF ((stderr, "Entering state %d\n", yystate));
  YY_ASSERT (0 <= yystate && yystate < YYNSTATES);
  YY_IGNORE_USELESS_CAST_BEGIN
  *yyssp = YY_CAST (yy_state_t, yystate);
  YY_IGNORE_USELESS_CAST_END

  if (yyss + yystacksize - 1 <= yyssp)
#if !defined yyoverflow && !defined YYSTACK_RELOCATE
    goto yyexhaustedlab;
#else
    {
      /* Get the current used size of the three stacks, in elements.  */
      YYPTRDIFF_T yysize = yyssp - yyss + 1;

# if defined yyoverflow
      {
        /* Give user a chance to reallocate the stack.  Use copies of
           these so that the &'s don't force the real ones into
           memory.  */
        yy_state_t *yyss1 = yyss;
        YYSTYPE *yyvs1 = yyvs;

        /* Each stack pointer address is followed by the size of the
           data in use in that stack, in bytes.  This used to be a
           conditional around just the two extra args, but that might
           be undefined if yyoverflow is a macro.  */
        yyoverflow (YY_("memory exhausted"),
                    &yyss1, yysize * YYSIZEOF (*yyssp),
                    &yyvs1, yysize * YYSIZEOF (*yyvsp),
                    &yystacksize);
        yyss = yyss1;
        yyvs = yyvs1;
      }
# else /* defined YYSTACK_RELOCATE */
      /* Extend the stack our own way.  */
      if (YYMAXDEPTH <= yystacksize)
        goto yyexhaustedlab;
      yystacksize *= 2;
      if (YYMAXDEPTH < yystacksize)
        yystacksize = YYMAXDEPTH;

      {
        yy_state_t *yyss1 = yyss;
        union yyalloc *yyptr =
          YY_CAST (union yyalloc *,
                   YYSTACK_ALLOC (YY_CAST (YYSIZE_T, YYSTACK_BYTES (yystacksize))));
        if (! yyptr)
          goto yyexhaustedlab;
        YYSTACK_RELOCATE (yyss_alloc, yyss);
        YYSTACK_RELOCATE (yyvs_alloc, yyvs);
# undef YYSTACK_RELOCATE
        if (yyss1 != yyssa)
          YYSTACK_FREE (yyss1);
      }
# endif

      yyssp = yyss + yysize - 1;
      yyvsp = yyvs + yysize - 1;

      YY_IGNORE_USELESS_CAST_BEGIN
      YYDPRINTF ((stderr, "Stack size increased to %ld\n",
                  YY_CAST (long, yystacksize)));
      YY_IGNORE_USELESS_CAST_END

      if (yyss + yystacksize - 1 <= yyssp)
        YYABORT;
    }
#endif /* !defined yyoverflow && !defined YYSTACK_RELOCATE */

  if (yystate == YYFINAL)
    YYACCEPT;

  goto yybackup;


/*-----------.
| yybackup.  |
`-----------*/
yybackup:
  /* Do appropriate processing given the current state.  Read a
     lookahead token if we need one and don't already have one.  */

  /* First try to decide what to do without reference to lookahead token.  */
  yyn = yypact[yystate];
  if (yypact_value_is_default (yyn))
    goto yydefault;

  /* Not known => get a lookahead token if don't already have one.  */

  /* YYCHAR is either YYEMPTY or YYEOF or a valid lookahead symbol.  */
  if (yychar == YYEMPTY)
    {
      YYDPRINTF ((stderr, "Reading a token: "));
      yychar = yylex ();
    }

  if (yychar <= YYEOF)
    {
      yychar = yytoken = YYEOF;
      YYDPRINTF ((stderr, "Now at end of input.\n"));
    }
  else
    {
      yytoken = YYTRANSLATE (yychar);
      YY_SYMBOL_PRINT ("Next token is", yytoken, &yylval, &yylloc);
    }

  /* If the proper action on seeing token YYTOKEN is to reduce or to
     detect an error, take that action.  */
  yyn += yytoken;
  if (yyn < 0 || YYLAST < yyn || yycheck[yyn] != yytoken)
    goto yydefault;
  yyn = yytable[yyn];
  if (yyn <= 0)
    {
      if (yytable_value_is_error (yyn))
        goto yyerrlab;
      yyn = -yyn;
      goto yyreduce;
    }

  /* Count tokens shifted since error; after three, turn off error
     status.  */
  if (yyerrstatus)
    yyerrstatus--;

  /* Shift the lookahead token.  */
  YY_SYMBOL_PRINT ("Shifting", yytoken, &yylval, &yylloc);
  yystate = yyn;
  YY_IGNORE_MAYBE_UNINITIALIZED_BEGIN
  *++yyvsp = yylval;
  YY_IGNORE_MAYBE_UNINITIALIZED_END

  /* Discard the shifted token.  */
  yychar = YYEMPTY;
  goto yynewstate;


/*-----------------------------------------------------------.
| yydefault -- do the default action for the current state.  |
`-----------------------------------------------------------*/
yydefault:
  yyn = yydefact[yystate];
  if (yyn == 0)
    goto yyerrlab;
  goto yyreduce;


/*-----------------------------.
| yyreduce -- do a reduction.  |
`-----------------------------*/
yyreduce:
  /* yyn is the number of a rule to reduce with.  */
  yylen = yyr2[yyn];

  /* If YYLEN is nonzero, implement the default value of the action:
     '$$ = $1'.

     Otherwise, the following line sets YYVAL to garbage.
     This behavior is undocumented and Bison
     users should not rely upon it.  Assigning to YYVAL
     unconditionally makes the parser a bit smaller, and it avoids a
     GCC warning that YYVAL may be used uninitialized.  */
  yyval = yyvsp[1-yylen];


  YY_REDUCE_PRINT (yyn);
  switch (yyn)
    {
  case 2:
#line 44 "task1.y"
                       {if(T_Table==NULL) T_Table=TypeTableCreate(); GLabel=getLabel();fprintf(target,"JMP L%d\n",GLabel);}
#line 1688 "y.tab.c"
    break;

  case 3:
#line 44 "task1.y"
                                                                                                                                         {fprintf(target,"L%d:\n",GLabel);}
#line 1694 "y.tab.c"
    break;

  case 5:
#line 48 "task1.y"
                    {T_Table=TypeTableCreate();/*printf("check-11");if(T_Table==NULL) printf("***");*/}
#line 1700 "y.tab.c"
    break;

  case 6:
#line 48 "task1.y"
                                                                                                                            {   ttableptr=T_Table;
																	printf("---------------------\n");
																	printf("Type Table\n");
																	printf("---------------------\n");
																	while(ttableptr!=NULL)
																	{
																		printf("%s ",ttableptr->name);
																		F_list=ttableptr->fields;
																		if(F_list)
																		{
																			printf("Fields = ");
																			while(F_list)
																			{
																				printf("%s - ",F_list->name);
																				F_list=F_list->next;
																			}
																		}
																		else
																			printf("Fields = NULL");
																		ttableptr=ttableptr->next;
																		printf("\n");
																	}
																	printf("---------------------\n");
																}
#line 1729 "y.tab.c"
    break;

  case 7:
#line 72 "task1.y"
                {T_Table=TypeTableCreate();}
#line 1735 "y.tab.c"
    break;

  case 10:
#line 79 "task1.y"
                        {TInstall(&T_Table,(yyvsp[0].string));}
#line 1741 "y.tab.c"
    break;

  case 11:
#line 79 "task1.y"
                                                                              {	
												ttableptr=TLookup(T_Table,(yyvsp[-4].string));
												if(!ttableptr)
	   											{	
	   												yyerror("type not defined in type table");exit(0);
	   											}
												ttableptr->fields=(yyvsp[-1].Fl);
												if(!ttableptr->fields)
													exit(0);
												F_list=(yyvsp[-1].Fl);
												/*while(F_list)
												{
													printf("%s ",F_list->name);
													F_list=F_list->next;
												}
												printf("\n");*/
												F_list=NULL;
												position=0;
											}
#line 1765 "y.tab.c"
    break;

  case 12:
#line 100 "task1.y"
                                                {	//printf("check1");
								struct Fieldlist *f_temp;
								f_temp=(yyvsp[-1].Fl);
								
								while(f_temp->next!=NULL)
								{
									//printf("%s---%s   ",f_temp->name,$<Fl>2->name);
									if(strcmp(f_temp->name,(yyvsp[0].Fl)->name))
										f_temp=f_temp->next;
									else
									{
										yyerror("ERROR- Two fields of same name");exit(0);
									}
								}
								if(!strcmp(f_temp->name,(yyvsp[0].Fl)->name))
								{
									
									yyerror("ERROR- Two fields of same name");exit(0);
								}
								//printf("%s---%s\n",f_temp->name,$<Fl>2->name);
								f_temp->next=(yyvsp[0].Fl);
								(yyval.Fl)=(yyvsp[-1].Fl); 
					 		}
#line 1793 "y.tab.c"
    break;

  case 13:
#line 124 "task1.y"
                                        {(yyval.Fl)=(yyvsp[0].Fl);}
#line 1799 "y.tab.c"
    break;

  case 14:
#line 127 "task1.y"
                                                { 
							//printf("check2");
							struct Fieldlist* F_list;
							F_list=(struct Fieldlist*)malloc(sizeof(struct Fieldlist));
							F_list->name=(char*)malloc(sizeof(char)*100);
							//printf("check12");
							//printf("%s",$<string>1);
							ttableptr=TLookup(T_Table,(yyvsp[-2].string));
							if(!ttableptr)
	   						{
	   							yyerror("type not defined in type table");exit(0);
	   						}
							F_list->type=ttableptr;
							strcpy(F_list->name,(yyvsp[-1].string));
							//printf("%s \n",F_list->name);
							if(position>8)
							{
								yyerror("Has more than 8 fields");exit(0);
							}
							F_list->fieldIndex=position;
							position++;
							F_list->next=NULL;
							(yyval.Fl)=F_list;
							//free(F_list);
							
						}
#line 1830 "y.tab.c"
    break;

  case 15:
#line 156 "task1.y"
                                                 {	Cptr=CTable;
						 	printf("---------------------\n");
							printf("Class Table\n");
							printf("---------------------\n");
							while(Cptr!=NULL)
							{
								printf("%s \n",Cptr->Name);
								printf("Class index= %d\n",Cptr->Class_index); 
								printf("Field count = %d\n",Cptr->Fieldcount);
								printf("Method count = %d\n",Cptr->Methodcount);
								f_temp=Cptr->Memberfield;
								if(f_temp)
								{
									printf("Fields = ");
									while(f_temp)
									{
										printf("%s - fieldindex = %d, ",f_temp->name,f_temp->fieldIndex);
										if(f_temp->type)
											printf("%s  ",f_temp->type->name);
										else if(f_temp->Ctype)
											printf("%s  ",f_temp->Ctype->Name);
										f_temp=f_temp->next;
									}
									//printf("  ");
								}
								else
									printf("Fields = NULL");
								printf("\n");
								
								
								m_temp=Cptr->Vfuncptr;
								///printf("***%s***",m_temp->type->name);
								if(m_temp)
								{
									printf("Members = ");
									while(m_temp)
									{
										printf("%s - funcposition = %d, type=%s, flabel=%d   ",m_temp->name,m_temp->Funcposition,m_temp->type->name,m_temp->Flabel);
										m_temp=m_temp->next;
									}
								}
								else
									printf("Members = NULL");
								printf("\n");
								printf("\n");
								
								Cptr=Cptr->Next;
							}
							printf("---------------------\n");
						}
#line 1885 "y.tab.c"
    break;

  case 17:
#line 209 "task1.y"
                                        {Cptr=NULL;}
#line 1891 "y.tab.c"
    break;

  case 18:
#line 210 "task1.y"
                                {Cptr=NULL;}
#line 1897 "y.tab.c"
    break;

  case 19:
#line 213 "task1.y"
                       { if(Cptr) { Cptr->Class_index=Class_index;} }
#line 1903 "y.tab.c"
    break;

  case 20:
#line 213 "task1.y"
                                                                                                                            {
									 								if(Cptr)
									 								{
									 									//printf("**%d %d **",f_position,m_position);
									 									Cptr->Fieldcount=f_position;Cptr->Methodcount=m_position;
									 								}
									 								f_position=0;m_position=0;Class_index++;
									 		
									 			   				}
#line 1917 "y.tab.c"
    break;

  case 21:
#line 224 "task1.y"
                                {Cptr = CInstall(&CTable,(yyvsp[0].string),NULL);}
#line 1923 "y.tab.c"
    break;

  case 22:
#line 225 "task1.y"
                                {
					P_Cptr=CLookup(CTable,(yyvsp[0].string));
					if(P_Cptr==NULL)
					{
						yyerror("Parent class not found in class table");exit(0);
					} 
					Cptr = CInstall(&CTable,(yyvsp[-2].string),P_Cptr);
					//printf("--%s--%s---",Cptr->Name,Cptr->Parentptr->Name);
				}
#line 1937 "y.tab.c"
    break;

  case 24:
#line 237 "task1.y"
                  { 
			if(Cptr->Parentptr)
			{ 
				int a;
				//f_position=Cptr->Parentptr->Fieldcount;
				//m_position=Cptr->Parentptr->Methodcount;
				
				f_temp=Cptr->Parentptr->Memberfield;
				while(f_temp)
				{
					
					Class_Finstall(Cptr,f_temp->Ctype,f_temp->type,f_temp->name,f_temp->fieldIndex);
					f_position++;
					f_temp=f_temp->next;	
				}
				
				m_temp=Cptr->Parentptr->Vfuncptr;
				while(m_temp)
				{
					
					a=m_temp->Flabel;
					/*fprintf(target,"MOV [%d], F%d\n",address, a);
					temp_address++;
					address++;*/
					//printf("    %s   ",m_temp->type->name);
					Class_Minstall(Cptr,m_temp->name,m_temp->type,m_temp->paramlist,m_position,a);
					m_position++;
					m_temp=m_temp->next;
					//printf("**%d**",m_position);
				}
				//Cptr->Vfuncptr=Cptr->Parentptr->Vfuncptr;
			}
		 }
#line 1975 "y.tab.c"
    break;

  case 25:
#line 272 "task1.y"
                                                {
							ttableptr=TLookup(T_Table,(yyvsp[-2].string));
	   						c_temp=CLookup(CTable,(yyvsp[-2].string));
	   						
	   						if(!ttableptr && !c_temp)
	   						{
	   							yyerror("type not defined in type table");exit(0);
	   						}
	   						if(f_position>8)
							{
								yyerror("class has more than 8 fields");exit(0);
							}
							//if(ttableptr)
							Class_Finstall(Cptr,c_temp,ttableptr,(yyvsp[-1].string),f_position);
							//else if(c_temp)
							//	Class_Finstall(Cptr,c_temp,ttableptr,$<string>2,f_position);
							
							//if(Cptr->Memberfield!=NULL)
							//	printf("**%s**",Cptr->Memberfield->name);
							
							f_position++;
							
						}
#line 2003 "y.tab.c"
    break;

  case 28:
#line 301 "task1.y"
                                                     {
							int a;
           						a=get_func_label();
           					//	printf("**%s**",$<string>1);
							ttableptr=TLookup(T_Table,(yyvsp[-5].string));
						//	printf("%s ",ttableptr->name);
	   						if(!ttableptr)
	   						{
	   							yyerror("type not defined in type table");exit(0);
	   						}
	   						if(m_position>8)
							{
								yyerror("class has more than 8 methods");exit(0);
							}
							m_temp=Class_Mlookup(Cptr->Parentptr,(yyvsp[-4].string));
							if(!m_temp)
							{
								/*fprintf(target,"MOV [%d], F%d\n",address, a);
								temp_address++;
								address++;*/
								//printf("   %s    ",ttableptr->name);
								//printf("--%d--",m_position);
								Class_Minstall(Cptr,(yyvsp[-4].string),ttableptr,(yyvsp[-2].Pl),m_position,a);
								m_position++;
							}
							else
							{
								if(check_func_param(m_temp->paramlist,(yyvsp[-2].Pl)))
								{
									/*fprintf(target,"MOV [%d], F%d\n",4096+ 8 * Cptr->Class_index + m_temp->Funcposition, a);
									//temp_address++;
									//address++;*/
									m_temp=Class_Mlookup(Cptr,(yyvsp[-4].string));
									m_temp->Flabel=a;
								}
								else
								{
									yyerror("Parameter doesnt match for parent and derived class");exit(0);
								}
							}
								
							
						}
#line 2051 "y.tab.c"
    break;

  case 30:
#line 349 "task1.y"
                  {
			Cptr=CTable;
			while(Cptr!=NULL)
			{
				temp_address=1;
				m_temp=Cptr->Vfuncptr;
				if(m_temp)
				{
					while(m_temp)
					{
						int a=m_temp->Flabel;
						fprintf(target,"MOV [%d], F%d\n",address, a);
						address++;
						temp_address++;
						m_temp=m_temp->next;
					}
				}
				while(temp_address<=8)
				{
					int Reg_i=getReg();
					if(Reg_i==-1)
						exit(0);
									 		
					fprintf(target, "MOV R%d, -1\n",Reg_i);
					fprintf(target,"MOV [%d], R%d\n",address, Reg_i);
								
					Reg_i=freeReg();
					if(Reg_i==-1)
						exit(0);
									 		
					temp_address++;
					address++;
				}
							
				Cptr=Cptr->Next;
			}

							
					}
#line 2095 "y.tab.c"
    break;

  case 31:
#line 388 "task1.y"
        {
	
	fprintf(target, "MOV SP, %d\nMOV BP, %d\nCALL MAIN\nINT 10\n", address,address+1);
	
	
	printf("----------------\n");
	printf("Global Symbol Table\n");
	printf("------------------\n");
	temp=GTable;
	while(temp)
        {
              printf("%s ",temp->name);
              if(temp->type)
            	  printf("type = %s ",temp->type->name);
              else if(temp->Ctype)
              	  printf("type = %s ",temp->Ctype->Name);
              printf("size = %d ",temp->size);
              printf("binding = %d ",temp->binding);
	      if(temp->paramlist)
	      {
			printf("paramlist.. ");
			struct Paramstruct *p;
			p=temp->paramlist;
			while(p)
			{	
				printf("name = %s,type= %s ",p->name,p->type);
				p=p->next;
			}
	      }
	      else
		printf("paramlist = NULL ");
		if(temp->type)
	     		F_list=temp->type->fields;
	     if(F_list)
	     {
		printf("Fields = ");
		while(F_list)
		{
			printf("%s - ",F_list->name);
			F_list=F_list->next;
		}
	     }
	     else
		printf("Fields = NULL");
	     
              temp=temp->next;
              printf("\n");
        }
        printf("--------------\n");
        }
#line 2150 "y.tab.c"
    break;

  case 35:
#line 445 "task1.y"
                      {
				ttableptr=TLookup(T_Table,(yyvsp[0].string));
	   			Cptr=CLookup(CTable,(yyvsp[0].string));
	   			if(!ttableptr && !Cptr)
	   			{ yyerror("type not defined in type table");exit(0);}
			}
#line 2161 "y.tab.c"
    break;

  case 39:
#line 459 "task1.y"
                {
				if(check_Reserved(Keywords,(yyvsp[0].string)))
				{
					yyerror("ERROR a reserved word declared as variable");
				}
       			else if(!GLookup(GTable,(yyvsp[0].string)))
				{
					GInstall(&GTable,(yyvsp[0].string),NULL,1,address,NULL,0);
					int reg_i=getReg();
					if (reg_i == -1)
            					exit(1);
					fprintf(target, "MOV R%d, -1\n",reg_i);
					fprintf(target, "MOV [%d], R%d\n",address,reg_i);
					reg_i = freeReg();
        				if (reg_i == -1)
            					exit(1);
            				temp=GLookup(GTable,(yyvsp[0].string));
					if(Cptr)
					{
						temp->Ctype=Cptr;
						address+=2;
					}
					else
					{
						temp->type=ttableptr;	
						address++;
					}
					
					
				}
				else
				{
					yyerror("ERROR-Multiple Declaration of same Variable");exit(0);
				}
			}
#line 2201 "y.tab.c"
    break;

  case 40:
#line 495 "task1.y"
                                {
           				int a;
           				a=get_func_label();
           				if(check_Reserved(Keywords,(yyvsp[-3].string)))
					{
						yyerror("ERROR a reserved word declared as variable");
					}
					else if(!GLookup(GTable,(yyvsp[-3].string)))
					{
						GInstall(&GTable,(yyvsp[-3].string),NULL,0,0,(yyvsp[-1].Pl),a);
						temp=GLookup(GTable,(yyvsp[-3].string));
						if(Cptr)
						{
							temp->Ctype=Cptr;
						}
						else
						{
							temp->type=ttableptr;	
						}
					}
					else
					{
						yyerror("ERROR-Multiple Declaration of same variable");exit(0);
					}
				}
#line 2231 "y.tab.c"
    break;

  case 41:
#line 521 "task1.y"
                                {
	   				//int b;
	   				if(check_Reserved(Keywords,(yyvsp[-3].string)))
					{
						yyerror("ERROR a reserved word declared as variable");
					}
					else if(!GLookup(GTable,(yyvsp[-3].string)))
					{
						GInstall(&GTable,(yyvsp[-3].string),NULL,(yyvsp[-1].a),address,NULL,0);
						temp=GLookup(GTable,(yyvsp[-3].string));
						if(Cptr)
						{
							temp->Ctype=Cptr;
						}
						else
						{
							temp->type=ttableptr;
						}
						address+=(yyvsp[-1].a);
					}
					else
					{
						yyerror("ERROR-Multiple Declaration of same Variable\n");exit(0);
					}
				}
#line 2261 "y.tab.c"
    break;

  case 42:
#line 548 "task1.y"
                                         {
						struct Paramstruct *temp_list;
						temp_list=(yyvsp[-2].Pl);
						//int flag=0;
						while(temp_list->next!=NULL)
						{
							//printf("%s %s --",temp_list->name,$<Pl>3->name);
							if(strcmp(temp_list->name,(yyvsp[0].Pl)->name))
								temp_list=temp_list->next;
							else
							{
								yyerror("ERROR- Failed Name equivalence of formal parameter");exit(0);
								//temp_list=temp_list->next;
							}
							//flag=1;
						}
						if(!strcmp(temp_list->name,(yyvsp[0].Pl)->name))
						{
							//printf("%s %s--\n",temp_list->name,$<Pl>3->name);
							yyerror("ERROR- Failed Name equivalence of parameter");exit(0);
						}
						temp_list->next=(yyvsp[0].Pl);
						(yyval.Pl)=(yyvsp[-2].Pl);
						//free(list);	  
					 }
#line 2291 "y.tab.c"
    break;

  case 43:
#line 573 "task1.y"
                                {(yyval.Pl)=(yyvsp[0].Pl);}
#line 2297 "y.tab.c"
    break;

  case 44:
#line 574 "task1.y"
                  {(yyval.Pl)=NULL;}
#line 2303 "y.tab.c"
    break;

  case 45:
#line 577 "task1.y"
                                {
       					struct Paramstruct * list;
					list=(struct Paramstruct*)malloc(sizeof(struct Paramstruct));
					list->name=(char*)malloc(sizeof(char)*100);
					strcpy(list->name,(yyvsp[0].string));
					list->type=(char*)malloc(sizeof(char)*100);
					strcpy(list->type,(yyvsp[-1].string));
					//list->type=$<a>1;
					list->next=NULL;
					(yyval.Pl)=list;
					//free(list);
				}
#line 2320 "y.tab.c"
    break;

  case 48:
#line 595 "task1.y"
                                            {
						pml=(yyvsp[0].Pl); gtemp=GLookup(GTable,(yyvsp[-2].string));m_temp=Class_Mlookup(Cptr,(yyvsp[-2].string));
					//	printf("**%s** ",Cptr->Name);
						if(gtemp==NULL && m_temp==NULL)
							yyerror("Function not declared");
						else if(m_temp && !check_func_param((yyvsp[0].Pl),m_temp->paramlist))
						{
							yyerror("Paramater error");exit(0);
						}
						else if(gtemp && !check_func_param((yyvsp[0].Pl),gtemp->paramlist))
						{
							yyerror("Paramter error");exit(0);
						}
						else
						{
							if(m_temp)
								fprintf(target, "F%d:\n",m_temp->Flabel);
							else if(gtemp)
								fprintf(target, "F%d:\n",gtemp->flabel);
							fprintf(target,"PUSH BP\n");
							fprintf(target,"MOV BP, SP\n");
							int binding=-3;
							while(pml)
							{
								ttableptr=TLookup(T_Table,pml->type);
								if(!ttableptr)
								{	yyerror("ERROR - Type not defined in type table");exit(0);}
								LInstall(&temp_table,pml->name,ttableptr,binding);
								binding--;
								pml=pml->next;
							}
							if(m_temp)
							{
								ttableptr=TLookup(T_Table,"void");
								binding--;
								LInstall(&temp_table,"self",ttableptr,binding);
								binding--;
							}
						}
						//printf("check1");
									
					}
#line 2367 "y.tab.c"
    break;

  case 49:
#line 636 "task1.y"
                                                                                                                           {LTable=temp_table;temp_table=NULL;}
#line 2373 "y.tab.c"
    break;

  case 50:
#line 636 "task1.y"
                                                                                                                                                                        {m_temp=NULL;}
#line 2379 "y.tab.c"
    break;

  case 51:
#line 639 "task1.y"
                       {	/*printf("--check1a--")*/;codeGen((yyvsp[0].no),target,break_label,continue_label);temp1=LTable;
	  					while(temp1)
	  					{	//printf("check1");
	  						if(temp1->binding>=1)
	  							fprintf(target,"POP R0\n");
	  						temp1=temp1->next;
	  					}}
#line 2391 "y.tab.c"
    break;

  case 53:
#line 647 "task1.y"
                        {	printf("---check1b---");codeGen(NULL,target,break_label,continue_label);}
#line 2397 "y.tab.c"
    break;

  case 54:
#line 650 "task1.y"
                                {return_codeGen(target,(yyvsp[-1].no));}
#line 2403 "y.tab.c"
    break;

  case 55:
#line 653 "task1.y"
                     {(yyval.no) = createTree(0,2,3,"typeless",(yyvsp[-1].no),(yyvsp[0].no),NULL);}
#line 2409 "y.tab.c"
    break;

  case 56:
#line 654 "task1.y"
           {(yyval.no)=NULL;}
#line 2415 "y.tab.c"
    break;

  case 57:
#line 657 "task1.y"
                                 {	//printf("check1");
					gtemp=GLookup(GTable,(yyvsp[-3].string)); ltemp=Lookup(LTable,(yyvsp[-3].string)); //temp_list=PLookup(pml,$<string>1);
     					if(gtemp == NULL && ltemp==NULL){
                                        	yyerror("Undefined variable4");//exit(1);
					}
					/*if(ltemp && temp_list)
					{
						yyerror("Redefinition of variable");
						exit(0);
					}*/
					else
					{
						//printf("check1");
						if(ltemp)
                                			{(yyvsp[-3].no) = createID(0,1,(yyvsp[-3].string),0,ltemp->type->name,gtemp,NULL,NULL,NULL,NULL);/*printf("check2 ");printf("%d",ltemp->type);*/}
                                		/*else if(temp_list)
                                			{$<no>1 = createID(0,1,$<string>1,0,temp_list->type,NULL,NULL,NULL,NULL,NULL);}printf("check2 ");printf("%d",ltemp->type);*/
                                		else
                                		{
                                			if(gtemp->type)
                                				(yyvsp[-3].no) = createID(0,1,(yyvsp[-3].string),0,gtemp->type->name,gtemp,NULL,NULL,NULL,NULL);
                                			else if(gtemp->Ctype)
                                				(yyvsp[-3].no) = createID(0,1,(yyvsp[-3].string),0,gtemp->Ctype->Name,gtemp,NULL,NULL,NULL,NULL);
                                		}
                                			
                                	(yyvsp[-3].no)->Lentry = ltemp;
					(yyval.no) = createTree(0,2,4,"typeless",(yyvsp[-3].no),(yyvsp[-1].no),NULL);
				}
		}
#line 2449 "y.tab.c"
    break;

  case 58:
#line 687 "task1.y"
                                   {   gtemp=GLookup(GTable,(yyvsp[-3].string)); ltemp=Lookup(LTable,(yyvsp[-3].string));// temp_list=PLookup(pml,$<string>1);
     					if(gtemp == NULL && ltemp==NULL){
                                        	yyerror("Undefined variable4");//exit(1);
					}
					/*if(ltemp && temp_list)
					{
						yyerror("Redefinition of variable");
						exit(0);
					}*/
					else
					{
						if(ltemp)
                                			(yyvsp[-3].no) = createID(0,1,(yyvsp[-3].string),0,ltemp->type->name,gtemp,NULL,NULL,NULL,NULL);
                                		/*else if(temp_list)
                                			$<no>1 = createID(0,1,$<string>1,0,temp_list->type,NULL,NULL,NULL,NULL,NULL);*/
                                		else
                                		{
                                			if(gtemp->type)
                                				(yyvsp[-3].no) = createID(0,1,(yyvsp[-3].string),0,gtemp->type->name,gtemp,NULL,NULL,NULL,NULL);
                                			else if(gtemp->Ctype)
                                				(yyvsp[-3].no) = createID(0,1,(yyvsp[-3].string),0,gtemp->Ctype->Name,gtemp,NULL,NULL,NULL,NULL);
                                		}
                                        	(yyvsp[-3].no)->Lentry = ltemp;
						(yyvsp[-1].no)=createID(0,5,(yyvsp[-1].string),0,"str",NULL,NULL,NULL,NULL,NULL);
                                        	(yyval.no) = createTree(0,2,4,"typeless",(yyvsp[-3].no),(yyvsp[-1].no),NULL);
                                      }
                                  }
#line 2481 "y.tab.c"
    break;

  case 59:
#line 715 "task1.y"
                                        {
						 (yyvsp[-1].no)=createID(0,5,(yyvsp[-1].string),0,"str",NULL,NULL,NULL,NULL,NULL);
                                                (yyval.no) = createTree(0,2,4,"typeless",(yyvsp[-3].no),(yyvsp[-1].no),NULL);
                                           }
#line 2490 "y.tab.c"
    break;

  case 60:
#line 720 "task1.y"
                                      {(yyval.no) = createTree(0,2,4,"typeless",(yyvsp[-3].no),(yyvsp[-1].no),NULL);}
#line 2496 "y.tab.c"
    break;

  case 61:
#line 721 "task1.y"
                                        {(yyval.no) = createTree(0,2,4,"typeless",(yyvsp[-3].no),(yyvsp[-1].no),NULL);}
#line 2502 "y.tab.c"
    break;

  case 62:
#line 723 "task1.y"
                                        {
						(yyvsp[-1].no)=createID(0,5,(yyvsp[-1].string),0,"str",NULL,NULL,NULL,NULL,NULL);
						(yyval.no) = createTree(0,2,4,"typeless",(yyvsp[-3].no),(yyvsp[-1].no),NULL);
					}
#line 2511 "y.tab.c"
    break;

  case 63:
#line 728 "task1.y"
                                                        {(yyval.no) =createTree(0,2,15,"typeless",(yyvsp[-6].no),(yyvsp[-4].no),(yyvsp[-2].no));}
#line 2517 "y.tab.c"
    break;

  case 64:
#line 729 "task1.y"
                                             {(yyval.no) =createTree(0,2,15,"typeless",(yyvsp[-4].no),(yyvsp[-2].no),NULL);}
#line 2523 "y.tab.c"
    break;

  case 65:
#line 730 "task1.y"
                                        {(yyval.no) = createTree(0,2,1,"typeless",NULL,(yyvsp[-1].no),NULL);}
#line 2529 "y.tab.c"
    break;

  case 66:
#line 731 "task1.y"
                                        {(yyval.no) = createTree(0,2,2,"typeless",NULL,(yyvsp[-1].no),NULL);}
#line 2535 "y.tab.c"
    break;

  case 67:
#line 733 "task1.y"
                                         { 
	    				 	 (yyvsp[-2].no)=createID(0,5,(yyvsp[-2].string),0,"str",NULL,NULL,NULL,NULL,NULL);
	    				  	(yyval.no) = createTree(0,2,2,"typeless",NULL,(yyvsp[-2].no),NULL);
					}
#line 2544 "y.tab.c"
    break;

  case 68:
#line 738 "task1.y"
                                                 {(yyval.no)=createTree(0,2,16,"typeless",(yyvsp[-4].no),(yyvsp[-2].no),NULL);}
#line 2550 "y.tab.c"
    break;

  case 69:
#line 739 "task1.y"
                                {(yyval.no)=createTree(0,3,0,"typeless",NULL,NULL,NULL);}
#line 2556 "y.tab.c"
    break;

  case 70:
#line 740 "task1.y"
                                {(yyval.no)=createTree(0,4,0,"typeless",NULL,NULL,NULL);}
#line 2562 "y.tab.c"
    break;

  case 71:
#line 742 "task1.y"
                                               {
							gtemp=GLookup(GTable,(yyvsp[-5].string)); ltemp=Lookup(LTable,(yyvsp[-5].string));
     							if(gtemp == NULL && ltemp==NULL){
                                        			yyerror("Undefined variable");exit(1);
							}
							else
							{
								if(ltemp)
                                					(yyvsp[-5].no) = createID(0,1,(yyvsp[-5].string),0,ltemp->type->name,gtemp,NULL,NULL,NULL,NULL);
                                				else
                                					(yyvsp[-5].no) = createID(0,1,(yyvsp[-5].string),0,gtemp->type->name,gtemp,NULL,NULL,NULL,NULL);
                                		
                                				(yyvsp[-5].no)->Lentry = ltemp;
                                			}
							(yyval.no)=createTree(0,2,22,"typeless",(yyvsp[-5].no),NULL,NULL);
						}
#line 2583 "y.tab.c"
    break;

  case 72:
#line 759 "task1.y"
                                                  {(yyval.no)=createTree(0,2,22,"typeless",(yyvsp[-5].no),NULL,NULL);}
#line 2589 "y.tab.c"
    break;

  case 73:
#line 761 "task1.y"
                                          {
							gtemp=GLookup(GTable,(yyvsp[-5].string)); ltemp=Lookup(LTable,(yyvsp[-5].string));
     							if(gtemp == NULL && ltemp==NULL){
                                        			yyerror("Undefined variable");exit(1);
							}
							else
							{
								if(ltemp)
                                					(yyvsp[-5].no) = createID(0,1,(yyvsp[-5].string),0,ltemp->type->name,gtemp,NULL,NULL,NULL,NULL);
                                				else
                                					(yyvsp[-5].no) = createID(0,1,(yyvsp[-5].string),0,gtemp->type->name,gtemp,NULL,NULL,NULL,NULL);
                                		
                                				(yyvsp[-5].no)->Lentry = ltemp;
                                			}
							(yyval.no)=createTree(0,2,20,"typeless",(yyvsp[-5].no),NULL,NULL);
						}
#line 2610 "y.tab.c"
    break;

  case 74:
#line 778 "task1.y"
                                             {(yyval.no)=createTree(0,2,20,"typeless",(yyvsp[-5].no),NULL,NULL);}
#line 2616 "y.tab.c"
    break;

  case 75:
#line 780 "task1.y"
                                    {
							gtemp=GLookup(GTable,(yyvsp[-4].string)); ltemp=Lookup(LTable,(yyvsp[-4].string));
     							if(gtemp == NULL && ltemp==NULL){
                                        			yyerror("Undefined variable");exit(1);
							}
							else
							{
								if(ltemp)
                                					(yyvsp[-4].no) = createID(0,1,(yyvsp[-4].string),0,ltemp->type->name,gtemp,NULL,NULL,NULL,NULL);
                                				else
                                					(yyvsp[-4].no) = createID(0,1,(yyvsp[-4].string),0,gtemp->type->name,gtemp,NULL,NULL,NULL,NULL);
                                		
                                				(yyvsp[-4].no)->Lentry = ltemp;
                                			}
							(yyval.no)=createTree(0,2,21,"typeless",(yyvsp[-4].no),NULL,NULL);
					}
#line 2637 "y.tab.c"
    break;

  case 76:
#line 797 "task1.y"
                                        {(yyval.no)=createTree(0,2,21,"typeless",(yyvsp[-4].no),NULL,NULL);}
#line 2643 "y.tab.c"
    break;

  case 77:
#line 799 "task1.y"
                                           {
						gtemp=GLookup(GTable,(yyvsp[-6].string));
						if(gtemp == NULL){
                                        		yyerror("Undefined variable");exit(1);
						}
						else
						{
							if(gtemp->Ctype == NULL)
							{
								yyerror("ERROR-1");exit(0);
							}
							//printf("--%s--",$<string>5);
							P_Cptr=CLookup(CTable,(yyvsp[-2].string));
							if(P_Cptr)
							{
								//$<no>5 = createID(0,1,$<string>5,0,P_Cptr->Name,NULL,NULL,NULL,NULL,NULL);
								while(P_Cptr)
								{	
									/*if(gtemp->type)
										$<no>1 = createID(0,1,$<string>1,0,gtemp->type->name,gtemp,NULL,NULL,NULL,NULL);
									else if(gtemp->Ctype) */
								//printf("check1");
								//printf("**%s**%s** ",P_Cptr->Name,gtemp->Ctype->Name);
									if(strcmp(P_Cptr->Name,gtemp->Ctype->Name)==0)
									{
										(yyvsp[-6].no) = createID(0,1,(yyvsp[-6].string),0,gtemp->Ctype->Name,gtemp,NULL,NULL,NULL,NULL);
										(yyval.no)=createTree(0,11,0,(yyvsp[-2].string),(yyvsp[-6].no),(yyvsp[-2].no),NULL);
										//printf("-*-%s-*-",$<string>5);
										//printf("-*-%s-*-",$<no>$->expr_type);
										break;
									}
									P_Cptr=P_Cptr->Parentptr;
								}
							}
							if(P_Cptr==NULL)
							{
								yyerror("Different class initialization error");exit(0);
							}
						}
					}
#line 2688 "y.tab.c"
    break;

  case 78:
#line 840 "task1.y"
                                                {
							
							P_Cptr=CLookup(CTable,(yyvsp[-2].string));
							if(P_Cptr)
							{
								//$<no>5 = createID(0,1,$<string>5,0,P_Cptr->Name,NULL,NULL,NULL,NULL,NULL);
								while(P_Cptr)
								{	
									if(strcmp(P_Cptr->Name,(yyvsp[-6].no)->expr_type)==0)
									{
										(yyval.no)=createTree(0,11,0,(yyvsp[-2].string),(yyvsp[-6].no),(yyvsp[-2].no),NULL);
										//printf("--%s--",$<no>$->expr_type);
										break;
									}
									P_Cptr=P_Cptr->Parentptr;
								}
							}
							if(P_Cptr==NULL)
							{
								yyerror("Different class initialization error");exit(0);
							}
						}
#line 2715 "y.tab.c"
    break;

  case 79:
#line 864 "task1.y"
                         {(yyval.no) = createTree(0,2,5,"int",(yyvsp[-2].no),(yyvsp[0].no),NULL);}
#line 2721 "y.tab.c"
    break;

  case 80:
#line 865 "task1.y"
                          {(yyval.no) = createTree(0,2,6,"int",(yyvsp[-2].no),(yyvsp[0].no),NULL);}
#line 2727 "y.tab.c"
    break;

  case 81:
#line 866 "task1.y"
                        {(yyval.no) = createTree(0,2,7,"int",(yyvsp[-2].no),(yyvsp[0].no),NULL);}
#line 2733 "y.tab.c"
    break;

  case 82:
#line 867 "task1.y"
                        {(yyval.no) = createTree(0,2,8,"int",(yyvsp[-2].no),(yyvsp[0].no),NULL);}
#line 2739 "y.tab.c"
    break;

  case 83:
#line 868 "task1.y"
                         {(yyval.no) = createTree(0,2,19,"int",(yyvsp[-2].no),(yyvsp[0].no),NULL);}
#line 2745 "y.tab.c"
    break;

  case 84:
#line 869 "task1.y"
                       {(yyval.no)=(yyvsp[-1].no);}
#line 2751 "y.tab.c"
    break;

  case 85:
#line 870 "task1.y"
                {(yyval.no) =createTree((yyvsp[0].a),0,0,"int",NULL,NULL,NULL);}
#line 2757 "y.tab.c"
    break;

  case 86:
#line 871 "task1.y"
                                {	
					gtemp=GLookup(GTable,(yyvsp[0].string)); ltemp=Lookup(LTable,(yyvsp[0].string)); //temp_list=PLookup(pml,$<string>1);
     					if(gtemp == NULL && ltemp==NULL){
                                        	yyerror("Undefined variable");exit(1);
					}
					/*if(ltemp && temp_list)
					{
						yyerror("Redefinition of variable");
						exit(0);
					}*/
					else
					{
						if(ltemp)
                                			(yyvsp[0].no) = createID(0,1,(yyvsp[0].string),0,ltemp->type->name,gtemp,NULL,NULL,NULL,NULL);
                                		/*else if(temp_list)
                                			{$<no>1 = createID(0,1,$<string>1,0,temp_list->type,NULL,NULL,NULL,NULL,NULL);}printf("check2 ");printf("%d",temp_list->type);*/
                                		else
                                		{
                                			if(gtemp->type)
                                				(yyvsp[0].no) = createID(0,1,(yyvsp[0].string),0,gtemp->type->name,gtemp,NULL,NULL,NULL,NULL);
                                			else if(gtemp->Ctype)
                                				(yyvsp[0].no) = createID(0,1,(yyvsp[0].string),0,gtemp->Ctype->Name,gtemp,NULL,NULL,NULL,NULL);
                                		}
                                		
                                		(yyvsp[0].no)->Lentry = ltemp;
                                		(yyval.no)=(yyvsp[0].no);
                                	}
				}
#line 2790 "y.tab.c"
    break;

  case 87:
#line 899 "task1.y"
                             {
                                temp = GLookup(GTable,(yyvsp[-3].string));
                                if(temp == NULL){
                                	yyerror("EROR- Undefined function1");
                                }
                                else if(!check_func_arg((yyvsp[-1].Pl),temp->paramlist))
				 {
					yyerror("argument error");
				 }
                                else
                                {	
                                	(yyval.no) = createID(0,6,(yyvsp[-3].string),0,temp->type->name,temp,NULL,NULL,NULL,(yyvsp[-1].Pl));
                                	(yyval.no)->Gentry = temp;
                                }
                              }
#line 2810 "y.tab.c"
    break;

  case 88:
#line 930 "task1.y"
                        {(yyval.no) = createTree(0,2,17,"bool",(yyvsp[-2].no),(yyvsp[0].no),NULL);}
#line 2816 "y.tab.c"
    break;

  case 89:
#line 931 "task1.y"
                        {(yyval.no) = createTree(0,2,18,"bool",(yyvsp[-2].no),(yyvsp[0].no),NULL);}
#line 2822 "y.tab.c"
    break;

  case 90:
#line 932 "task1.y"
                        {(yyval.no) = createTree(0,2,9,"bool",(yyvsp[-2].no),(yyvsp[0].no),NULL);}
#line 2828 "y.tab.c"
    break;

  case 91:
#line 933 "task1.y"
                        {(yyval.no) = createTree(0,2,10,"bool",(yyvsp[-2].no),(yyvsp[0].no),NULL);}
#line 2834 "y.tab.c"
    break;

  case 92:
#line 934 "task1.y"
                        {(yyval.no) = createTree(0,2,11,"bool",(yyvsp[-2].no),(yyvsp[0].no),NULL);}
#line 2840 "y.tab.c"
    break;

  case 93:
#line 935 "task1.y"
                        {(yyval.no) = createTree(0,2,12,"bool",(yyvsp[-2].no),(yyvsp[0].no),NULL);}
#line 2846 "y.tab.c"
    break;

  case 94:
#line 936 "task1.y"
                        {(yyval.no) = createTree(0,2,13,"bool",(yyvsp[-2].no),(yyvsp[0].no),NULL);}
#line 2852 "y.tab.c"
    break;

  case 95:
#line 937 "task1.y"
                        {(yyval.no) = createTree(0,2,14,"bool",(yyvsp[-2].no),(yyvsp[0].no),NULL);}
#line 2858 "y.tab.c"
    break;

  case 96:
#line 938 "task1.y"
                         {(yyval.no)= (yyvsp[0].no);}
#line 2864 "y.tab.c"
    break;

  case 97:
#line 939 "task1.y"
                 {(yyval.no)= (yyvsp[0].no);}
#line 2870 "y.tab.c"
    break;

  case 98:
#line 940 "task1.y"
                        { (yyval.no) = createTree(0,9,0,"void",NULL,NULL,NULL);}
#line 2876 "y.tab.c"
    break;

  case 99:
#line 941 "task1.y"
                        {(yyval.no)=(yyvsp[0].no);}
#line 2882 "y.tab.c"
    break;

  case 100:
#line 944 "task1.y"
                        {	
				gtemp=GLookup(GTable,(yyvsp[-2].string)); ltemp=Lookup(LTable,(yyvsp[-2].string));
     				if(gtemp == NULL && ltemp==NULL){
                                       yyerror("Undefined variable");exit(1);
				}
				else
				{
					if(ltemp)
					{	//if(ltemp->type==NULL)
							//exit(0);
						F_list= FLookup(ltemp->type->fields,(yyvsp[0].string));
						if(F_list==NULL || F_list->type==NULL)
						{
							yyerror("Undefined variable");exit(1);
						}
						//if(F_list!=NULL)exit(0);
                               		(yyvsp[-2].no) = createID(0,1,(yyvsp[-2].string),0,ltemp->type->name,gtemp,NULL,NULL,NULL,NULL);
                               		
                               		(yyvsp[0].no) = createID(F_list->fieldIndex,1,(yyvsp[0].string),0,F_list->type->name,NULL,NULL,NULL,NULL,NULL);
                               		(yyval.no) = createTree(0,8,0,F_list->type->name,(yyvsp[-2].no),(yyvsp[0].no),NULL);
                               		
                               	}
                                	else
                                	{
                                		//if(gtemp->type==NULL)
						//	exit(0);
						if(gtemp->type)
							F_list= FLookup(gtemp->type->fields,(yyvsp[0].string));
						else if(gtemp->Ctype)
							F_list= FLookup(gtemp->Ctype->Memberfield,(yyvsp[0].string));
							
						if(F_list==NULL || F_list->type==NULL)
						{
							yyerror("Undefined variable");exit(1);
						}
						//if(F_list!=NULL)exit(0);
						if(gtemp->type)
                               			(yyvsp[-2].no) = createID(0,1,(yyvsp[-2].string),0,gtemp->type->name,gtemp,NULL,NULL,NULL,NULL);
                               		else if(gtemp->Ctype)
                               			(yyvsp[-2].no) = createID(0,1,(yyvsp[-2].string),0,gtemp->Ctype->Name,gtemp,NULL,NULL,NULL,NULL);
                               			
                               		(yyvsp[0].no) = createID(F_list->fieldIndex,1,(yyvsp[-2].string),0,F_list->type->name,NULL,NULL,NULL,NULL,NULL);
                               		(yyval.no) = createTree(0,8,0,F_list->type->name,(yyvsp[-2].no),(yyvsp[0].no),NULL);
                               		//if(F_list!=NULL)exit(0);
                               	}
                                		
                                	(yyvsp[-2].no)->Lentry = ltemp;
                                	(yyval.no)->Gentry = gtemp;
                                	(yyval.no)->Lentry = ltemp;
                                	
                               }
                              // $<no>$=NULL;
			}
#line 2940 "y.tab.c"
    break;

  case 101:
#line 998 "task1.y"
                        {
        				ttableptr=TLookup(T_Table,(yyvsp[-2].no)->expr_type);
        				c_temp=CLookup(CTable,(yyvsp[-2].no)->expr_type);
        				if(ttableptr)
        					F_list= FLookup(ttableptr->fields,(yyvsp[0].string));
        				else if(c_temp)
        					F_list= FLookup(c_temp->Memberfield,(yyvsp[0].string));
        				if(F_list==NULL || F_list->type==NULL)
					{
						yyerror("Undefined variable2");exit(1);
					}
					
					if(F_list->type)
                               		(yyvsp[0].no) = createID(F_list->fieldIndex,1,(yyvsp[0].string),0,F_list->type->name,NULL,NULL,NULL,NULL,NULL);
                               	else if(F_list->Ctype)
                               		(yyvsp[0].no) = createID(F_list->fieldIndex,1,(yyvsp[0].string),0,F_list->Ctype->Name,NULL,NULL,NULL,NULL,NULL);
                               		
                               	if(F_list->type)
                               		(yyval.no) = createTree(0,8,0,F_list->type->name,(yyvsp[-2].no),(yyvsp[0].no),NULL);
                               	else if(F_list->Ctype)
                               		(yyval.no) = createTree(0,8,0,F_list->Ctype->Name,(yyvsp[-2].no),(yyvsp[0].no),NULL);
        				/*gtemp=$<no>1->Gentry;
        				ltemp=$<no>1->Lentry;
        				if(gtemp == NULL && ltemp==NULL){
                                       	yyerror("Undefined variable1");exit(1);
					}
					else
					{
						if(ltemp)
						{
							if(ltemp->type==NULL)
							    exit(0);
							F_list= FLookup(ltemp->type->fields,$<string>3);
							if(F_list==NULL || F_list->type==NULL)
							{
								yyerror("Undefined variable2");exit(1);
							}
                               			$<no>3 = createID(F_list->fieldIndex,1,$<string>3,0,F_list->type->name,NULL,NULL,NULL,NULL,NULL);
                               			$<no>$ = createTree(0,8,0,F_list->type->name,$<no>1,$<no>3,NULL);
                               		}
                                		else
                                		{
                                			if(gtemp->type==NULL)
							     exit(0);
							F_list= FLookup(gtemp->type->fields,$<string>3);
							if(F_list==NULL || F_list->type==NULL)
							{
								yyerror("Undefined variable3");exit(1);
							}
                               			$<no>3 = createID(F_list->fieldIndex,1,$<string>1,0,F_list->type->name,NULL,NULL,NULL,NULL,NULL);
                               			$<no>$ = createTree(0,8,0,F_list->type->name,$<no>1,$<no>3,NULL);
                               		}
                                		
                                		$<no>1->Lentry = ltemp;
                                		$<no>$->Gentry = gtemp;
                                		$<no>$->Lentry = ltemp;
                               	}*/
                               	//$<no>$=NULL;
				}
#line 3004 "y.tab.c"
    break;

  case 102:
#line 1057 "task1.y"
                                                 {
							//if(Cptr!=NULL) exit(0);
							//if(Cptr!=NULL) printf("**%s**",Cptr->Name);
							
							f_temp=Class_Flookup(Cptr,(yyvsp[0].string));//printf("**%s**",f_temp->name);
							if(f_temp==NULL)
							{	yyerror("Field not present1");exit(0);}
							
							else
                                			{	//if(f_temp->type==NULL)
                                				//	exit(0);
                                				(yyvsp[-2].no)= createID(0,1,"self",0,"typeless",NULL,NULL,NULL,NULL,NULL);
                                				if(f_temp->type)
                                					(yyvsp[0].no) = createID(f_temp->fieldIndex,1,(yyvsp[0].string),0,f_temp->type->name,NULL,NULL,NULL,NULL,NULL);
                                				else if(f_temp->Ctype)
                                					(yyvsp[0].no) = createID(f_temp->fieldIndex,1,(yyvsp[0].string),0,f_temp->Ctype->Name,NULL,NULL,NULL,NULL,NULL);
                                					
                                				if(f_temp->type)	
                               					(yyval.no) = createTree(0,8,0,f_temp->type->name,(yyvsp[-2].no),(yyvsp[0].no),NULL);
                               				else if(f_temp->Ctype)
                               					(yyval.no) = createTree(0,8,0,f_temp->Ctype->Name,(yyvsp[-2].no),(yyvsp[0].no),NULL);
                     					 }
						}
#line 3032 "y.tab.c"
    break;

  case 103:
#line 1082 "task1.y"
                                              {
							//printf("check1a");
							m_temp=Class_Mlookup(Cptr,(yyvsp[-3].string));
							if(m_temp==NULL)
								yyerror("Function not declared");
							else if(!check_func_arg((yyvsp[-1].Pl),m_temp->paramlist))
							{
								yyerror("Argument error");exit(0);
							}
							else
                                			{	
                                				//if(Cptr)
                                			//	printf("%s--%s ",Cptr->Name,$<string>3);
                                				(yyvsp[-5].no) = createID(0,1,"self",0,"typeless",NULL,NULL,NULL,NULL,NULL);
                                				(yyvsp[-3].no) = createID(m_temp->Funcposition,10,(yyvsp[-3].string),0,m_temp->type->name,NULL,NULL,NULL,NULL,NULL);
                                				(yyval.no) = createID(0,10,(yyvsp[-3].string),0,m_temp->type->name,NULL,(yyvsp[-5].no),(yyvsp[-3].no),NULL,(yyvsp[-1].Pl));
                     					 }
						}
#line 3055 "y.tab.c"
    break;

  case 104:
#line 1100 "task1.y"
                                            {
						gtemp=GLookup(GTable,(yyvsp[-5].string));
						if(gtemp == NULL){
                                        		yyerror("Undefined variable");exit(1);
						}
						else
						{
							Cptr=gtemp->Ctype;
							//if(Cptr)
							
							m_temp=Class_Mlookup(Cptr,(yyvsp[-3].string));
							if(m_temp==NULL)
								yyerror("Function not declared");
							else if(!check_func_arg((yyvsp[-1].Pl),m_temp->paramlist))
							{
								yyerror("Argument Error");exit(0);
							}
							else
                                			{	
                                				//printf("%s--%s--%d ",Cptr->Name,$<string>3,m_temp->Flabel);
                                				(yyvsp[-5].no) = createID(0,1,(yyvsp[-5].string),0,gtemp->Ctype->Name,gtemp,NULL,NULL,NULL,NULL);
                                				(yyvsp[-3].no) = createID(m_temp->Funcposition,10,(yyvsp[-3].string),0,m_temp->type->name,NULL,NULL,NULL,NULL,NULL);
                                				(yyval.no) = createID(0,10,(yyvsp[-3].string),0,m_temp->type->name,NULL,(yyvsp[-5].no),(yyvsp[-3].no),NULL,(yyvsp[-1].Pl));
                     					}
						}
						//printf("check1b");
					}
#line 3087 "y.tab.c"
    break;

  case 105:
#line 1128 "task1.y"
                                                {
								c_temp=CLookup(CTable,(yyvsp[-5].no)->expr_type);
							//	if(c_temp)
							//	printf("%s--%s ",c_temp->Name,$<string>3);
								//printf("**%s**",c_temp->Vfuncptr->name);
								m_temp=Class_Mlookup(c_temp,(yyvsp[-3].string));
								if(m_temp==NULL)
									yyerror("Function not declared2");
								else if(!check_func_arg((yyvsp[-1].Pl),m_temp->paramlist))
								{
									yyerror("Argument error");exit(0);
								}
								else
                                				{	
                                					(yyvsp[-3].no) = createID(m_temp->Funcposition,10,(yyvsp[-3].string),0,m_temp->type->name,NULL,NULL,NULL,NULL,NULL);
                                					(yyval.no) = createID(0,10,(yyvsp[-3].string),0,m_temp->type->name,NULL,(yyvsp[-5].no),(yyvsp[-3].no),NULL,(yyvsp[-1].Pl));
                     						 }
                     					//printf("Check1a");
                     					}
#line 3111 "y.tab.c"
    break;

  case 106:
#line 1149 "task1.y"
                          {
                                temp=GLookup(GTable,(yyvsp[-3].string));
                                if(temp)
                                {
                                	if((yyvsp[-1].no)->type==0)
                                	{
                                		if((yyvsp[-1].no)->val>=temp->size)
						{
							yyerror("Index out of range");
							exit(0);
						}
                                	}
                                	else
                                	{
						if(strcmp((yyvsp[-1].no)->expr_type,"int")!=0)
						{
							{
								yyerror("Type mismatch");
								exit(0);
							}
						}
					}	
                                       (yyval.no) = createID(0,7,(yyvsp[-3].string),0,temp->type->name,temp,(yyvsp[-1].no),NULL,NULL,NULL);                                
                                }
                                else
                                {
                                        yyerror("ERROR-Variable not declared");
                                        exit(0);
                                }
                        }
#line 3146 "y.tab.c"
    break;

  case 107:
#line 1182 "task1.y"
                                {
                                        struct Paramstruct *temp_list,*list;
                                        list=(struct Paramstruct*)malloc(sizeof(struct Paramstruct));
                                        list->type=(char*)malloc(sizeof(char)*100);
                         		 list->type=(yyvsp[0].no)->expr_type;
                         		 list->val=(yyvsp[0].no);
                         		 list->next=NULL;
                         		 
                                        temp_list=(yyvsp[-2].Pl);
                                        //int flag=0;
                                       if(temp_list)
                                        {
                                        	while(temp_list->next!=NULL)
                                        	{
                                        	    temp_list=temp_list->next;
                                        	}
                                        	temp_list->next=list;
                                        	(yyval.Pl)=(yyvsp[-2].Pl);
                                        }
                                        else
                                        //free(list);    
						(yyval.Pl)=list;    
                               }
#line 3174 "y.tab.c"
    break;

  case 108:
#line 1206 "task1.y"
                               {
        				(yyvsp[0].no)=createID(0,5,(yyvsp[0].string),0,"str",NULL,NULL,NULL,NULL,NULL);
        				struct Paramstruct *temp_list,*list;
                                        list=(struct Paramstruct*)malloc(sizeof(struct Paramstruct));
                                        list->type=(char*)malloc(sizeof(char)*100);
                         		 list->type=(yyvsp[0].no)->expr_type;
                         		 list->name=(char*)malloc(sizeof(char)*100);
                         		 list->name=(yyvsp[0].string);
                         		 list->val=(yyvsp[0].no);
                         		 list->next=NULL;
                         		 
                         		 temp_list=(yyvsp[-2].Pl);
                                        //int flag=0;
                                        if(temp_list)
                                        {
                                        	while(temp_list->next!=NULL)
                                        	{
                                        	    temp_list=temp_list->next;
                                        	}
                                        	temp_list->next=list;
                                        	(yyval.Pl)=(yyvsp[-2].Pl);
                                        }
                                        else
                                        //free(list);    
						(yyval.Pl)=list;  
                               }
#line 3205 "y.tab.c"
    break;

  case 109:
#line 1233 "task1.y"
                {
                         struct Paramstruct * list;
                         list=(struct Paramstruct*)malloc(sizeof(struct Paramstruct));
                         list->type=(char*)malloc(sizeof(char)*100);
                         list->type=(yyvsp[0].no)->expr_type;
                         list->val=(yyvsp[0].no);
                         list->next=NULL;
                         (yyval.Pl)=list;
                         //free(list);
                }
#line 3220 "y.tab.c"
    break;

  case 110:
#line 1244 "task1.y"
                {
       		(yyvsp[0].no)=createID(0,5,(yyvsp[0].string),0,"str",NULL,NULL,NULL,NULL,NULL);
       		
       			struct Paramstruct * list;
                         	list=(struct Paramstruct*)malloc(sizeof(struct Paramstruct));
                         	list->type=(char*)malloc(sizeof(char)*100);
                        	list->type=(yyvsp[0].no)->expr_type;
                         	list->name=(char*)malloc(sizeof(char)*100);
                         	strcpy(list->name,(yyvsp[0].string));
                         	list->val=(yyvsp[0].no);
                         	list->next=NULL;
                         	(yyval.Pl)=list;
                         //free(list);
                }
#line 3239 "y.tab.c"
    break;

  case 111:
#line 1259 "task1.y"
          {(yyval.Pl)=NULL;}
#line 3245 "y.tab.c"
    break;

  case 112:
#line 1263 "task1.y"
                              {pml=NULL; fprintf(target, "MAIN:\n"); fprintf(target,"PUSH BP\n"); fprintf(target,"MOV BP, SP\n");}
#line 3251 "y.tab.c"
    break;

  case 113:
#line 1265 "task1.y"
                                        {	
						ttableptr=TLookup(T_Table,(yyvsp[-4].string));
						if(!ttableptr)
	   					{
	   						yyerror("type not defined in type table");exit(0);
	   					}
	  					GInstall(&GTable,"MAIN",ttableptr,0,0,NULL,0);
	  					//LTable=NULL;
						//some more work to be done
					}
#line 3266 "y.tab.c"
    break;

  case 114:
#line 1275 "task1.y"
                                                          {LTable=temp_table;temp_table=NULL;}
#line 3272 "y.tab.c"
    break;

  case 116:
#line 1278 "task1.y"
                                         {
						temp1=temp_table;
						printf("LST---------\n");
					
					//	if(temp_table!=NULL)
					//		printf("check2");
					
						while(temp1)
        					{
         						printf("%s ",temp1->name);
         						if(temp1->binding>0);
        					        printf("type=%s ",temp1->type->name);
        					       // printf("size =%d ",temp1->size);
        					       printf("binding =%d ",temp1->binding);
         					       F_list=temp1->type->fields;
	 					       if(F_list)
	    					       {
								printf("Fields = ");
								while(F_list)
								{
									printf("%s - ",F_list->name);
									F_list=F_list->next;
								}
	    						 }
	     						else
								printf("Fields = NULL");
              						temp1=temp1->next;
              						printf("\n");
        					}
        					printf("-----------------\n");
        					lbinding=1;
        				}
#line 3309 "y.tab.c"
    break;

  case 117:
#line 1311 "task1.y"
                                {
	        			lbinding=1;temp1=temp_table;
					printf("LST---------\n");
					
					//if(temp_table!=NULL)
					//	printf("check2");
					
					while(temp1)
        				{
              					printf("%s ",temp1->name);
              					if(temp1->binding>0);
              					printf("type=%s ",temp1->type->name);
             					// printf("size =%d ",temp1->size);
              					printf("binding =%d ",temp1->binding);
              					F_list=temp1->type->fields;
	     					if(F_list)
	     					{
							printf("Fields = ");
							while(F_list)
							{
								printf("%s - ",F_list->name);
								F_list=F_list->next;
							}
	     					}
	     					else
							printf("Fields = NULL");
              					temp1=temp1->next;
              					printf("\n");
        				}
        				printf("-----------------\n");
        				}
#line 3345 "y.tab.c"
    break;

  case 118:
#line 1343 "task1.y"
         {
        	lbinding=1;temp1=temp_table;
		printf("LST---------\n");
		if(temp_table==NULL)
			exit(0);
		while(temp1)
        	{
              		printf("%s ",temp1->name);
              		if(temp1->binding>0);
              		printf("type=%s ",temp1->type->name);
             		// printf("size =%d ",temp1->size);
              		printf("binding =%d ",temp1->binding);
              		F_list=temp1->type->fields;
	     		if(F_list)
	     		{
				printf("Fields = ");
				while(F_list)
				{
					printf("%s - ",F_list->name);
					F_list=F_list->next;
				}
	     		}
	     		else
				printf("Fields = NULL");
              		temp1=temp1->next;
             		printf("\n");
        	}
        	printf("-----------------\n");
        }
#line 3379 "y.tab.c"
    break;

  case 121:
#line 1378 "task1.y"
                                            {	
						ttableptr=TLookup(T_Table,(yyvsp[-2].string));
						if(!ttableptr)
	   					{
	   						yyerror("type not defined in type table");exit(0);
	   					}
						
       					temp1=temp_table;
						while(temp1 && temp1->type==NULL)
						{
							temp1->type=ttableptr;
							temp1=temp1->next;
						}
					}
#line 3398 "y.tab.c"
    break;

  case 122:
#line 1394 "task1.y"
                                        {	//printf("check2");
				if(check_Reserved(Keywords,(yyvsp[0].string)))
				{
					yyerror("ERROR reserved word declared as variable");
				}
				else if(!Lookup(temp_table,(yyvsp[0].string)))
	 		     	{
	 		     		//printf("**%d **",lbinding);
	 				LInstall(&temp_table,(yyvsp[0].string),NULL,lbinding);
					lbinding++;
				        fprintf(target,"PUSH R0\n");
				}
				else
				{
					yyerror("ERROR-Multiple Declaration of same variable");
				}
			     }
#line 3420 "y.tab.c"
    break;

  case 123:
#line 1411 "task1.y"
                     {	//printf("check3");
			if(check_Reserved(Keywords,(yyvsp[0].string)))
			{
				yyerror("ERROR reserved word declared as variable");
			}
			else if(!Lookup(temp_table,(yyvsp[0].string)))
                         {
                         	// printf("**%d **",lbinding);
                         	 LInstall(&temp_table,(yyvsp[0].string),NULL,lbinding);
                                lbinding++;
                                fprintf(target,"PUSH R0\n");
                         }
                         else
			 {
                                yyerror("ERROR-Multiple Declaration of same variable");
			 }
		}
#line 3442 "y.tab.c"
    break;

  case 124:
#line 1430 "task1.y"
                      {(yyval.string)=(yyvsp[0].string);}
#line 3448 "y.tab.c"
    break;

  case 125:
#line 1431 "task1.y"
                      {(yyval.string)=(yyvsp[0].string);}
#line 3454 "y.tab.c"
    break;

  case 126:
#line 1432 "task1.y"
                      {(yyval.string)=(yyvsp[0].string);}
#line 3460 "y.tab.c"
    break;


#line 3464 "y.tab.c"

      default: break;
    }
  /* User semantic actions sometimes alter yychar, and that requires
     that yytoken be updated with the new translation.  We take the
     approach of translating immediately before every use of yytoken.
     One alternative is translating here after every semantic action,
     but that translation would be missed if the semantic action invokes
     YYABORT, YYACCEPT, or YYERROR immediately after altering yychar or
     if it invokes YYBACKUP.  In the case of YYABORT or YYACCEPT, an
     incorrect destructor might then be invoked immediately.  In the
     case of YYERROR or YYBACKUP, subsequent parser actions might lead
     to an incorrect destructor call or verbose syntax error message
     before the lookahead is translated.  */
  YY_SYMBOL_PRINT ("-> $$ =", yyr1[yyn], &yyval, &yyloc);

  YYPOPSTACK (yylen);
  yylen = 0;
  YY_STACK_PRINT (yyss, yyssp);

  *++yyvsp = yyval;

  /* Now 'shift' the result of the reduction.  Determine what state
     that goes to, based on the state we popped back to and the rule
     number reduced by.  */
  {
    const int yylhs = yyr1[yyn] - YYNTOKENS;
    const int yyi = yypgoto[yylhs] + *yyssp;
    yystate = (0 <= yyi && yyi <= YYLAST && yycheck[yyi] == *yyssp
               ? yytable[yyi]
               : yydefgoto[yylhs]);
  }

  goto yynewstate;


/*--------------------------------------.
| yyerrlab -- here on detecting error.  |
`--------------------------------------*/
yyerrlab:
  /* Make sure we have latest lookahead translation.  See comments at
     user semantic actions for why this is necessary.  */
  yytoken = yychar == YYEMPTY ? YYEMPTY : YYTRANSLATE (yychar);

  /* If not already recovering from an error, report this error.  */
  if (!yyerrstatus)
    {
      ++yynerrs;
#if ! YYERROR_VERBOSE
      yyerror (YY_("syntax error"));
#else
# define YYSYNTAX_ERROR yysyntax_error (&yymsg_alloc, &yymsg, \
                                        yyssp, yytoken)
      {
        char const *yymsgp = YY_("syntax error");
        int yysyntax_error_status;
        yysyntax_error_status = YYSYNTAX_ERROR;
        if (yysyntax_error_status == 0)
          yymsgp = yymsg;
        else if (yysyntax_error_status == 1)
          {
            if (yymsg != yymsgbuf)
              YYSTACK_FREE (yymsg);
            yymsg = YY_CAST (char *, YYSTACK_ALLOC (YY_CAST (YYSIZE_T, yymsg_alloc)));
            if (!yymsg)
              {
                yymsg = yymsgbuf;
                yymsg_alloc = sizeof yymsgbuf;
                yysyntax_error_status = 2;
              }
            else
              {
                yysyntax_error_status = YYSYNTAX_ERROR;
                yymsgp = yymsg;
              }
          }
        yyerror (yymsgp);
        if (yysyntax_error_status == 2)
          goto yyexhaustedlab;
      }
# undef YYSYNTAX_ERROR
#endif
    }



  if (yyerrstatus == 3)
    {
      /* If just tried and failed to reuse lookahead token after an
         error, discard it.  */

      if (yychar <= YYEOF)
        {
          /* Return failure if at end of input.  */
          if (yychar == YYEOF)
            YYABORT;
        }
      else
        {
          yydestruct ("Error: discarding",
                      yytoken, &yylval);
          yychar = YYEMPTY;
        }
    }

  /* Else will try to reuse lookahead token after shifting the error
     token.  */
  goto yyerrlab1;


/*---------------------------------------------------.
| yyerrorlab -- error raised explicitly by YYERROR.  |
`---------------------------------------------------*/
yyerrorlab:
  /* Pacify compilers when the user code never invokes YYERROR and the
     label yyerrorlab therefore never appears in user code.  */
  if (0)
    YYERROR;

  /* Do not reclaim the symbols of the rule whose action triggered
     this YYERROR.  */
  YYPOPSTACK (yylen);
  yylen = 0;
  YY_STACK_PRINT (yyss, yyssp);
  yystate = *yyssp;
  goto yyerrlab1;


/*-------------------------------------------------------------.
| yyerrlab1 -- common code for both syntax error and YYERROR.  |
`-------------------------------------------------------------*/
yyerrlab1:
  yyerrstatus = 3;      /* Each real token shifted decrements this.  */

  for (;;)
    {
      yyn = yypact[yystate];
      if (!yypact_value_is_default (yyn))
        {
          yyn += YYTERROR;
          if (0 <= yyn && yyn <= YYLAST && yycheck[yyn] == YYTERROR)
            {
              yyn = yytable[yyn];
              if (0 < yyn)
                break;
            }
        }

      /* Pop the current state because it cannot handle the error token.  */
      if (yyssp == yyss)
        YYABORT;


      yydestruct ("Error: popping",
                  yystos[yystate], yyvsp);
      YYPOPSTACK (1);
      yystate = *yyssp;
      YY_STACK_PRINT (yyss, yyssp);
    }

  YY_IGNORE_MAYBE_UNINITIALIZED_BEGIN
  *++yyvsp = yylval;
  YY_IGNORE_MAYBE_UNINITIALIZED_END


  /* Shift the error token.  */
  YY_SYMBOL_PRINT ("Shifting", yystos[yyn], yyvsp, yylsp);

  yystate = yyn;
  goto yynewstate;


/*-------------------------------------.
| yyacceptlab -- YYACCEPT comes here.  |
`-------------------------------------*/
yyacceptlab:
  yyresult = 0;
  goto yyreturn;


/*-----------------------------------.
| yyabortlab -- YYABORT comes here.  |
`-----------------------------------*/
yyabortlab:
  yyresult = 1;
  goto yyreturn;


#if !defined yyoverflow || YYERROR_VERBOSE
/*-------------------------------------------------.
| yyexhaustedlab -- memory exhaustion comes here.  |
`-------------------------------------------------*/
yyexhaustedlab:
  yyerror (YY_("memory exhausted"));
  yyresult = 2;
  /* Fall through.  */
#endif


/*-----------------------------------------------------.
| yyreturn -- parsing is finished, return the result.  |
`-----------------------------------------------------*/
yyreturn:
  if (yychar != YYEMPTY)
    {
      /* Make sure we have latest lookahead translation.  See comments at
         user semantic actions for why this is necessary.  */
      yytoken = YYTRANSLATE (yychar);
      yydestruct ("Cleanup: discarding lookahead",
                  yytoken, &yylval);
    }
  /* Do not reclaim the symbols of the rule whose action triggered
     this YYABORT or YYACCEPT.  */
  YYPOPSTACK (yylen);
  YY_STACK_PRINT (yyss, yyssp);
  while (yyssp != yyss)
    {
      yydestruct ("Cleanup: popping",
                  yystos[+*yyssp], yyvsp);
      YYPOPSTACK (1);
    }
#ifndef yyoverflow
  if (yyss != yyssa)
    YYSTACK_FREE (yyss);
#endif
#if YYERROR_VERBOSE
  if (yymsg != yymsgbuf)
    YYSTACK_FREE (yymsg);
#endif
  return yyresult;
}
#line 1434 "task1.y"


int yyerror(char const *s)
{
	printf("yyerror %s at line no %d\n",s,yylineno);exit(0);
}

int main(void)
{
	FILE *fp;
	fp=fopen("input","r");
	yyin=fp;
	target=fopen("task2.xsm","w");
	if(target==NULL)
	{
		printf("Can not be written to file\n");
		exit(0);
	}
	fprintf(target, "%d\n%d\n%d\n%d\n%d\n%d\n%d\n%d\n",0,2056,0,0,0,0,0,0);
	fprintf(target, "BRKP\n");
	//exit(0);
	yyparse();
	fclose(target);
	
	return 0;
}
