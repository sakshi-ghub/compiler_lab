#include<fstream>
#include<iostream>
#include<bits/stdc++.h>
using namespace std;
typedef long long int ll;

int main()
{
	ll label = 2056, flag = 0;
	map < string, ll > hm ;
	ofstream outfile,outfile1;
	ifstream infile;

	infile.open("task2.xsm");

	string data;
	while(getline(infile,data))
	{

		ll size = data.size();

		if(data != "0" && data != "2056")
			flag = 1;


		if((data[0] == 'L' && data[size - 1] == ':') || (data[0] == 'F' && data[size -1] ==':') || (data[0]=='M' && data[1]=='A' && data[2]=='I' && data[3]=='N' && data[4]==':'))
		{
			if(hm[data] == 0)
				hm[data] = label;
		}

		else if(flag == 1)
			label += 2;
	}

	infile.close();
	outfile.open("translated.xsm");
	infile.open("task2.xsm");

	ll x = 2056;
	flag = 0;
	while(getline(infile,data))
	{
		string newline = "\n",save = "",data1 = "";
		ll size = data.size(), i = 0;

		if(data != "0" && data != "2056")
			flag = 1;

		if((data[0] == 'L' && data[size - 1] == ':') || (data[0] == 'F' && data[size -1] ==':') || (data[0]=='M' && data[1]=='A' && data[2]=='I' && data[3]=='N' && data[4]==':'))
		{
				continue;
		}
		else if(data[0] == 'J' && data[1] == 'M' && data[2] == 'P')
		{
			i = 4;
			data1 += "JMP ";
			while(data[i] != '\0')
			{
				save += data[i];
				i++;
			}
                        
                        save += ':';
                        save = to_string(hm[save]);
                        data1 += save;
                        outfile << data1 << newline ;
                        outfile1 << x << " " << data1 << newline ;':';
		}
		else if(data[0] == 'C' && data[1] == 'A' && data[2] == 'L' && data[3]=='L' && (data[5]=='F' || data[5]=='M'))
                {
                        i = 5;
                        data1 += "CALL ";
                        while(data[i] != '\0')
                        {
                                save += data[i];
                                i++;
                        }
                        save += ':';
                        save = to_string(hm[save]);
                        data1 += save;
                        outfile << data1 << newline ;
                        outfile1 << x << " " << data1 << newline ;
                }

		else if(data[0] == 'J' && data[1] == 'Z')
		{
			i = 0;
			while(data[i + 1] != 'L')
			{
				data1 += data[i];
				i++;
			}
			i++;
			while(data[i] != '\0')
			{
				save += data[i];
				i++;
			}
			save += ':';
			save = to_string(hm[save]);
			data1 += save;
			outfile << data1 << newline ;
			outfile1 << x << " " << data1 << newline ;
		}
		else if(data[0] == 'J' && data[1] == 'N' && data[2]=='Z')
                {
                        i = 0;
                        while(data[i + 1] != 'L')
                        {
                                data1 += data[i];
                                i++;
                        }
                        i++;
                        while(data[i] != '\0')
                        {
                                save += data[i];
                                i++;
                        }
                        save += ':';
                        save = to_string(hm[save]);
                        data1 += save;
                        outfile << data1 << newline ;
                        outfile1 << x << " " << data1 << newline ;
                }
		else
		{
			int check=0;
			for(i=size;i>=0;i--)
			{
				if(data[i]=='F')
				{
					check=1;break;
				}
			}
			if(check==0)
			{
				outfile << data << newline ;
				outfile1 << x << " " << data << newline ;
			}
			else if(check==1)
			{
				i=0;
				while(data[i+1]!='F')
				{
					data1 += data[i];
					i++;
				}
				i++;
				while(data[i] != '\0')
				{
					save += data[i];
					i++;
				}
				save += ':';
				save = to_string(hm[save]);
				data1 += save;
				outfile << data1 << newline;
				outfile1 << x << " " << data1 << newline ;

			}
		}

		if(flag)
			x += 2;
	}

}
