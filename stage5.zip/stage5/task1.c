int address=4096;

struct Gsymbol *GLookup(struct Gsymbol *GTable,char *name)
{
	if(GTable==NULL)
		return NULL;
	while(GTable!=NULL)
	{
		if(strcmp(GTable->name, name)==0)
			return GTable;
		GTable=GTable->next;
	}
	return NULL;
}


void GInstall(struct Gsymbol **GTable,char *name, int type, int size,int binding, struct Paramstruct *paramlist)
{
	struct Gsymbol *temp=(struct Gsymbol*)malloc(sizeof(struct Gsymbol));
	temp->name=(char*)malloc(sizeof(char)*100);
	strcpy(temp->name,name);
	temp->type=type;
	temp->size=size;
	if(binding!=0)
		temp->binding=binding;
	else
		temp->binding=0;
	temp->paramlist=paramlist;
	temp->next=(*GTable);
	(*GTable) =temp;
}

struct Lsymbol *Lookup(struct Lsymbol *LTable,char *name)
{
	if(LTable==NULL)
		return NULL;
	while(LTable!=NULL)
	{
		if(strcmp(LTable->name, name)==0)
			return LTable;
		LTable=LTable->next;
	}
	return NULL;
}
struct Paramstruct *PLookup(struct Paramstruct *pml,char *name)
{
	if(pml==NULL)
		return NULL;
	while(pml!=NULL)
	{
		if(strcmp(pml->name, name)==0)
			return pml;
		pml=pml->next;
	}
	return NULL;
}

void LInstall(struct Lsymbol **LTable,char *name, int type,int binding)
{
	struct Lsymbol *temp=(struct Lsymbol*)malloc(sizeof(struct Lsymbol));
	temp->name=(char*)malloc(sizeof(char)*100);
	strcpy(temp->name,name);
	temp->type=type;
	temp->binding=4096+binding;
	temp->next=(*LTable);
	(*LTable) =temp;
}

int check_func_arg(struct Paramstruct *head1, struct Paramstruct *head2)
{
    struct Paramstruct *curr1 = head1;
    struct Paramstruct *curr2 = head2;

    while(curr1 && curr2)
    {
    	//printf("** %d %d **\n",curr1->type,curr2->type); 
        if(curr1->type != curr2->type)
            return 0;
		
        curr1 = curr1->next;
        curr2 = curr2->next;
    }
	
    if(!curr1 && !curr2)
        return 1;
    else
        {/*printf("check1");*/return 0;}
}

int check_func_param(struct Paramstruct *head1, struct Paramstruct *head2)
{
    struct Paramstruct *curr1 = head1;
    struct Paramstruct *curr2 = head2;

    while(curr1 && curr2)
    {
    	//printf("** %d %d **\n",curr1->type,curr2->type); 
        if(curr1->type != curr2->type)
            return 0;
	//printf("** %s %s **\n",curr1->name,curr2->name);
	if(strcmp(curr1->name,curr2->name))
		return 0;
		
        curr1 = curr1->next;
        curr2 = curr2->next;
    }
	
    if(!curr1 && !curr2)
        return 1;
    else
        {/*printf("check1");*/return 0;}
}
struct ASTNode* createTree(int val,int type,int nodetype,int expr_type,struct ASTNode *l,struct ASTNode *r,struct ASTNode *t)
{
	if(type==2)
	{
		if (nodetype==1)
		{
			if(r->type!=1 && r->type!=7)
			{
				yyerror("Type mismatch1");
				exit(0);
			}
		}
		else if (nodetype==2)
		{
			if(r->expr_type!=1 && r->expr_type!=2)
			{	
				yyerror("Type mismatch2");
				exit(0);
			}
		}
		else if(nodetype==4|| nodetype==13 || nodetype==14)
		{
			//printf("--%d %d--",l->expr_type,r->expr_type);
			if(l->expr_type!=r->expr_type)
			{
				yyerror("Type mismatch3");
				//exit(0);
			}
		}
		else if(nodetype==5 || nodetype==6 || nodetype==7 || nodetype==8 || nodetype==9 || nodetype==10 || nodetype==11 || nodetype==12 || nodetype==19 )
		{
			if(l->expr_type!=1 || r->expr_type!=1)
			{
				//printf("--%d %d %d--",l->expr_type,r->expr_type,nodetype);
				yyerror("Type mismatch4");
				//exit(0);
			}
		}
		else if(nodetype==15 || nodetype==16)
		{
			if(l->expr_type!=0)
			{
				yyerror("Type mismatch5");
				exit(0);
			}
		}
		else if(nodetype==17 || nodetype==18)
		{
			if(l->expr_type!=0 || l->expr_type!=0)
			{
				//printf("--%d %d--",l->expr_type,r->expr_type);
				yyerror("Type mismatch6");
				//exit(0);
			}
		}
	}

    	struct ASTNode *temp;
    	temp = (struct ASTNode*)malloc(sizeof(struct ASTNode));
    	temp->val=val;
    	temp->type=type;
    	temp->varname = NULL;
    	temp->nodetype=nodetype;
    	temp->left = l;
    	temp->right = r;
    	temp->expr_type=expr_type;
    	temp->third=t;
    	return temp;
}

struct ASTNode* createID(int val,int type, char *varname,int nodetype,int expr_type,struct Gsymbol *Gentry,struct ASTNode *l,struct ASTNode *r,struct ASTNode *t,struct Paramstruct *paramlist)
{
    struct ASTNode *temp;
    temp = (struct ASTNode*)malloc(sizeof(struct ASTNode));
    temp->val=val;
    temp->type=type;
    temp->varname = (char*)malloc(sizeof(char)*100);
    strcpy(temp->varname,varname);
    temp->nodetype=nodetype;
    temp->left = l;
    temp->right = r;
    temp->expr_type=expr_type;
    temp->third=t;
    temp->Gentry=Gentry;
    temp->paramlist=paramlist;
    return temp;
}

