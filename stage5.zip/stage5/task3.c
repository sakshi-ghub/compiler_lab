int LABEL = -1;
struct Gsymbol *GTable=NULL;
struct Gsymbol *temp,*gtemp;
struct Lsymbol *LTable=NULL,*temp_table=NULL,*temp1,*ltemp; 
struct Paramstruct *pml,*temp_list;
struct Gsymbol *temp;
int break_label,continue_label;
int FLABEL = -1;
int psize = 0;
int address=4096;

char * Keywords[21] = {"main", "decl", "enddecl", "begin", "end", "do", "while", "repeat", "until", "break", "continue", "breakpoint", "if", "else", "then", "endif", "endwhile", "int", "str","read", "write"};

int check_Reserved(char * Keywords[21], char * variable)
{
	int i;
	for(i=0;i<21;i++)
	{
		if(strcmp(Keywords[i],variable)==0)
			return 1;
	}
	return 0;
}
		
int getLabel()
{
    int a = ++LABEL;
    return a;
}

struct Gsymbol *GLookup(struct Gsymbol *GTable,char *name)
{
	if(GTable==NULL)
		return NULL;
	while(GTable!=NULL)
	{
		if(strcmp(GTable->name, name)==0)
			return GTable;
		GTable=GTable->next;
	}
	return NULL;
}


void GInstall(struct Gsymbol **GTable,char *name, int type, int size,int binding, struct Paramstruct *paramlist,int flabel)
{
	struct Gsymbol *temp=(struct Gsymbol*)malloc(sizeof(struct Gsymbol));
	temp->name=(char*)malloc(sizeof(char)*100);
	strcpy(temp->name,name);
	temp->type=type;
	temp->size=size;
	if(binding!=0)
		temp->binding=binding;
	else
		temp->binding=0;
	temp->paramlist=paramlist;
	temp->flabel=flabel;
	temp->next=(*GTable);
	(*GTable) =temp;
}

struct Lsymbol *Lookup(struct Lsymbol *LTable,char *name)
{
	if(LTable==NULL)
		return NULL;
	while(LTable!=NULL)
	{
		if(strcmp(LTable->name, name)==0)
			return LTable;
		LTable=LTable->next;
	}
	return NULL;
}
struct Paramstruct *PLookup(struct Paramstruct *pml,char *name)
{
	if(pml==NULL)
		return NULL;
	while(pml!=NULL)
	{
		if(strcmp(pml->name, name)==0)
			return pml;
		pml=pml->next;
	}
	return NULL;
}

void LInstall(struct Lsymbol **LTable,char *name, int type,int binding)
{
	struct Lsymbol *temp=(struct Lsymbol*)malloc(sizeof(struct Lsymbol));
	temp->name=(char*)malloc(sizeof(char)*100);
	strcpy(temp->name,name);
	temp->type=type;
	temp->binding=binding;
	temp->next=(*LTable);
	(*LTable) =temp;
}

int check_func_param(struct Paramstruct *head1, struct Paramstruct *head2)
{
    struct Paramstruct *curr1 = head1;
    struct Paramstruct *curr2 = head2;

    while(curr1 && curr2)
    {
    	//printf("** %d %d **\n",curr1->type,curr2->type); 
        if(curr1->type != curr2->type)
            return 0;
	//printf("** %s %s **\n",curr1->name,curr2->name);
	if(strcmp(curr1->name,curr2->name))
		return 0;
		
        curr1 = curr1->next;
        curr2 = curr2->next;
    }
	
    if(!curr1 && !curr2)
        return 1;
    else
        {/*printf("check1");*/return 0;}
}

int check_func_arg(struct Paramstruct *head1, struct Paramstruct *head2)
{
    struct Paramstruct *curr1 = head1;
    struct Paramstruct *curr2 = head2;

    while(curr1 && curr2)
    {
    	//printf("** %d %d **\n",curr1->type,curr2->type); 
        if(curr1->type != curr2->type)
            return 0;
		
        curr1 = curr1->next;
        curr2 = curr2->next;
    }
	
    if(!curr1 && !curr2)
        return 1;
    else
        {printf("check1-1");return 0;}
}

struct ASTNode* createTree(int val,int type,int nodetype,int expr_type,struct ASTNode *l,struct ASTNode *r,struct ASTNode *t)
{
	if(type==2)
	{
		if (nodetype==1)
		{
			if(r->type!=1 && r->type!=7)
			{
				yyerror("Type mismatch1");
				exit(0);
			}
		}
		else if (nodetype==2)
		{
			if(r->expr_type!=1 && r->expr_type!=2)
			{	
				yyerror("Type mismatch2");
				exit(0);
			}
		}
		else if(nodetype==4|| nodetype==13 || nodetype==14)
		{
			//printf("--%d %d--",l->expr_type,r->expr_type);
			if(l->expr_type!=r->expr_type)
			{
				yyerror("Type mismatch3");
				//exit(0);
			}
		}
		else if(nodetype==5 || nodetype==6 || nodetype==7 || nodetype==8 || nodetype==9 || nodetype==10 || nodetype==11 || nodetype==12 || nodetype==19 )
		{
			if(l->expr_type!=1 || r->expr_type!=1)
			{
				//printf("--%d %d %d--",l->expr_type,r->expr_type,nodetype);
				yyerror("Type mismatch4");
				//exit(0);
			}
		}
		else if(nodetype==15 || nodetype==16)
		{
			if(l->expr_type!=0)
			{
				yyerror("Type mismatch5");
				exit(0);
			}
		}
		else if(nodetype==17 || nodetype==18)
		{
			if(l->expr_type!=0 || l->expr_type!=0)
			{
				//printf("--%d %d--",l->expr_type,r->expr_type);
				yyerror("Type mismatch6");
				//exit(0);
			}
		}
	}

    	struct ASTNode *temp;
    	temp = (struct ASTNode*)malloc(sizeof(struct ASTNode));
    	temp->val=val;
    	temp->type=type;
    	temp->varname = NULL;
    	temp->nodetype=nodetype;
    	temp->left = l;
    	temp->right = r;
    	temp->expr_type=expr_type;
    	temp->third=t;
    	return temp;
}

struct ASTNode* createID(int val,int type, char *varname,int nodetype,int expr_type,struct Gsymbol *Gentry,struct ASTNode *l,struct ASTNode *r,struct ASTNode *t,struct Paramstruct *paramlist)
{
    struct ASTNode *temp;
    temp = (struct ASTNode*)malloc(sizeof(struct ASTNode));
    temp->val=val;
    temp->type=type;
    temp->varname = (char*)malloc(sizeof(char)*100);
    strcpy(temp->varname,varname);
    temp->nodetype=nodetype;
    temp->left = l;
    temp->right = r;
    temp->expr_type=expr_type;
    temp->third=t;
    temp->Gentry=Gentry;
    temp->paramlist=paramlist;
    return temp;
}
int reg[20];
//Get a register
int getReg()
{
    for(int i = 0;i < 20;i++)
    {
        if(reg[i] == 0)
        {
            reg[i] = 1;
            return i;
        }
    }

    printf("Out of Registers\n");
    return -1;
}

//Free a register
int freeReg()
{
    int max = -1;
    for (int i = 0; i < 20; i++)
    {
        if (reg[i] == 1 && i > max)
            max = i;
    }
    if (max != -1)
    {
        reg[max] = 0;
        return max;
    }
    printf("Invalid Register\n");
    exit(1);
}

void read_codeGen(struct ASTNode*t, FILE *target)
{
	int var_Addr;
        int idx = getReg();
        if (idx == -1)
            exit(1);
        if(t->right->type == 1)
        {
            var_Addr = get_Address(target,t->right);
            fprintf(target, "MOV R%d, R%d\n", idx, var_Addr);
            var_Addr = freeReg(); 
        }
        else if(t->right->type == 7)
        {
            var_Addr = get_Address(target,t->right);
            fprintf(target, "MOV R%d,R%d\n", idx ,var_Addr);
            var_Addr = freeReg();   
        }
        
        int temp = getReg();
        if (temp == -1)
            exit(1);
     //   fprintf(target, "MOV SP, address\n");
        fprintf(target, "MOV R%d,\"Read\"\n", temp);
        fprintf(target, "PUSH R%d\n", temp);
        fprintf(target, "MOV R%d,-1\n", temp);
        fprintf(target, "PUSH R%d\n", temp);
        fprintf(target, "PUSH R%d\n", idx);
        fprintf(target, "PUSH R%d\n", temp);
        fprintf(target, "PUSH R%d\n", temp);
        fprintf(target, "CALL 128\n");
        fprintf(target, "POP R%d\n", temp);
        fprintf(target, "POP R%d\n", temp);
        fprintf(target, "POP R%d\n", temp);
        fprintf(target, "POP R%d\n", temp);
        fprintf(target, "POP R%d\n", temp);
        temp = freeReg();
        if (temp == -1)
            exit(1);
        idx = freeReg();
        if (idx == -1)
            exit(1);  
        //var_Addr = freeReg();
        //if (var_Addr == -1)
          //  exit(1); 
    
}

void write_codeGen(struct ASTNode*t, FILE *target)
{
        int idx;
    	idx = expression_codeGen(t->right, target);
        int temp = getReg();
        if (temp == -1)
            exit(1);
     //   fprintf(target, "MOV SP, address\n");
        fprintf(target, "MOV R%d,\"Write\"\n", temp);
        fprintf(target, "PUSH R%d\n", temp);
        fprintf(target, "MOV R%d,-2\n", temp);
        fprintf(target, "PUSH R%d\n", temp);
        fprintf(target, "PUSH R%d\n", idx);
        fprintf(target, "PUSH R%d\n", temp);
        fprintf(target, "PUSH R%d\n", temp);
        fprintf(target, "CALL 0\n");
        fprintf(target, "POP R%d\n", temp);
        fprintf(target, "POP R%d\n", temp);
        fprintf(target, "POP R%d\n", temp);
        fprintf(target, "POP R%d\n", temp);
        fprintf(target, "POP R%d\n", temp);
        idx = freeReg();
        if (idx == -1)
            exit(1);
        idx = freeReg();
        if (idx == -1)
            exit(1);
}

int get_Address(FILE *target,struct ASTNode * t)
{
    int tmp;
    struct Gsymbol *tmp2 ;
    
    if(t->type == 7)
    {
        tmp2 = GLookup(GTable,t->varname);

        tmp = getReg();
        fprintf(target,"MOV R%d, %d\n",tmp,tmp2->binding);
        int tmp1 = expression_codeGen(t->left,target);
        fprintf(target,"ADD R%d, R%d\n",tmp,tmp1);
        tmp1 = freeReg();
        return tmp;
    }
    else
    {
        temp1 = Lookup(LTable,t->varname);
        if(temp1)
        {
        	int reg_i = getReg();
        	fprintf(target, "MOV R%d, BP\n", reg_i);
            	fprintf(target, "ADD R%d, %d\n", reg_i, temp1->binding);
            	return reg_i;
        }
        else
        {
        	tmp2 = GLookup(GTable,t->varname);
        	int reg_i = getReg();
            if(tmp2 != NULL){
          //  printf("%d",tmp2->binding);
        	fprintf(target, "MOV R%d, %d\n",reg_i, tmp2->binding);}
            else
                printf("Variable Not Declared\n");
            return reg_i;
       }
    }
}
int get_func_label()
{
    int a = ++FLABEL;
    return a;
}


void push_arg_in_stack(struct Paramstruct * root, FILE *target)
{
    if(root)
    {
        push_arg_in_stack(root->next, target);
        int reg_i = expression_codeGen(root->val, target);
        fprintf(target, "PUSH R%d\n",reg_i);
        reg_i = freeReg();
        psize++;
    }
    return ;
}

int funct_codeGen(struct ASTNode *t, FILE *target)
{	
	temp=GLookup(GTable, t->varname);
	int count=0,size,i;
	psize=1;
	
	int reg=getReg();
	for(i=0;i<reg;i++)
	{
		count++;
		fprintf(target, "PUSH R%d\n", i);
		//freeReg();
	}
	reg=freeReg();
	push_arg_in_stack(t->paramlist, target);
	
    	int reg_i = getReg();
    	fprintf(target, "PUSH R%d\n",reg_i); //extra space for return val
    	reg_i = freeReg(); 
    	
    	fprintf(target, "CALL F%d\n",temp->flabel);
    
   /* f(0, tmp_cnt)
        getReg(); */

    	size = psize; //Parameter size and an additional reg for reurn value

    	reg_i= getReg(); //Register to store return value
    	int reg_i2 = getReg(); //Register to pop initial saved registers
	
	for(i=0;i<size;i++)
	{
		if(i == 0)
            		fprintf(target, "POP R%d\n", reg_i);
        	else
            		fprintf(target, "POP R%d\n", reg_i2);
       }
       
   	reg_i2 = freeReg(); //Not frees reg_i as it contains return value;

   	for(int i = count - 1;i >= 0;i--)
   	{
        	fprintf(target, "POP R%d\n",i); //Popping out initial pushed registers
   	}
   	return reg_i; //Register which contain Return Value;
 
}
		

int expression_codeGen(struct ASTNode *t,FILE *target)
{
    int idx;
    if(t->type == 0)
    {
        idx = getReg();
        if(idx == -1)
            exit(1);
        fprintf(target,"MOV R%d, %d\n",idx, t->val);
        return idx;
    }
    else if(t->type == 1  || t->type==7)
    {
        idx = getReg();
        int var_Addr = get_Address(target,t);
        if(idx == -1)
            exit(1);

        fprintf(target,"MOV R%d, [R%d]\n",idx, var_Addr);
        var_Addr = freeReg();
        return idx;
    }
    else if(t->type == 5)
    {
        idx = getReg();
        if(idx == -1)
            exit(1);
	fprintf(target,"MOV R%d,\"%s\"\n",idx,t->varname);
        return idx;
    }
    else if(t->type==6)
    {
    	return funct_codeGen(t,target);
    }
    else if(t->left || t->right)
    {

        int left, right;
        if(t->left)
            left = expression_codeGen(t->left, target);
        if(t->right)
            right = expression_codeGen(t->right, target);

        switch(t->nodetype)
        {
            case 5:
                    fprintf(target,"ADD R%d, R%d\n",left, right);
                    idx = freeReg();

                    if(idx == -1)
                        exit(1);
                    return left;
                    break;
            case 6:
                    fprintf(target,"SUB R%d, R%d\n",left, right);
                    idx = freeReg();

                    if(idx == -1)
                        exit(1);
                    return left;
                    break;
            case 7:
                    fprintf(target,"MUL R%d, R%d\n",left, right);
                    idx = freeReg();

                    if(idx == -1)
                        exit(1);
                    return left;
                    break;
            case 8:
                    fprintf(target,"DIV R%d, R%d\n",left, right);
                    idx = freeReg();

                    if(idx == -1)
                        exit(1);
                    return left;
                    break;
            case 19:
                    fprintf(target,"MOD R%d, R%d\n",left, right);
                    idx = freeReg();

                    if(idx == -1)
                        exit(1);
                    return left;
                    break;
        }

    }

}
void assg_codeGen(struct ASTNode*t, FILE *target)
{
    	int idx,var_Addr;
        idx = expression_codeGen(t->right, target);
        if(t->left->type == 1 || t->left->type == 7)
        {
            var_Addr = get_Address(target, t->left);
            fprintf(target,"MOV [R%d], R%d\n",var_Addr,idx);
            var_Addr = freeReg();
        }
        
        idx = freeReg();
        if(idx == -1){
            exit(1);
        }
}
int bool_codeGen(struct ASTNode *t, FILE *target)
{
    int a, b,idx,label1,label2;
    if(t->nodetype==17 || t->nodetype==18)
    {
    	a=bool_codeGen(t->left,target);
    	b=bool_codeGen(t->left,target);
    	
    }
    else
    {
    	a = expression_codeGen(t->left,target);
    	b = expression_codeGen(t->right,target);
    }

    switch(t->nodetype)
    {
        case 9:
            fprintf(target,"LT R%d,R%d\n",a,b);
            idx = freeReg();
	     if(idx == -1)
                   exit(1);
            break;
        case 10:
            fprintf(target,"GT R%d,R%d\n",a,b);
            idx = freeReg();
	     if(idx == -1)
                   exit(1);
            break;
        case 11:
            fprintf(target,"LE R%d,R%d\n",a,b);
            idx = freeReg();
	     if(idx == -1)
                   exit(1);
            break;
        case 12:
            fprintf(target,"GE R%d,R%d\n",a,b);
            idx = freeReg();
	     if(idx == -1)
                   exit(1);
            break;
        case 14:
            fprintf(target,"EQ R%d,R%d\n",a,b);
            idx = freeReg();
	     if(idx == -1)
                   exit(1);
            break;
        case 13:
            fprintf(target,"NE R%d,R%d\n",a,b);
            idx = freeReg();
	     if(idx == -1)
                   exit(1);
            break;
        case 17:
                label1=getLabel();
        	label2=getLabel();
            fprintf(target,"JNZ R%d, L%d\n",a,label1);
            fprintf(target,"JNZ R%d, L%d\n",b,label1);
            fprintf(target,"JMP L%d\n",label2);
            fprintf(target, "L%d:\n",label1);
            fprintf(target,"MOV R%d, 1\n",a);
            fprintf(target, "L%d:\n",label2);
            
            idx = freeReg();

            if(idx == -1)
                 exit(1);
            break;
        case 18:
            label1=getLabel();
            label2=getLabel();
        
            fprintf(target,"JZ R%d, L%d\n",a,label1);
            fprintf(target,"JZ R%d, L%d\n",b,label1);
            fprintf(target,"JMP L%d\n",label2);
            fprintf(target, "L%d:\n",label1);
            fprintf(target,"MOV R%d, 0\n",a);
            fprintf(target, "L%d:\n",label2);
            
            idx = freeReg();
            if(idx == -1)
                exit(1);
             break;
    }
    
    return a;
}

void while_codeGen(struct ASTNode *t, FILE *target)
{
    if(t->left)
    {
        int label1 = getLabel();
        int label2 = getLabel();
        int idx;
        fprintf(target,"L%d:\n",label1);
        break_label=label2;
        continue_label=label1;
        if(t->left)
            idx=bool_codeGen(t->left,target);
	fprintf(target,"JZ R%d, L%d\n",idx,label2);
    	int tmp = freeReg();
        if(t->right)
            codeGen(t->right,target,label2,label1);
            
    	
    	
        fprintf(target, "JMP L%d\n",label1);
        fprintf(target, "L%d:\n",label2);
        return ;
    }
    printf("Invalid WHILE\n");
    exit(0);
}
void if_else_codeGen(struct ASTNode * t, FILE *target,int break_label, int continue_label)
{
	int label1 = getLabel();
        int idx,label2;
	idx=bool_codeGen(t->left,target);
	if(t->third)
	{
		label2 = getLabel();
		fprintf(target, "JZ R%d, L%d\n",idx,label2);
	}
	else
		fprintf(target, "JZ R%d, L%d\n",idx,label1);		
	codeGen(t->right,target,break_label,continue_label);
	fprintf(target, "JMP L%d\n",label1);
			
	if(t->third)
	{
		fprintf(target,"L%d:\n",label2);
		codeGen(t->third,target,break_label,continue_label);
	}
	fprintf(target, "JMP L%d\n",label1);
	fprintf(target,"L%d:\n",label1);
		
}
void return_codeGen(FILE *target, struct ASTNode *t)
{
    int tmp1 = getReg();
    int tmp2 = expression_codeGen(t, target);
    fprintf(target, "MOV R%d, BP\nSUB R%d, 2\nMOV [R%d], R%d\n", tmp1, tmp1,tmp1, tmp2);
    tmp2 = freeReg();
    tmp1 = freeReg();
    fprintf(target, "MOV BP, [BP]\nPOP BP\n");
    fprintf(target,"RET\n");
    return ;
}
void codeGen(struct ASTNode *t, FILE *target, int break_label, int continue_label)
{
	if(t)
	{
		if(t->type==2)
		{
			if(t->nodetype==1)
			{
				read_codeGen(t,target);
				return;
			}
			if(t->nodetype==2)
			{
				write_codeGen(t,target);
				return;
			}
			if(t->nodetype==4)
			{
				assg_codeGen(t,target);
				return;
			}
			if(t->nodetype==15)
			{
				if_else_codeGen(t,target,break_label,continue_label);
				return;
			}
			if(t->nodetype==16)
			{
				while_codeGen(t,target);
				return;
			}
		}
		else if(t->type==3)
		{
			if(break_label != -1)
                	fprintf(target,"JMP L%d\n",break_label);
            		return ; 
            	}
            	else if(t->type == 4)
        	{
            		if(continue_label != -1)
               	fprintf(target,"JMP L%d\n",continue_label);
           		return ;
        	}
        	else if(t->type==6)
        	{
        		funct_codeGen(t,target);
        		return;
        	}
        	codeGen(t->left,target,break_label,continue_label);
        	codeGen(t->right,target,break_label,continue_label);
        }
        return;
}	
