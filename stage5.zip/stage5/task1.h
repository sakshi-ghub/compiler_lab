typedef struct Gsymbol{
	char *name; //name of the variable or function
	int type; //type of the variable: (Integer /String)
	int size; //size of an array 
	int binding; //static binding of global variables
	struct Paramstruct *paramlist; //pointer to the head of the formal list
	int flabel; // a label for identifying the starting address of a function's code
	struct Gsymbol *next; //points to the next Global Symbol Table
}Gsymbol;

typedef struct Lsymbol{
	char *name; // name of the variable
	int type;  //type of the variable: (Integer /String)
	int binding; //local binding of the variable
	struct Lsymbol *next; //points to the next Local Symbol Table entry
}Lsymbol;

typedef struct Paramstruct{
	char *name; //name of the parameter
	int type; //type of the parameter
	struct Paramstruct *next; //points to the next paramter list entry
}Paramstruct;

// nodetype 1-read
// 	     2-write
// 	     3-connector
// 	     4- '='
// 	     5- '+'
// 	     6- '-'
// 	     7- '*'
// 	     8- '/'
//	     9- LT
//	     10-GT
//	     11- LE
//           12- GE
//	      13- NE
//		14- EQ
//		15- IF_ELSE_THEN
//		16- WHILE
//		17-OR
//		18-AND
//		19-MODULUS
//type  0- num
//	1-ID
//	2-nonleaf
//	3-break
//	4-continue
//	5-string
//	6-FUNCTION
//	7-array element

//expr_type 0-boolean
//	     1-arithmetic
//	      2-string
//           5-typeless


typedef struct ASTNode{
 int val; //value of a number for NUM nodes
 int type; //type of variable
 char *varname; //name of a variable for ID nodes
 int nodetype; //information about non-leaf nodes -read/write/connector/+/- etc
 int expr_type; //iformation about type of expression ex- arithmetic, boolean, typeless
 struct ASTNode *left,*right,*third; //left and right branches
 struct Gsymbol *Gentry; //pointer to GST entry for global variables and functions
 struct Lsymbol *Lentry; //pointer to the function's LST for local variables and arguments
 struct Paramstruct *paramlist; //pointer to the parameter list given as argument to a function call
}ASTNode;

void GInstall(struct Gsymbol **GTable,char *name, int type, int size,int binding,struct Paramstruct *paramlist);
struct Gsymbol *GLookup(struct Gsymbol *Table,char *name);
struct ASTNode* createTree(int val,int type,int nodetype,int expr_type,struct ASTNode *l,struct ASTNode *r,struct ASTNode *t);
struct ASTNode* createID(int val,int type, char *varname,int nodetype,int expr_type,struct Gsymbol *Gentry,struct ASTNode *l,struct ASTNode *r,struct ASTNode *t,struct Paramstruct *paramlist);
int check_func_param(struct Paramstruct *head1, struct Paramstruct *head2);
int check_func_arg(struct Paramstruct *head1, struct Paramstruct *head2);
