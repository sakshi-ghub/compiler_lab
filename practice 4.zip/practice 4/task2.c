struct tnode* createTree(int val,int type, char c,int nodetype,int expr_type,struct tnode *l,struct tnode *r,struct tnode *t)
{
	if(type==2)
	{
		if (nodetype==2)
		{
			if(r->expr_type!=1 && r->expr_type!=2)
			{
				yyerror("Type mismatch");
				exit(0);
			}
		}
		else if (nodetype==1)
		{
			if(r->type!=1 && r->type!=7)
			{
				yyerror("Type mismatch");
				exit(0);
			}
		}
		else if(nodetype==4|| nodetype==13 || nodetype==14)
		{
			if(l->expr_type!=r->expr_type)
			{
				yyerror("Type mismatch");
				exit(0);
			}
		}
		else if(nodetype==5 || nodetype==6 || nodetype==7 || nodetype==8 ||nodetype==17|| nodetype==9 || nodetype==10 || nodetype==11 || nodetype==12 )
		{
			if(l->expr_type!=1 || r->expr_type!=1)
			{
				yyerror("Type mismatch");
				exit(0);
			}
		}
		else if(nodetype==15 || nodetype==16)
		{
			if(l->expr_type!=0)
			{
				yyerror("Type mismatch");
				exit(0);
			}
		}
	}

    	struct tnode *temp;
    	temp = (struct tnode*)malloc(sizeof(struct tnode));
    	temp->val=val;
    	temp->type=type;
    	temp->varname = NULL;
    	temp->nodetype=nodetype;
    	temp->left = l;
    	temp->right = r;
    	temp->expr_type=expr_type;
    	temp->third=t;
    	return temp;
}

struct tnode* createID(int val,int type, char *varname,int nodetype,int expr_type,struct Gsymbol *Gentry,struct tnode *l,struct tnode *r,struct tnode *t)
{
    struct tnode *temp;
    temp = (struct tnode*)malloc(sizeof(struct tnode));
    temp->val=val;
    temp->type=type;
    temp->varname = (char*)malloc(sizeof(char)*100);
    strcpy(temp->varname,varname);
    temp->nodetype=nodetype;
    temp->left = l;
    temp->right = r;
    temp->expr_type=expr_type;
    temp->third=t;
    temp->Gentry=Gentry;
    return temp;
}

struct Gsymbol *Lookup(struct Gsymbol *Table,char *name)
{
	if(Table==NULL)
		return NULL;
	while(Table!=NULL)
	{
		if(strcmp(Table->name, name)==0)
			return Table;
		Table=Table->next;
	}
	return NULL;
}


void Install(struct Gsymbol **Table,char *name, int type, int size,int binding)
{
	struct Gsymbol *temp=(struct Gsymbol*)malloc(sizeof(struct Gsymbol));
	temp->name=(char*)malloc(sizeof(char)*100);
	strcpy(temp->name,name);
	temp->type=type;
	temp->size=size;
	temp->binding=4096+binding;
	temp->next=(*Table);
	(*Table) =temp;
}


int codeGen(struct tnode *t,FILE *target){
	int i,j,num,k2,k1,k;
	static int k3=-1;
	if(t==NULL)
		return 0;
	static int regNo=6;
	static int labelno=0;
	if(regNo>19)
	{
		printf("Out of registers\n");
		exit(0);
	}
	if(t->type==0)
	{
		fprintf(target, "MOV R%d, %d\n",regNo++,t->val);
		return (regNo-1);
	}
	else if(t->type==1)
	{
		num=t->Gentry->binding;
		return num;
	}
	else if(t->type==3)
	{
		if(k3!=-1)
			fprintf(target,"JMP L%d\n",k3);
		
	}
	else if(t->type==4)
	{
		if(k3!=-1)
			fprintf(target,"JMP L%d\n",k3-1);
	}
	else if(t->type==5)
	{
		return regNo;	
	}
	else if(t->type==7)
	{
		if(t->left->type==0)
		{
			num=t->Gentry->binding+t->left->val;
			return num;
		}
		else if(t->left->type==1)
		{
			num=t->Gentry->binding;
			return num;
		}
	}		
	else
	{
		if(!(t->nodetype==15 || t->nodetype==16))
		{
			i=codeGen(t->left,target);
			j=codeGen(t->right,target);
		}
		if(t->nodetype==1)
		{
				num=j;
				fprintf(target, "MOV SP, 4300\n");
				fprintf(target, "MOV R1, \"Read\"\n");
        			fprintf(target, "PUSH R1\n");
        			fprintf(target, "MOV R1, -1\n");
        			fprintf(target, "PUSH R1\n");
				fprintf(target, "MOV R1, %d\n",num);
				if(t->right->type==7 && t->right->left->type==1)
				{
					fprintf(target,"MOV R0, [%d]\n",t->right->left->Gentry->binding);
					fprintf(target, "ADD R1, R0\n");
				}
        			fprintf(target, "PUSH R1\n");
				fprintf(target, "PUSH R0\n");
        			fprintf(target, "PUSH R0\n");
        			fprintf(target,"CALL 128\n");
        			fprintf(target, "POP R0\n");
        			fprintf(target, "POP R1\n");
        			fprintf(target, "POP R1\n");
        			fprintf(target, "POP R1\n");
        			fprintf(target, "POP R1\n");
        			return regNo;
			
		}
		else if(t->nodetype==2)
		{
			if(t->right->type==1 || (t->right->type==7 && t->right->left->type==0))
			{
				fprintf(target,"MOV R0, [%d]\n",j);
			}
			else if(t->right->type==0)
			{
				fprintf(target,"MOV R0, R%d\n",j);
			}
			else if(t->right->type==5)
			{
				fprintf(target,"MOV R0, \"%s\"\n",t->right->varname);
			}
			else if(t->right->type==7 && t->right->left->type==1)
			{
				fprintf(target,"MOV R0, %d\n",j);
				fprintf(target,"MOV R1, [%d]\n",t->right->left->Gentry->binding);
				//printf("check- %d",t->right->left->Gentry->binding);
				fprintf(target, "ADD R0, R1\n");
				fprintf(target, "MOV R0, [R0]\n");
			}
			
			fprintf(target, "MOV SP, 4300\n");
			fprintf(target, "MOV R1, \"Write\"\n");
			fprintf(target, "PUSH R1\n");
			fprintf(target, "MOV R1, -2\n");
			fprintf(target, "PUSH R1\n");
			fprintf(target, "PUSH R0\n");
			fprintf(target, "PUSH R0\n");
			fprintf(target, "PUSH R0\n");
			fprintf(target,"CALL 0\n");
			fprintf(target, "POP R0\n");
			fprintf(target, "POP R1\n");
			fprintf(target, "POP R1\n");
			fprintf(target, "POP R1\n");
			fprintf(target, "POP R1\n");
			regNo--;
			return regNo;
		}
		else if(t->nodetype==3)
		{
			return regNo;
		}
		else if(t->nodetype==4)
		{
                        if(t->left->expr_type==1){
                        	if(t->left->type==1 || (t->left->type==7 && t->left->left->type==0))
                        	{
					if(t->right->type==1 || (t->right->type==7 && t->right->left->type==0))
					{
						fprintf(target,"MOV R0,[%d]\n",j);
						fprintf(target,"MOV [%d], R0\n",i);
					}
					else if(t->right->type==7 && t->right->left->type==1)
					{
						fprintf(target,"MOV R0, %d\n",j);
						fprintf(target,"MOV R1, [%d]\n",t->right->left->Gentry->binding);
						fprintf(target, "ADD R0, R1\n");
						fprintf(target, "MOV R0, [R0]\n");
						fprintf(target,"MOV [%d], R0\n",i);
					}
					else
					{
						fprintf(target,"MOV [%d],R%d\n",i,j);
						regNo--;
					}
				}
				else if(t->left->type==7 && t->left->left->type==1)
				{	//printf("check1");
					fprintf(target,"MOV R0, %d\n",i);
					fprintf(target,"MOV R2, [%d]\n",t->left->left->Gentry->binding);
					fprintf(target, "ADD R2, R0\n");
					
					if(t->right->type==1 || (t->right->type==7 && t->right->left->type==0))
					{
						fprintf(target,"MOV R0,[%d]\n",j);
						fprintf(target,"MOV [R2], R0\n");
					}
					else if(t->right->type==7 && t->right->left->type==1)
					{
						fprintf(target,"MOV R0, %d\n",j);
						fprintf(target,"MOV R1, [%d]\n",t->right->left->Gentry->binding);
						fprintf(target, "ADD R0, R1\n");
						fprintf(target, "MOV R0, [R0]\n");
						fprintf(target,"MOV [R2], R0\n");
					}
					else
					{
						//printf("check2");
						fprintf(target,"MOV [R2],R%d\n",j);
						regNo--;
					}
				}
			}
			else if(t->left->expr_type==2)
			{
				if(t->left->type==1 || (t->left->type==7 && t->left->left->type==0))
                        	{
					if(t->right->type==1 || (t->right->type==7 && t->right->left->type==0))
					{
						fprintf(target,"MOV R0,[%d]\n",j);
						fprintf(target,"MOV [%d], R0\n",i);
					}
					else if(t->right->type==7 && t->right->left->type==1)
					{
						fprintf(target,"MOV R0, %d\n",j);
						fprintf(target,"MOV R1, [%d]\n",t->right->left->Gentry->binding);
						fprintf(target, "ADD R0, R1\n");
						fprintf(target, "MOV R0, [R0]\n");
						fprintf(target,"MOV [%d], R0\n",i);
					}
					else
					{
						fprintf(target,"MOV [%d],R%d\n",i,j);
						regNo--;
					}
				}
				else if(t->left->type==7 && t->left->left->type==1)
				{	//printf("check1");
					fprintf(target,"MOV R0, %d\n",i);
					fprintf(target,"MOV R2, [%d]\n",t->left->left->Gentry->binding);
					fprintf(target, "ADD R2, R0\n");
					
					if(t->right->type==1 || (t->right->type==7 && t->right->left->type==0))
					{
						fprintf(target,"MOV R0,[%d]\n",j);
						fprintf(target,"MOV [R2], R0\n");
					}
					else if(t->right->type==7 && t->right->left->type==1)
					{
						fprintf(target,"MOV R0, %d\n",j);
						fprintf(target,"MOV R1, [%d]\n",t->right->left->Gentry->binding);
						fprintf(target, "ADD R0, R1\n");
						fprintf(target, "MOV R0, [R0]\n");
						fprintf(target,"MOV [R2], R0\n");
					}
					else
					{
						//printf("check2");
						fprintf(target,"MOV [R2],R%d\n",j);
						regNo--;
					}
				}
				else
				{
					fprintf(target,"MOV [%d],\"%s\"\n",i,t->right->varname);
				}
			}
			return regNo;
		}
		else if(t->nodetype==5)
		{
			if(t->right->type==1 || (t->right->type==7 && t->right->left->type==0))
                        {
                        	
                                if(t->left->type==1 || (t->left->type==7 && t->left->left->type==0))
                                {
                                	//printf("check1a");
                                        fprintf(target, "MOV R%d, [%d]\n",regNo,i);
                                        fprintf(target, "MOV R0, [%d]\n",j);
                                        fprintf(target, "ADD R%d, R0\n",regNo);
                                        regNo++;
                                        return regNo-1;
                                }
                                else if(t->left->type==7 && t->left->left->type==1)
				 {	
				 	//printf("check2a");
					fprintf(target,"MOV R%d, %d\n",regNo,i);
					fprintf(target,"MOV R1, [%d]\n",t->left->left->Gentry->binding);
					fprintf(target,"ADD R1, R%d\n",regNo);
					fprintf(target,"MOV R%d, [R1]\n",regNo);
					
					fprintf(target, "MOV R0, [%d]\n",j);
					fprintf(target, "ADD R%d, R0\n",regNo);
                                       regNo++;
                                       return regNo-1;
				 }
                                else
                                {	// printf("check3a");
                                        fprintf(target, "MOV R0, [%d]\n",j);
                                        fprintf(target, "ADD R%d, R0\n",i);
                                        return i;
                                }
                                
                        }
                        else if(t->right->type==7 && t->right->left->type==1)
			{	
				fprintf(target,"MOV R0, %d\n",j);
				fprintf(target,"MOV R1, [%d]\n",t->right->left->Gentry->binding);
				fprintf(target,"ADD R1, R0\n");
				fprintf(target,"MOV R0, [R1]\n");
				
				 if(t->left->type==1 || (t->left->type==7 && t->left->left->type==0))
                                {
                                        fprintf(target, "MOV R%d, [%d]\n",regNo,i);
                                        fprintf(target, "ADD R%d, R0\n",regNo);
                                        regNo++;
                                        return regNo-1;
                                }
                                else if(t->left->type==7 && t->left->left->type==1)
				 {	
					fprintf(target,"MOV R%d, %d\n",regNo,i);
					fprintf(target,"MOV R1, [%d]\n",t->left->left->Gentry->binding);
					fprintf(target,"ADD R1, R%d\n",regNo);
					fprintf(target,"MOV R%d, [R1]\n",regNo);
					
					fprintf(target, "ADD R%d, R0\n",regNo);
                                       regNo++;
                                       return regNo-1;
				 }
                                else
                                {
                                        fprintf(target, "ADD R%d, R0\n",i);
                                        return i;
                                }
					
			}
                        else
                        {
                                 if(t->left->type==1 || (t->left->type==7 && t->left->left->type==0))
                                {
                                	//printf("check1b");
                                	  fprintf(target, "MOV R0, R%d\n",j);
                                        fprintf(target, "MOV R%d, [%d]\n",j,i);
                                        fprintf(target, "ADD R%d, R0\n",j);
                                        return j;
                                	 
                                }
                                else if(t->left->type==7 && t->left->left->type==1)
				 {	
				 	//printf("check2b");
					fprintf(target,"MOV R%d, %d\n",regNo,i);
					fprintf(target,"MOV R1, [%d]\n",t->left->left->Gentry->binding);
					fprintf(target,"ADD R1, R%d\n",regNo);
					fprintf(target,"MOV R%d, [R1]\n",regNo);
					
					fprintf(target, "MOV R0, R%d\n",j);
					fprintf(target, "ADD R%d, R0\n",regNo);
                                       regNo++;
                                       return regNo-1;
				 }
                                else
                                {
                                	  //printf("check3b");
                                	  fprintf(target, "ADD R%d, R%d\n",i,j);
                                        regNo--;
                                        return i;
                                }
                        }
		}
		else if(t->nodetype==6)
		{
            		if(t->right->type==1 || (t->right->type==7 && t->right->left->type==0))
                        {
                        	
                                if(t->left->type==1 || (t->left->type==7 && t->left->left->type==0))
                                {
                                	//printf("check1a");
                                        fprintf(target, "MOV R%d, [%d]\n",regNo,i);
                                        fprintf(target, "MOV R0, [%d]\n",j);
                                        fprintf(target, "SUB R%d, R0\n",regNo);
                                        regNo++;
                                        return regNo-1;
                                }
                                else if(t->left->type==7 && t->left->left->type==1)
				 {	
				 	//printf("check2a");
					fprintf(target,"MOV R%d, %d\n",regNo,i);
					fprintf(target,"MOV R1, [%d]\n",t->left->left->Gentry->binding);
					fprintf(target,"ADD R1, R%d\n",regNo);
					fprintf(target,"MOV R%d, [R1]\n",regNo);
					
					fprintf(target, "MOV R0, [%d]\n",j);
					fprintf(target, "SUB R%d, R0\n",regNo);
                                       regNo++;
                                       return regNo-1;
				 }
                                else
                                {	// printf("check3a");
                                        fprintf(target, "MOV R0, [%d]\n",j);
                                        fprintf(target, "SUB R%d, R0\n",i);
                                        return i;
                                }
                                
                        }
                        else if(t->right->type==7 && t->right->left->type==1)
			{	
				fprintf(target,"MOV R0, %d\n",j);
				fprintf(target,"MOV R1, [%d]\n",t->right->left->Gentry->binding);
				fprintf(target,"ADD R1, R0\n");
				fprintf(target,"MOV R0, [R1]\n");
				
				 if(t->left->type==1 || (t->left->type==7 && t->left->left->type==0))
                                {
                                        fprintf(target, "MOV R%d, [%d]\n",regNo,i);
                                        fprintf(target, "SUB R%d, R0\n",regNo);
                                        regNo++;
                                        return regNo-1;
                                }
                                else if(t->left->type==7 && t->left->left->type==1)
				 {	
					fprintf(target,"MOV R%d, %d\n",regNo,i);
					fprintf(target,"MOV R1, [%d]\n",t->left->left->Gentry->binding);
					fprintf(target,"ADD R1, R%d\n",regNo);
					fprintf(target,"MOV R%d, [R1]\n",regNo);
					
					fprintf(target, "SUB R%d, R0\n",regNo);
                                       regNo++;
                                       return regNo-1;
				 }
                                else
                                {
                                        fprintf(target, "SUB R%d, R0\n",i);
                                        return i;
                                }
					
			}
                        else
                        {
                                 if(t->left->type==1 || (t->left->type==7 && t->left->left->type==0))
                                {
                                	//printf("check1b");
                                	  fprintf(target, "MOV R0, R%d\n",j);
                                        fprintf(target, "MOV R%d, [%d]\n",j,i);
                                        fprintf(target, "SUB R%d, R0\n",j);
                                        return j;
                                	 
                                }
                                else if(t->left->type==7 && t->left->left->type==1)
				 {	
				 	//printf("check2b");
					fprintf(target,"MOV R%d, %d\n",regNo,i);
					fprintf(target,"MOV R1, [%d]\n",t->left->left->Gentry->binding);
					fprintf(target,"ADD R1, R%d\n",regNo);
					fprintf(target,"MOV R%d, [R1]\n",regNo);
					
					fprintf(target, "MOV R0, R%d\n",j);
					fprintf(target, "SUB R%d, R0\n",regNo);
                                       regNo++;
                                       return regNo-1;
				 }
                                else
                                {
                                	//  printf("check3b");
                                	  fprintf(target, "SUB R%d, R%d\n",i,j);
                                        regNo--;
                                        return i;
                                }
                        }
		}
		else if(t->nodetype==7)
		{
           		if(t->right->type==1 || (t->right->type==7 && t->right->left->type==0))
                        {
                        	
                                if(t->left->type==1 || (t->left->type==7 && t->left->left->type==0))
                                {
                                	//printf("check1a");
                                        fprintf(target, "MOV R%d, [%d]\n",regNo,i);
                                        fprintf(target, "MOV R0, [%d]\n",j);
                                        fprintf(target, "MUL R%d, R0\n",regNo);
                                        regNo++;
                                        return regNo-1;
                                }
                                else if(t->left->type==7 && t->left->left->type==1)
				 {	
				 	//printf("check2a");
					fprintf(target,"MOV R%d, %d\n",regNo,i);
					fprintf(target,"MOV R1, [%d]\n",t->left->left->Gentry->binding);
					fprintf(target,"ADD R1, R%d\n",regNo);
					fprintf(target,"MOV R%d, [R1]\n",regNo);
					
					fprintf(target, "MOV R0, [%d]\n",j);
					fprintf(target, "MUL R%d, R0\n",regNo);
                                       regNo++;
                                       return regNo-1;
				 }
                                else
                                {	// printf("check3a");
                                        fprintf(target, "MOV R0, [%d]\n",j);
                                        fprintf(target, "MUL R%d, R0\n",i);
                                        return i;
                                }
                                
                        }
                        else if(t->right->type==7 && t->right->left->type==1)
			{	
				fprintf(target,"MOV R0, %d\n",j);
				fprintf(target,"MOV R1, [%d]\n",t->right->left->Gentry->binding);
				fprintf(target,"ADD R1, R0\n");
				fprintf(target,"MOV R0, [R1]\n");
				
				 if(t->left->type==1 || (t->left->type==7 && t->left->left->type==0))
                                {
                                        fprintf(target, "MOV R%d, [%d]\n",regNo,i);
                                        fprintf(target, "MUL R%d, R0\n",regNo);
                                        regNo++;
                                        return regNo-1;
                                }
                                else if(t->left->type==7 && t->left->left->type==1)
				 {	
					fprintf(target,"MOV R%d, %d\n",regNo,i);
					fprintf(target,"MOV R1, [%d]\n",t->left->left->Gentry->binding);
					fprintf(target,"ADD R1, R%d\n",regNo);
					fprintf(target,"MOV R%d, [R1]\n",regNo);
					
					fprintf(target, "MUL R%d, R0\n",regNo);
                                       regNo++;
                                       return regNo-1;
				 }
                                else
                                {
                                        fprintf(target, "MUL R%d, R0\n",i);
                                        return i;
                                }
					
			}
                        else
                        {
                                 if(t->left->type==1 || (t->left->type==7 && t->left->left->type==0))
                                {
                                	//printf("check1b");
                                	  fprintf(target, "MOV R0, R%d\n",j);
                                        fprintf(target, "MOV R%d, [%d]\n",j,i);
                                        fprintf(target, "MUL R%d, R0\n",j);
                                        return j;
                                	 
                                }
                                else if(t->left->type==7 && t->left->left->type==1)
				 {	
				 	//printf("check2b");
					fprintf(target,"MOV R%d, %d\n",regNo,i);
					fprintf(target,"MOV R1, [%d]\n",t->left->left->Gentry->binding);
					fprintf(target,"ADD R1, R%d\n",regNo);
					fprintf(target,"MOV R%d, [R1]\n",regNo);
					
					fprintf(target, "MOV R0, R%d\n",j);
					fprintf(target, "MUL R%d, R0\n",regNo);
                                       regNo++;
                                       return regNo-1;
				 }
                                else
                                {
                                	//  printf("check3b");
                                	  fprintf(target, "MUL R%d, R%d\n",i,j);
                                        regNo--;
                                        return i;
                                }
                        }
		}
		else if(t->nodetype==8)
		{
            		if(t->right->type==1 || (t->right->type==7 && t->right->left->type==0))
                        {
                        	
                                if(t->left->type==1 || (t->left->type==7 && t->left->left->type==0))
                                {
                                	//printf("check1a");
                                        fprintf(target, "MOV R%d, [%d]\n",regNo,i);
                                        fprintf(target, "MOV R0, [%d]\n",j);
                                        fprintf(target, "DIV R%d, R0\n",regNo);
                                        regNo++;
                                        return regNo-1;
                                }
                                else if(t->left->type==7 && t->left->left->type==1)
				 {	
				 	//printf("check2a");
					fprintf(target,"MOV R%d, %d\n",regNo,i);
					fprintf(target,"MOV R1, [%d]\n",t->left->left->Gentry->binding);
					fprintf(target,"ADD R1, R%d\n",regNo);
					fprintf(target,"MOV R%d, [R1]\n",regNo);
					
					fprintf(target, "MOV R0, [%d]\n",j);
					fprintf(target, "DIV R%d, R0\n",regNo);
                                       regNo++;
                                       return regNo-1;
				 }
                                else
                                {	// printf("check3a");
                                        fprintf(target, "MOV R0, [%d]\n",j);
                                        fprintf(target, "DIV R%d, R0\n",i);
                                        return i;
                                }
                                
                        }
                        else if(t->right->type==7 && t->right->left->type==1)
			{	
				fprintf(target,"MOV R0, %d\n",j);
				fprintf(target,"MOV R1, [%d]\n",t->right->left->Gentry->binding);
				fprintf(target,"ADD R1, R0\n");
				fprintf(target,"MOV R0, [R1]\n");
				
				 if(t->left->type==1 || (t->left->type==7 && t->left->left->type==0))
                                {
                                        fprintf(target, "MOV R%d, [%d]\n",regNo,i);
                                        fprintf(target, "DIV R%d, R0\n",regNo);
                                        regNo++;
                                        return regNo-1;
                                }
                                else if(t->left->type==7 && t->left->left->type==1)
				 {	
					fprintf(target,"MOV R%d, %d\n",regNo,i);
					fprintf(target,"MOV R1, [%d]\n",t->left->left->Gentry->binding);
					fprintf(target,"ADD R1, R%d\n",regNo);
					fprintf(target,"MOV R%d, [R1]\n",regNo);
					
					fprintf(target, "DIV R%d, R0\n",regNo);
                                       regNo++;
                                       return regNo-1;
				 }
                                else
                                {
                                        fprintf(target, "DIV R%d, R0\n",i);
                                        return i;
                                }
					
			}
                        else
                        {
                                 if(t->left->type==1 || (t->left->type==7 && t->left->left->type==0))
                                {
                                	//printf("check1b");
                                	  fprintf(target, "MOV R0, R%d\n",j);
                                        fprintf(target, "MOV R%d, [%d]\n",j,i);
                                        fprintf(target, "DIV R%d, R0\n",j);
                                        return j;
                                	 
                                }
                                else if(t->left->type==7 && t->left->left->type==1)
				 {	
				 	//printf("check2b");
					fprintf(target,"MOV R%d, %d\n",regNo,i);
					fprintf(target,"MOV R1, [%d]\n",t->left->left->Gentry->binding);
					fprintf(target,"ADD R1, R%d\n",regNo);
					fprintf(target,"MOV R%d, [R1]\n",regNo);
					
					fprintf(target, "MOV R0, R%d\n",j);
					fprintf(target, "DIV R%d, R0\n",regNo);
                                       regNo++;
                                       return regNo-1;
				 }
                                else
                                {
                                	//  printf("check3b");
                                	  fprintf(target, "DIV R%d, R%d\n",i,j);
                                        regNo--;
                                        return i;
                                }
                        }
		}
		else if(t->nodetype==17)
                {
                        if(t->right->type==1 || (t->right->type==7 && t->right->left->type==0))
                        {
                        	
                                if(t->left->type==1 || (t->left->type==7 && t->left->left->type==0))
                                {
                                	//printf("check1a");
                                        fprintf(target, "MOV R%d, [%d]\n",regNo,i);
                                        fprintf(target, "MOV R0, [%d]\n",j);
                                        fprintf(target, "MOD R%d, R0\n",regNo);
                                        regNo++;
                                        return regNo-1;
                                }
                                else if(t->left->type==7 && t->left->left->type==1)
				 {	
				 	//printf("check2a");
					fprintf(target,"MOV R%d, %d\n",regNo,i);
					fprintf(target,"MOV R1, [%d]\n",t->left->left->Gentry->binding);
					fprintf(target,"ADD R1, R%d\n",regNo);
					fprintf(target,"MOV R%d, [R1]\n",regNo);
					
					fprintf(target, "MOV R0, [%d]\n",j);
					fprintf(target, "MOD R%d, R0\n",regNo);
                                       regNo++;
                                       return regNo-1;
				 }
                                else
                                {	// printf("check3a");
                                        fprintf(target, "MOV R0, [%d]\n",j);
                                        fprintf(target, "MOD R%d, R0\n",i);
                                        return i;
                                }
                                
                        }
                        else if(t->right->type==7 && t->right->left->type==1)
			{	
				fprintf(target,"MOV R0, %d\n",j);
				fprintf(target,"MOV R1, [%d]\n",t->right->left->Gentry->binding);
				fprintf(target,"ADD R1, R0\n");
				fprintf(target,"MOV R0, [R1]\n");
				
				 if(t->left->type==1 || (t->left->type==7 && t->left->left->type==0))
                                {
                                        fprintf(target, "MOV R%d, [%d]\n",regNo,i);
                                        fprintf(target, "MOD R%d, R0\n",regNo);
                                        regNo++;
                                        return regNo-1;
                                }
                                else if(t->left->type==7 && t->left->left->type==1)
				 {	
					fprintf(target,"MOV R%d, %d\n",regNo,i);
					fprintf(target,"MOV R1, [%d]\n",t->left->left->Gentry->binding);
					fprintf(target,"ADD R1, R%d\n",regNo);
					fprintf(target,"MOV R%d, [R1]\n",regNo);
					
					fprintf(target, "MOD R%d, R0\n",regNo);
                                       regNo++;
                                       return regNo-1;
				 }
                                else
                                {
                                        fprintf(target, "MOD R%d, R0\n",i);
                                        return i;
                                }
					
			}
                        else
                        {
                                 if(t->left->type==1 || (t->left->type==7 && t->left->left->type==0))
                                {
                                	//printf("check1b");
                                	  fprintf(target, "MOV R0, R%d\n",j);
                                        fprintf(target, "MOV R%d, [%d]\n",j,i);
                                        fprintf(target, "MOD R%d, R0\n",j);
                                        return j;
                                	 
                                }
                                else if(t->left->type==7 && t->left->left->type==1)
				 {	
				 	//printf("check2b");
					fprintf(target,"MOV R%d, %d\n",regNo,i);
					fprintf(target,"MOV R1, [%d]\n",t->left->left->Gentry->binding);
					fprintf(target,"ADD R1, R%d\n",regNo);
					fprintf(target,"MOV R%d, [R1]\n",regNo);
					
					fprintf(target, "MOV R0, R%d\n",j);
					fprintf(target, "MOD R%d, R0\n",regNo);
                                       regNo++;
                                       return regNo-1;
				 }
                                else
                                {
                                	//  printf("check3b");
                                	  fprintf(target, "MOD R%d, R%d\n",i,j);
                                        regNo--;
                                        return i;
                                }
                        }
                }
		else if(t->nodetype==15)
		{
			

			i=codeGen(t->left,target);
			k1=labelno++;
			if(t->third)
			{
				k2=labelno++;
				fprintf(target, "JZ R%d, L%d\n",i,k2);
			}
			else
				fprintf(target, "JZ R%d, L%d\n",i,k1);
			codeGen(t->right,target);
			fprintf(target, "JMP L%d\n",k1);
			
			if(t->third)
			{
				fprintf(target,"L%d:\n",k2);
				codeGen(t->third,target);
			}
			fprintf(target, "JMP L%d\n",k1);
			fprintf(target,"L%d:\n",k1);
			return regNo;
		}
		else if(t->nodetype==16)
		{
			fprintf(target,"L%d:\n",labelno++);
			k=labelno;
			k3=labelno;
			labelno++;
			i=codeGen(t->left,target);
			fprintf(target, "JZ R%d, L%d\n",i,k);
			codeGen(t->right,target);
			fprintf(target,"JMP L%d\n",k-1);
			fprintf(target, "L%d:\n",k);
			k3=-1;
			return regNo;
		}
		else
		{

			
			if(t->right->type==1 || (t->right->type==7 && t->right->left->type==0))
			{
				fprintf(target, "MOV R0, [%d]\n",j);
				if(t->left->type==1 || (t->left->type==7 && t->left->left->type==0))
				{
					fprintf(target, "MOV R%d, [%d]\n",regNo,i);
				}
				else if(t->left->type==7 && t->left->left->type==1)
				{	
					fprintf(target,"MOV R%d, %d\n",regNo,i);
					fprintf(target,"MOV R1, [%d]\n",t->left->left->Gentry->binding);
					fprintf(target,"ADD R1, R%d\n",regNo);
					fprintf(target,"MOV R%d, [R1]\n",regNo);	
				}
				else
				{	regNo--;
					fprintf(target, "MOV R%d, R%d\n",regNo, i);
				}
			}
			else if(t->right->type==7 && t->right->left->type==1)
			{	
				fprintf(target,"MOV R0, %d\n",j);
				fprintf(target,"MOV R1, [%d]\n",t->right->left->Gentry->binding);
				fprintf(target,"ADD R1, R0\n");
				fprintf(target,"MOV R0, [R1]\n");
				if(t->left->type==1 || (t->left->type==7 && t->left->left->type==0))
				{
					fprintf(target, "MOV R%d, [%d]\n",regNo,i);
				}
				else if(t->left->type==7 && t->left->left->type==1)
				{	
					fprintf(target,"MOV R%d, %d\n",regNo,i);
					fprintf(target,"MOV R1, [%d]\n",t->left->left->Gentry->binding);
					fprintf(target,"ADD R1, R%d\n",regNo);
					fprintf(target,"MOV R%d, [R1]\n",regNo);	
				}
				else
				{	regNo--;
					fprintf(target, "MOV R%d, R%d\n",regNo, i);
				}
					
			}
			else
			{
				fprintf(target, "MOV R0, R%d\n",j);
				regNo--;
				if(t->left->type==1 || (t->left->type==7 && t->left->left->type==0))
				{
					fprintf(target, "MOV R%d, [%d]\n",regNo,i);
				}
				else if(t->left->type==7 && t->left->left->type==1)
				{	
					fprintf(target,"MOV R%d, %d\n",regNo,i);
					fprintf(target,"MOV R1, [%d]\n",t->left->left->Gentry->binding);
					fprintf(target,"ADD R1, R%d\n",regNo);
					fprintf(target,"MOV R%d, [R1]\n",regNo);	
				}
				else
				{	regNo--;
					fprintf(target, "MOV R%d, R%d\n",regNo, i);
				}
			}
				
				
			if(t->nodetype==9)
				fprintf(target, "LT R%d, R0\n",regNo);
			else if(t->nodetype==10)
				fprintf(target, "GT R%d, R0\n",regNo);
			else if(t->nodetype==11)
				fprintf(target, "LE R%d, R0\n",regNo);
			else if(t->nodetype==12)
				fprintf(target, "GE R%d, R0\n",regNo);
			else if(t->nodetype==13)
				fprintf(target, "NE R%d, R0\n",regNo);
			else if(t->nodetype==14)
				fprintf(target, "EQ R%d, R0\n",regNo);
			return (regNo);
		}
	}
}


